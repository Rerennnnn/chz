<?php
$page_title = "About Us – Cheeze Tea Alaminos Laguna";
require 'includes/db.php';
require 'includes/header.php';
require 'includes/navbar.php';
?>

<!DOCTYPE html>
<html lang="en" class="scroll-smooth">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?= $page_title ?></title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet" />
    <link href="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="stylesheet" href="assets/index.css?v=<?= time() ?>" />
</head>

<body class="bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 text-gray-800 overflow-x-hidden">

    <!-- Floating Golden Bubbles + Sparkles (same magic as homepage) -->
    <div class="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <?php for ($i = 1; $i <= 22; $i++):
            $size = rand(18, 40);
            $duration = 18 + rand(0, 15);
            $delay = $i * 0.7;
            $left = rand(1, 99);
            ?>
            <div class="bubble-container" style="left: <?= $left ?>%; animation-delay: <?= $delay ?>s;">
                <div class="particle"
                    style="width: <?= $size ?>px; height: <?= $size ?>px; animation-duration: <?= $duration ?>s;"></div>
                <div class="sparkle" style="animation-duration: <?= $duration ?>s; animation-delay: <?= $delay + 0.4 ?>s;">
                </div>
                <div class="sparkle" style="animation-duration: <?= $duration ?>s; animation-delay: <?= $delay + 1.1 ?>s;">
                </div>
                <div class="sparkle" style="animation-duration: <?= $duration ?>s; animation-delay: <?= $delay + 1.8 ?>s;">
                </div>
            </div>
        <?php endfor; ?>
    </div>

    <!-- HERO -->
    <section class="relative min-h-screen flex items-center justify-center px-6 text-center">
        <div class="container mx-auto max-w-5xl">
            <h1 class="text-7xl sm:text-8xl md:text-9xl lg:text-10xl font-black leading-tight" data-aos="fade-up">
                <span class="hero-gradient-text">About</span><br>
                <span class="text-amber-800">Cheeze Tea</span>
            </h1>
            <p class="text-2xl md:text-4xl font-medium text-amber-700 mt-10 max-w-3xl mx-auto" data-aos="fade-up"
                data-aos-delay="400">
                Born in Alaminos, Laguna · Crafted with Love · Served with Happiness
            </p>
        </div>
    </section>

    <!-- OUR STORY -->
    <section class="py-32 bg-white/70 backdrop-blur-xl">
        <div class="container mx-auto px-6 max-w-6xl">
            <div class="grid md:grid-cols-2 gap-16 items-center">
                <div data-aos="fade-right">
                    <h2 class="text-5xl md:text-7xl font-black text-amber-800 mb-8">Our Story</h2>
                    <p class="text-xl leading-relaxed text-gray-700 mb-6">
                        It all started with one dream: <strong>to bring the creamiest, dreamiest cheese foam milk tea to
                            Alaminos, Laguna</strong>.
                    </p>
                    <p class="text-xl leading-relaxed text-gray-700 mb-6">
                        In 2023, two best friends decided that grew up in the same barangay decided to turn their
                        late-night milk tea cravings into reality.
                        After countless experiments in a tiny kitchen, they finally perfected the <strong>golden cheese
                            foam recipe</strong> that melts in your mouth.
                    </p>
                    <p class="text-xl leading-relaxed text-gray-700">
                        Today, Cheeze Tea is more than just a drink — it’s a warm hug in a cup, made fresh daily with
                        love, premium ingredients, and a whole lot of cheese magic.
                    </p>
                </div>
                <div data-aos="fade-left" class="relative">
                    <img src="uploads/story.jpg" alt="Our Story"
                        class="rounded-3xl shadow-2xl w-full h-96 object-cover">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent rounded-3xl"></div>
                </div>
            </div>
        </div>
    </section>

    <!-- WHY CHOOSE US -->
    <section class="py-32">
        <div class="container mx-auto px-6 max-w-7xl">
            <h2 class="text-6xl md:text-8xl font-black text-center text-transparent bg-clip-text bg-gradient-to-r from-amber-600 to-orange-600 mb-20"
                data-aos="fade-up">
                Why People Love Us
            </h2>

            <div class="grid md:grid-cols-3 gap-12">
                <div class="text-center" data-aos="zoom-in" data-aos-delay="100">
                    <div class="text-8xl mb-6">Real Cheese Foam</div>
                    <p class="text-2xl font-bold text-amber-700">No powder. No shortcuts. Only real cream cheese whipped
                        to perfection.</p>
                </div>
                <div class="text-center" data-aos="zoom-in" data-aos-delay="300">
                    <div class="text-8xl mb-6">Fresh Daily</div>
                    <p class="text-2xl font-bold text-amber-700">Every drink is made fresh when you order — never
                        pre-made.</p>
                </div>
                <div class="text-center" data-aos="zoom-in" data-aos-delay="500">
                    <div class="text-8xl mb-6">Love in Every Cup</div>
                    <p class="text-2xl font-bold text-amber-700">We put our hearts into every sip. That’s the Cheeze Tea
                        promise.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- TEAM / FOUNDERS -->
    <section class="py-32 bg-gradient-to-b from-amber-50 to-yellow-100">
        <div class="container mx-auto px-6 max-w-6xl text-center">
            <h2 class="text-6xl md:text-8xl font-black text-amber-800 mb-20" data-aos="fade-up">
                Meet the Dreamers
            </h2>

            <div class="grid md:grid-cols-2 gap-16 items-center">
                <div data-aos="fade-right">
                    <img src="uploads/gallery/founder1.jpg" alt="Founder" class="rounded-3xl shadow-2xl mx-auto w-80">
                    <h3 class="text-3xl font-bold mt-8 text-amber-800">Angelo Averion</h3>
                    <p class="text-xl text-amber-600">The Boss</p>
                </div>
                <div data-aos="fade-left">
                    <img src="uploads/bro.jpg" alt="Founder" class="rounded-3xl shadow-2xl mx-auto w-80">
                    <h3 class="text-3xl font-bold mt-8 text-amber-800">Quert Alfonso Villafuerte</h3>
                    <p class="text-xl text-amber-600">Other Boss</p>
                </div>
            </div>

            <p class="text-2xl text-center mt-16 max-w-4xl mx-auto text-amber-700" data-aos="fade-up">
                “We didn’t just want to sell milk tea. We wanted to create moments of joy, one golden sip at a time.”
            </p>
        </div>
    </section>

    <!-- LOCATION & HOURS -->
    <section class="py-32 bg-white/80 backdrop-blur-xl">
        <div class="container mx-auto px-6 max-w-5xl text-center">
            <h2 class="text-6xl md:text-8xl font-black text-amber-800 mb-16" data-aos="fade-up">
                Visit Us
            </h2>

            <div class="grid md:grid-cols-2 gap-12 text-left max-w-4xl mx-auto">
                <div class="bg-gradient-to-br from-amber-100 to-yellow-50 p-10 rounded-3xl shadow-xl"
                    data-aos="fade-right">
                    <h3 class="text-3xl font-bold text-amber-800 flex items-center gap-4 mb-4">
                        <i class="fas fa-map-marker-alt text-4xl text-orange-600"></i> Location
                    </h3>
                    <p class="text-xl">National Highway, Brgy. San Andres<br>Alaminos, Laguna 4001</p>
                </div>

                <div class="bg-gradient-to-br from-amber-100 to-yellow-50 p-10 rounded-3xl shadow-xl"
                    data-aos="fade-left">
                    <h3 class="text-3xl font-bold text-amber-800 flex items-center gap-4 mb-4">
                        <i class="fas fa-clock text-4xl text-orange-600"></i> Open Hours
                    </h3>
                    <p class="text-xl">
                        Monday – Sunday<br>
                        <strong class="text-2xl text-amber-700">10:00 AM – 10:00 PM</strong>
                    </p>
                </div>
            </div>

            <a href="https://www.facebook.com/profile.php?id=100076206880064" target="_blank"
                class="inline-block mt-16 btn btn-lg bg-gradient-to-r from-amber-600 to-orange-600 text-white text-2xl px-16 py-6 rounded-full shadow-2xl hover:shadow-3xl transform hover:scale-110 transition">
                <i class="fab fa-facebook mr-4"></i> Follow us on Facebook
            </a>
        </div>
    </section>

    <!-- FINAL CTA -->
    <section
        class="py-32 bg-gradient-to-r from-amber-700 via-orange-600 to-amber-800 text-white text-center relative overflow-hidden">
        <div class="absolute inset-0 bg-black/40"></div>
        <div class="relative z-10 container mx-auto px-6">
            <h2 class="text-6xl md:text-9xl font-black mb-10 text-white" data-aos="fade-up">
                Come Say Hi!
            </h2>
            <p class="text-3xl mb-12 text-white" data-aos="fade-up" data-aos-delay="300">
                We can’t wait to serve you your next favorite drink
            </p>
            <a href="products.php"
                class="btn btn-lg bg-white text-amber-700 hover:bg-yellow-100 text-3xl px-20 py-8 rounded-full shadow-2xl hover:shadow-3xl transform hover:scale-110 transition">
                Order Now
            </a>
        </div>
    </section>

    <?php require 'includes/footer.php'; ?>

    <script>
        AOS.init({
            duration: 1200,
            easing: 'ease-out-cubic',
            once: true
        });
    </script>
</body>

</html>