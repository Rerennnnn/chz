<?php
session_start();
require '../includes/config.php';
require '../includes/db.php';
require '../vendor/autoload.php';

$fb = new \Facebook\Facebook([
    'app_id' => FB_APP_ID,
    'app_secret' => FB_APP_SECRET,
    'default_graph_version' => 'v18.0',
]);

$helper = $fb->getRedirectLoginHelper();

try {
    // Get access token from Facebook
    $accessToken = $helper->getAccessToken(FB_REDIRECT_URI);
} catch(Facebook\Exceptions\FacebookResponseException $e) {
    $_SESSION['oauth_error'] = 'Graph returned an error: ' . $e->getMessage();
    header('Location: ../login.php');
    exit();
} catch(Facebook\Exceptions\FacebookSDKException $e) {
    $_SESSION['oauth_error'] = 'Facebook SDK error: ' . $e->getMessage();
    header('Location: ../login.php');
    exit();
}

if (!isset($accessToken)) {
    $_SESSION['oauth_error'] = 'No access token received';
    header('Location: ../login.php');
    exit();
}

// Get user info
try {
    $response = $fb->get('/me?fields=id,name,email', $accessToken);
    $userData = $response->getGraphUser();
} catch(Facebook\Exceptions\FacebookResponseException $e) {
    $_SESSION['oauth_error'] = 'Graph returned an error: ' . $e->getMessage();
    header('Location: ../login.php');
    exit();
} catch(Facebook\Exceptions\FacebookSDKException $e) {
    $_SESSION['oauth_error'] = 'Facebook SDK error: ' . $e->getMessage();
    header('Location: ../login.php');
    exit();
}

$email = $userData->getEmail();
$name = $userData->getName() ?? 'Facebook User';
$fb_id = $userData->getId();

if (!$email) {
    $_SESSION['oauth_error'] = 'Could not retrieve email from Facebook';
    header('Location: ../login.php');
    exit();
}

// Check if user exists
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

if ($user) {
    // Existing user: login and link FB if not already linked
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['name'] = $user['name'];
    $_SESSION['role'] = $user['role'];

    if (!$user['fb_id']) {
        $updateStmt = $pdo->prepare("UPDATE users SET fb_id = ? WHERE id = ?");
        $updateStmt->execute([$fb_id, $user['id']]);
    }

} else {
    // New user: create account with random password
    $hashedPassword = password_hash(bin2hex(random_bytes(16)), PASSWORD_BCRYPT);
    $insertStmt = $pdo->prepare(
        "INSERT INTO users (name, email, password, fb_id, role) VALUES (?, ?, ?, ?, ?)"
    );
    $insertStmt->execute([$name, $email, $hashedPassword, $fb_id, 'customer']);

    $newUserId = $pdo->lastInsertId();
    $_SESSION['user_id'] = $newUserId;
    $_SESSION['name'] = $name;
    $_SESSION['role'] = 'customer';
}

// Redirect to homepage
header('Location: ../index.php');
exit();
