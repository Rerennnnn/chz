-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2025 at 03:35 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(150) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `created_at`) VALUES
(1, 'ren', NULL, '2025-12-03 14:34:55');

-- --------------------------------------------------------

--
-- Table structure for table `deliveries`
--

CREATE TABLE `deliveries` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `rider_id` int(11) DEFAULT NULL,
  `pickup_address` varchar(255) NOT NULL,
  `dropoff_address` varchar(255) NOT NULL,
  `pickup_lat` decimal(10,7) DEFAULT NULL,
  `pickup_lng` decimal(10,7) DEFAULT NULL,
  `dropoff_lat` decimal(10,7) DEFAULT NULL,
  `dropoff_lng` decimal(10,7) DEFAULT NULL,
  `distance_km` decimal(8,2) DEFAULT 0.00,
  `created_at` datetime DEFAULT current_timestamp(),
  `assigned_at` datetime DEFAULT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `picked_up_at` datetime DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `status` enum('assigned','accepted','picked_up','delivered','failed','cancelled') NOT NULL DEFAULT 'assigned',
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deliveries`
--

INSERT INTO `deliveries` (`id`, `order_id`, `rider_id`, `pickup_address`, `dropoff_address`, `pickup_lat`, `pickup_lng`, `dropoff_lat`, `dropoff_lng`, `distance_km`, `created_at`, `assigned_at`, `accepted_at`, `picked_up_at`, `delivered_at`, `status`, `notes`) VALUES
(1, 22, 1, 'Cheeze Tea Main Store', '235', NULL, NULL, NULL, NULL, 0.00, '2025-12-02 21:47:51', NULL, '2025-12-02 21:47:58', '2025-12-02 21:48:03', '2025-12-02 22:02:26', 'delivered', NULL),
(2, 23, 1, 'Cheeze Tea Main Store', 'wqewqewqe', NULL, NULL, NULL, NULL, 0.00, '2025-12-03 19:58:28', NULL, '2025-12-03 20:23:16', '2025-12-03 20:23:30', '2025-12-03 20:24:24', 'delivered', NULL),
(3, 24, 7, 'Cheeze Tea Main Store', 'qweasewrwq', NULL, NULL, NULL, NULL, 0.00, '2025-12-04 18:03:08', NULL, '2025-12-04 18:17:39', '2025-12-04 18:17:43', '2025-12-04 18:20:22', 'delivered', NULL),
(4, 25, 7, 'Cheeze Tea Main Store', '123213', NULL, NULL, NULL, NULL, 0.00, '2025-12-04 18:05:54', NULL, '2025-12-04 18:17:42', '2025-12-04 18:17:45', NULL, 'picked_up', NULL),
(5, 26, 1, 'Cheeze Tea Main Store', '12qwe', NULL, NULL, NULL, NULL, 0.00, '2025-12-04 18:21:40', NULL, '2025-12-04 18:21:53', '2025-12-04 18:21:56', '2025-12-04 18:22:38', 'delivered', NULL),
(6, 27, 1, 'Cheeze Tea Main Store', 'rqwrwq', NULL, NULL, NULL, NULL, 0.00, '2025-12-04 18:27:45', NULL, '2025-12-04 18:27:54', '2025-12-04 18:27:56', '2025-12-04 18:28:06', 'delivered', NULL),
(7, 29, 1, 'Cheeze Tea Main Store', 'wqeds', NULL, NULL, NULL, NULL, 0.00, '2025-12-04 18:30:10', NULL, '2025-12-04 18:30:17', '2025-12-04 18:30:19', '2025-12-04 18:30:27', 'delivered', NULL),
(8, 37, 1, 'Cheeze Tea Main Store', 'asdw', NULL, NULL, NULL, NULL, 0.00, '2025-12-04 18:54:15', NULL, '2025-12-04 18:54:34', '2025-12-04 18:54:35', '2025-12-04 18:54:49', 'delivered', NULL),
(9, 38, 1, 'Cheeze Tea Main Store', 'ty', NULL, NULL, NULL, NULL, 0.00, '2025-12-04 18:57:37', NULL, '2025-12-04 18:57:48', '2025-12-04 18:57:54', '2025-12-04 18:58:11', 'delivered', NULL),
(10, 39, 1, 'Cheeze Tea Main Store', 'asdwe', NULL, NULL, NULL, NULL, 0.00, '2025-12-04 19:04:21', NULL, '2025-12-04 19:04:36', '2025-12-04 19:04:37', '2025-12-04 19:04:45', 'delivered', NULL),
(11, 40, 13, 'Cheeze Tea Main Store', 'qwe', NULL, NULL, NULL, NULL, 0.00, '2025-12-04 20:03:00', NULL, '2025-12-04 20:04:03', '2025-12-04 20:04:05', '2025-12-04 21:13:36', 'delivered', NULL),
(12, 41, 13, 'Cheeze Tea Main Store', 'asdwe', NULL, NULL, NULL, NULL, 0.00, '2025-12-04 20:03:51', NULL, '2025-12-04 20:04:04', '2025-12-04 20:17:10', '2025-12-06 20:50:13', 'delivered', NULL),
(16, 42, 1, 'Shop', 'asfdwer', NULL, NULL, NULL, NULL, 0.00, '2025-12-06 20:53:15', NULL, '2025-12-06 20:54:23', '2025-12-06 20:54:27', '2025-12-06 20:54:46', 'delivered', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `delivery_proofs`
--

CREATE TABLE `delivery_proofs` (
  `id` int(11) NOT NULL,
  `delivery_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `delivery_proofs`
--

INSERT INTO `delivery_proofs` (`id`, `delivery_id`, `image_path`, `uploaded_at`) VALUES
(1, 1, 'uploads/proofs/1764683312_bg.PNG', '2025-12-02 21:48:32'),
(2, 2, 'uploads/proofs/1764764636_1 (1).jpg', '2025-12-03 20:23:56'),
(3, 3, 'uploads/proofs/1764843475_482242571_664047132812177_931533662552572023_n.jpg', '2025-12-04 18:17:55'),
(4, 5, 'uploads/proofs/1764843720_523258092_769959765554246_4718797139197496523_n.jpg', '2025-12-04 18:22:00'),
(5, 6, 'uploads/proofs/1764844080_481059497_664048509478706_8543595310874172130_n.jpg', '2025-12-04 18:28:00'),
(6, 7, 'uploads/proofs/1764844224_520233388_767688375781385_3325845288833627440_n.jpg', '2025-12-04 18:30:24'),
(7, 8, 'uploads/proofs/1764845683_482242571_664047132812177_931533662552572023_n.jpg', '2025-12-04 18:54:43'),
(8, 9, 'uploads/proofs/1764845881_518406588_767688432448046_4828976655674195048_n.jpg', '2025-12-04 18:58:01'),
(9, 10, 'uploads/proofs/1764846281_520233388_767688375781385_3325845288833627440_n.jpg', '2025-12-04 19:04:41'),
(10, 11, 'uploads/proofs/1764849855_482242571_664047132812177_931533662552572023_n.jpg', '2025-12-04 20:04:15'),
(11, 12, 'uploads/proofs/1765025395_482242571_664047132812177_931533662552572023_n.jpg', '2025-12-06 20:49:55'),
(12, 16, 'uploads/proofs/1765025673_482242571_664047132812177_931533662552572023_n.jpg', '2025-12-06 20:54:33');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `status` enum('pending','completed') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_id` varchar(255) DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT 'pending',
  `payment_method` varchar(50) DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total`, `status`, `created_at`, `payment_id`, `payment_status`, `payment_method`, `customer_name`, `customer_email`, `customer_phone`, `shipping_address`, `notes`) VALUES
(23, 7, 70.50, 'completed', '2025-12-03 11:58:23', 'pi_MysdH1B3Nyk1MGW3DfBVHUzL', 'paid', NULL, 'Rheinier Cuenca', 'cuencarenren@gmail.com', '0923123421', 'wqewqewqe', ''),
(24, 7, 109.00, 'completed', '2025-12-04 10:02:51', 'pi_3RKRWwhjC65CV6PbFaxwKWU3', 'paid', NULL, 'Rheinier Cuenca', 'cuencarenren@gmail.com', '0923123421', 'qweasewrwq', ''),
(25, 7, 197.00, 'completed', '2025-12-04 10:05:51', 'pi_zpvcywqnEj6dNCj552ofHqvP', 'paid', NULL, 'Rheinier Cuenca', 'admin@shop.com', '0923123421', '123213', ''),
(26, 1, 39.00, 'completed', '2025-12-04 10:21:37', 'pi_7xZKZG8okJ89yKU2pwYqNNqJ', 'paid', NULL, 'Admin', 'reren@gmail.com', '0923123421', '12qwe', 's'),
(27, 1, 244.00, 'completed', '2025-12-04 10:27:41', 'pi_4rawbhy2rsWsJQr13yuRntDP', 'paid', NULL, 'Admin', 'admin@shop.com', '0923123421', 'rqwrwq', 'asdw'),
(28, 1, 49.00, 'pending', '2025-12-04 10:29:42', 'pi_gSKas1eMNnmyBEb87aERfzye', 'pending', NULL, 'Admin', 'rheiniercuenca2@gmail.com', '0923123421', 'sdfew', ''),
(29, 1, 88.00, 'completed', '2025-12-04 10:30:06', 'pi_Yap8cPu6gfXJ4Cek5wnJ6vnC', 'paid', NULL, 'Admin', 'admin@shop.com', '0923123421', 'wqeds', ''),
(30, 1, 39.00, 'pending', '2025-12-04 10:38:52', 'pi_4o247AtmpT5db5QtM8mZmFkp', 'pending', NULL, 'Admin', 'cuenca@gmail.com', '0923123421', 'qwe', ''),
(31, 1, 39.00, 'pending', '2025-12-04 10:42:30', NULL, 'pending', NULL, 'Admin', 'cuenca@gmail.com', '0923123421', 'qwe', ''),
(32, 1, 39.00, 'pending', '2025-12-04 10:43:30', 'pi_AZETg7mDVSFX2rqRWhhmvz2T', 'pending', NULL, 'Admin', 'cuenca@gmail.com', '0923123421', 'qwe', ''),
(33, 1, 39.00, 'pending', '2025-12-04 10:44:23', 'pi_Md1aSsQpSEvCXo9H15mmCmtE', 'pending', NULL, 'Admin', 'cuenca@gmail.com', '0923123421', 'qwe', ''),
(34, 1, 39.00, 'pending', '2025-12-04 10:45:29', 'pi_AzgZE4bJ9PoVWYS52v5DfYsM', 'pending', NULL, 'Admin', 'cuenca@gmail.com', '0923123421', 'qwe', ''),
(35, 1, 39.00, 'pending', '2025-12-04 10:47:35', 'pi_5LmvDmqGuMaPC2QdA7bf6F4i', 'pending', NULL, 'Admin', 'admin@shop.com', '0923123421', 'qwe', 'qwe'),
(36, 1, 39.00, 'pending', '2025-12-04 10:49:43', 'pi_Ku3PSVE2vvxGRbdXeffXxB5n', 'pending', NULL, 'Admin', 'admin@shop.com', '0923123421', 'qwe', ''),
(37, 1, 68.00, 'completed', '2025-12-04 10:54:11', 'pi_hHSqaRN4N8iM2nNFz5uQ1h91', 'paid', NULL, 'Admin', 'admin@shop.com', '0923123421', 'asdw', ''),
(38, 1, 89.00, 'completed', '2025-12-04 10:57:34', 'pi_ZvqcrDyTBGvKtAtonyRkHViT', 'paid', NULL, 'Admin', 'reren@gmail.com', '0923123421', 'ty', ''),
(39, 1, 49.00, 'completed', '2025-12-04 11:04:17', 'pi_5LZbZHK14ofuyFPPpRcEZWWc', 'paid', NULL, 'Admin', 'reren@gmail.com', '0923123421', 'asdwe', ''),
(40, 15, 109.00, 'completed', '2025-12-04 12:02:56', 'pi_5CfJryqDiX6bNEwCEhu6JtU4', 'paid', NULL, 'michael jonard', 'jonard@shop.com', '0923123421', 'qwe', ''),
(41, 13, 109.00, 'completed', '2025-12-04 12:03:48', 'pi_2YK9MpkWLAdV8b8P9GnGznhL', 'paid', NULL, 'Rheinier Cuenca', 'rheiniercuenca554@gmail.com', '0923123421', 'asdwe', ''),
(42, 15, 39.00, 'pending', '2025-12-06 12:46:11', NULL, 'cod_pending', NULL, 'michael jonard', 'admin@shop.com', '0923123421', 'asfdwer', '');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(23, 23, 6, 1, 42.00),
(24, 23, 4, 1, 28.50),
(25, 24, 69, 1, 109.00),
(26, 25, 52, 1, 49.00),
(27, 25, 19, 1, 39.00),
(28, 25, 69, 1, 109.00),
(29, 26, 53, 1, 39.00),
(30, 27, 53, 1, 39.00),
(31, 27, 63, 1, 49.00),
(32, 27, 29, 1, 39.00),
(33, 27, 38, 1, 29.00),
(34, 27, 40, 1, 39.00),
(35, 27, 40, 1, 49.00),
(36, 28, 54, 1, 49.00),
(37, 29, 54, 1, 49.00),
(38, 29, 52, 1, 39.00),
(39, 30, 53, 1, 39.00),
(40, 31, 53, 1, 39.00),
(41, 32, 53, 1, 39.00),
(42, 33, 53, 1, 39.00),
(43, 34, 53, 1, 39.00),
(44, 35, 53, 1, 39.00),
(45, 36, 53, 1, 39.00),
(46, 37, 53, 1, 39.00),
(47, 37, 40, 1, 29.00),
(48, 38, 70, 1, 89.00),
(49, 39, 56, 1, 49.00),
(50, 40, 69, 1, 109.00),
(51, 41, 69, 1, 109.00),
(52, 42, 47, 1, 39.00);

-- --------------------------------------------------------

--
-- Table structure for table `payout_settings`
--

CREATE TABLE `payout_settings` (
  `id` int(11) NOT NULL DEFAULT 1,
  `base_pay` decimal(10,2) NOT NULL DEFAULT 30.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payout_settings`
--

INSERT INTO `payout_settings` (`id`, `base_pay`) VALUES
(1, 30.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `category` varchar(50) DEFAULT 'milktea',
  `stock` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `category`, `stock`, `image`, `status`, `created_at`) VALUES
(4, 'Cookies and Cream', 'Smooth milk tea loaded with crushed Oreo bits. Dessert in every sip!', 29.00, 'milktea', 999, '1764860256_6931a1604901a.png', 'active', '2025-11-30 01:32:34'),
(6, 'Wintermelon', 'Light, refreshing, and naturally sweet. The all-time bestseller!', 42.00, 'milktea', 0, '1764860215_6931a137bb76b.png', 'inactive', '2025-11-30 01:32:34'),
(11, 'Cucumber Fruit Tea', 'Super light and clean, like cold spa water but tastier. Ultra-refreshing on a hot day.', 29.00, 'fruittea', 999, '1764862118_6931a8a6d450b.jfif', 'active', '2025-12-03 15:50:03'),
(12, 'Kiwi Fruit Tea', 'Bright, tangy-sweet with a little tropical zing. Tastes like biting into a fresh kiwi.', 29.00, 'fruittea', 999, '1764862032_6931a8506ecc8.webp', 'active', '2025-12-03 15:50:30'),
(13, 'Green Apple Fruit Tea', 'Crisp, sour-sweet kick that wakes up your taste buds. Perfect if you love that candy-apple vibe.', 29.00, 'fruittea', 999, '1764861964_6931a80c6f377.webp', 'active', '2025-12-03 15:50:52'),
(14, 'Strawberry Fruit Tea', 'Sweet, juicy, and smells exactly like ripe strawberries. The crowd favorite!', 29.00, 'fruittea', 999, '1764861920_6931a7e09a00c.png', 'active', '2025-12-03 15:52:50'),
(15, 'Blueberry Fruit Tea', 'Rich, deep berry sweetness with a soft tart finish. Feels premium and fruity.', 29.00, 'fruittea', 999, '1764861840_6931a790ba2b5.jpg', 'active', '2025-12-03 15:53:12'),
(16, 'Watermelon Fruit Tea', 'Pure summer in a cup. Sweet, watery, and instantly cools you down.', 29.00, 'fruittea', 999, '1764862211_6931a90307bc9.webp', 'active', '2025-12-03 15:53:33'),
(17, 'Orange Fruit Tea', 'Fresh-squeezed sunshine. Sweet citrus burst with no bitter aftertaste.', 29.00, 'fruittea', 999, '1764861562_6931a67a1d2cb.jpg', 'active', '2025-12-03 15:53:59'),
(18, 'Peach Fruit Tea', 'Soft, fragrant, and naturally sweet—like eating ripe peach slices. So smooth!', 29.00, 'fruittea', 999, '1764861293_6931a56d633a1.png', 'active', '2025-12-03 15:54:26'),
(19, 'Mango Fruit Tea', 'Thick, sweet Philippine mango goodness. Tastes like mango shake but lighter and iced.', 29.00, 'fruittea', 999, '1764861442_6931a602e3e90.jpg', 'active', '2025-12-03 15:57:01'),
(20, 'Lychee Fruit Tea', 'Delicately floral and sweet, with that signature lychee perfume. Elegant and addictive.', 29.00, 'fruittea', 999, '1764861516_6931a64ca3e24.jpg', 'active', '2025-12-03 15:57:24'),
(22, 'Lemon Sparkling Soda', 'Bright, zesty lemon with fizzy bubbles that pop in your mouth. The ultimate thirst-killer!', 29.00, 'sparkling', 999, '1764862905_6931abb9630f7.webp', 'active', '2025-12-03 16:01:11'),
(23, 'Cucumber Sparkling Soda', 'Super clean and refreshing, like sparkling spa water with a cool cucumber twist.', 29.00, 'sparkling', 999, '1764862880_6931aba0ea942.webp', 'active', '2025-12-03 16:01:30'),
(24, 'Kiwi Sparkling Soda', 'Tangy-sweet kiwi meets fizzy soda—tropical, vibrant, and insanely refreshing.', 29.00, 'sparkling', 999, '1764862813_6931ab5db51e4.webp', 'active', '2025-12-03 16:01:50'),
(25, 'Green Apple Sparkling Soda', 'Crisp, sour-sweet green apple fizz that feels like biting into a cold apple.', 29.00, 'sparkling', 999, '1764862790_6931ab46f359b.webp', 'active', '2025-12-03 16:02:07'),
(27, 'Blueberry Sparkling Soda', 'Rich, jammy blueberry sweetness dancing with sparkling fizz. So satisfying.', 29.00, 'sparkling', 999, '1764862724_6931ab04e63fc.webp', 'active', '2025-12-03 16:02:41'),
(28, 'Watermelon Sparkling Soda', 'Pure summer vibes—sweet, light watermelon with effervescent bubbles.', 29.00, 'sparkling', 999, '1764862672_6931aad0d9d8c.webp', 'active', '2025-12-03 16:02:57'),
(29, 'Orange Sparkling Soda', 'Fresh-squeezed orange brightness in every fizzy sip. Sunshine in a cup!', 29.00, 'sparkling', 999, '1764862608_6931aa901aade.webp', 'active', '2025-12-03 16:03:14'),
(30, 'Peach Sparkling Soda', 'Soft, fragrant peach flavor with gentle carbonation—smooth and dreamy.', 29.00, 'sparkling', 999, '1764862545_6931aa5134322.webp', 'active', '2025-12-03 16:03:28'),
(31, 'Mango Sparkling Soda', 'Ripe Philippine mango sweetness + bubbly sparkle. Tastes like mango float, but lighter!', 29.00, 'sparkling', 999, '1764862633_6931aaa97f9ff.webp', 'active', '2025-12-03 16:03:44'),
(33, 'Passion Fruit Sparkling Soda', 'Bold, tangy passion fruit punch with popping seeds and intense fizz. The most exciting one!', 29.00, 'sparkling', 999, '1764862265_6931a939f1a1d.webp', 'active', '2025-12-03 16:04:15'),
(34, 'Java Chips', 'Rich coffee milkshake loaded with crunchy chocolate chips. Your caffeine fix in dessert form!', 69.00, 'milkshake', 999, '1764861025_6931a46142270.jfif', 'active', '2025-12-03 16:07:06'),
(35, 'Oreo Cream', 'Classic Oreo cookies blended into smooth vanilla cream. Every sip has that satisfying cookie crunch.', 69.00, 'milkshake', 999, '1764860922_6931a3fa5c82b.jfif', 'active', '2025-12-03 16:07:22'),
(36, 'Rocky Road', 'Chocolate milkshake packed with marshmallows, nuts, and chocolate bits—heaven for chocolate lovers!', 69.00, 'milkshake', 999, '1764860858_6931a3ba54644.jpg', 'active', '2025-12-03 16:07:38'),
(37, 'Strawberry Cream', 'Sweet, fresh strawberry swirled into creamy vanilla ice. Tastes like strawberry ice cream in a cup!', 69.00, 'milkshake', 999, '1764860731_6931a33b297c4.jpg', 'active', '2025-12-03 16:07:56'),
(38, 'Blueberry Cream', 'Tangy-sweet blueberry blended with rich cream. Bright, fruity, and ultra-smooth.', 69.00, 'milkshake', 999, '1764860632_6931a2d89022d.avif', 'active', '2025-12-03 16:08:17'),
(39, 'Black Forest', 'Decadent dark chocolate + cherry hints + whipped cream on top. Just like the cake, but drinkable!', 69.00, 'milkshake', 999, '1764860548_6931a284c20a3.png', 'active', '2025-12-03 16:08:32'),
(40, 'Matcha Cream', 'Premium Japanese matcha blended with sweet cream. Earthy, creamy, and perfectly balanced.', 69.00, 'milkshake', 999, '1764860484_6931a244741a3.png', 'active', '2025-12-03 16:08:45'),
(41, 'Mango Graham', 'Ripe Philippine mango + crushed graham crackers + creamy base. Tastes exactly like mango graham float!', 69.00, 'milkshake', 999, '1764860360_6931a1c8a355d.png', 'active', '2025-12-03 16:08:58'),
(43, 'Dark Choco', 'Rich, velvety dark chocolate milk tea. Pure chocolate heaven.', 29.00, 'milktea', 999, '1764860187_6931a11bc6f5b.png', 'active', '2025-12-03 16:12:22'),
(44, 'Red Velvet', 'Sweet cream cheese flavor with a hint of cocoa—like drinking red velvet cake!', 29.00, 'milktea', 999, '1764860133_6931a0e5bae9e.png', 'active', '2025-12-03 16:12:36'),
(45, 'Okinawa', 'Deep roasted brown sugar milk tea. Caramel-like, super addictive.', 29.00, 'milktea', 999, '1764860086_6931a0b60feb4.png', 'active', '2025-12-03 16:12:50'),
(47, 'Brown Sugar', 'Freshly torched brown sugar syrup with creamy milk. Tiger stripes guaranteed.', 29.00, 'milktea', 998, '1764860059_6931a09b7291f.jpg', 'active', '2025-12-03 16:13:20'),
(48, 'Hazelnut', 'Nutty, fragrant hazelnut swirled into fresh milk tea. Smells amazing!', 29.00, 'milktea', 999, '1764859928_6931a01843550.png', 'active', '2025-12-03 16:13:34'),
(49, 'Black Forest', 'Dark chocolate + cherry hints in milk tea. Decadent and delicious.', 29.00, 'milktea', 999, '1764859903_69319fff9e63a.png', 'active', '2025-12-03 16:13:46'),
(50, 'Taro', 'Creamy purple taro with that signature sweet, earthy taste. So smooth!', 29.00, 'milktea', 999, '1764859881_69319fe959720.png', 'active', '2025-12-03 16:13:56'),
(51, 'Hokkaido', 'Rich Japanese caramel milk tea—sweet, buttery, and luxurious.', 29.00, 'milktea', 999, '1764859850_69319fca8f7c4.png', 'active', '2025-12-03 16:14:08'),
(52, 'Chocolate', 'Classic chocolate milk tea. Perfect for chocolate lovers.', 29.00, 'milktea', 999, '1764859819_69319fab0baa2.png', 'active', '2025-12-03 16:14:17'),
(53, 'Matcha', 'Premium green matcha with fresh milk. Earthy, creamy, and refreshing.', 29.00, 'milktea', 999, '1764859796_69319f94306f1.png', 'active', '2025-12-03 16:14:31'),
(54, 'Candy', 'Fun, sweet cotton-candy flavor that brings back childhood memories!', 29.00, 'milktea', 999, '1764859749_69319f65258fe.png', 'active', '2025-12-03 16:14:45'),
(55, 'Americano (Black Coffee)', 'Strong and bold classic coffee', 29.00, 'coffee', 999, '1764863123_6931ac9379db1.webp', 'active', '2025-12-03 16:15:13'),
(56, 'Latte (Milk and Coffee)', 'Smooth espresso with steamed milk', 29.00, 'coffee', 998, '1764863069_6931ac5db3468.webp', 'active', '2025-12-03 16:15:29'),
(57, 'Caramel Macchiato', 'Espresso + milk + caramel drizzle', 29.00, 'coffee', 999, '1764863031_6931ac37c8554.webp', 'active', '2025-12-03 16:15:44'),
(58, 'White Chocolate', 'Sweet white chocolate mocha', 29.00, 'coffee', 999, '1764862999_6931ac176f36d.webp', 'active', '2025-12-03 16:15:58'),
(60, 'Salted Caramel', 'Sweet-salty caramel coffee bliss', 29.00, 'coffee', 999, '1764862971_6931abfbdc2d4.webp', 'active', '2025-12-03 16:16:23'),
(61, 'Hamburger', 'Juicy burger patty with fresh lettuce and creamy dressing.', 49.00, 'food', 999, '1764863591_6931ae67f24e1.jfif', 'active', '2025-12-03 16:33:13'),
(62, 'Overload hotdog sandwich', 'Tender, juicy hotdog topped with lots of cheese and sauce.', 49.00, 'food', 999, '1764863548_6931ae3c891a0.jfif', 'active', '2025-12-03 16:33:34'),
(63, 'Ham & cheese sandwich', 'Classic ham and melted cheese with fresh greens.', 49.00, 'food', 999, '1764863505_6931ae112be21.webp', 'active', '2025-12-03 16:33:49'),
(64, 'Chicken / tuna sandwich', 'Choice of chicken or tuna with fresh lettuce and mayo.', 49.00, 'food', 999, '1764863451_6931addb10b7a.jpg', 'active', '2025-12-03 16:34:04'),
(65, 'Taco', 'Crispy taco shell filled with tasty meat and cheese.', 49.00, 'food', 999, '1764863408_6931adb001a5e.jfif', 'active', '2025-12-03 16:34:36'),
(66, 'Pork empanada – 3 pcs', 'Golden, crispy pastry stuffed with seasoned pork.', 69.00, 'food', 999, '1764863369_6931ad899b5ae.jfif', 'active', '2025-12-03 16:34:58'),
(67, 'Overload Hungarian sausage', 'Big, smoky sausage topped with cheese and sauce.', 69.00, 'food', 999, '1764863292_6931ad3cd48a9.jfif', 'active', '2025-12-03 16:35:12'),
(68, 'French fries', 'Crispy fries with your choice of BBQ, cheese, sour and cream.', 89.00, 'food', 999, '1764863263_6931ad1f5b5e3.jfif', 'active', '2025-12-03 16:35:32'),
(69, 'Cheesy fries', 'Fries loaded with rich melted cheese on top.', 109.00, 'food', 997, '1764863190_6931acd6a34cb.jpg', 'active', '2025-12-03 16:35:46'),
(70, 'Fav shots – 10 pcs', 'Bite-sized snacks, crispy outside and soft inside.', 89.00, 'food', 999, '1764863632_6931ae907f4f9.jfif', 'active', '2025-12-03 16:36:04');

-- --------------------------------------------------------

--
-- Table structure for table `rider_earnings`
--

CREATE TABLE `rider_earnings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `rider_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','paid') NOT NULL DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rider_earnings`
--

INSERT INTO `rider_earnings` (`id`, `rider_id`, `order_id`, `total`, `status`, `created_at`) VALUES
(1, 1, 1001, 35.00, 'paid', '2025-12-04 17:50:18'),
(2, 1, 1002, 45.50, 'paid', '2025-12-04 17:50:18'),
(3, 1, 29, 50.00, 'pending', '2025-12-04 18:30:27'),
(4, 1, 37, 50.00, 'pending', '2025-12-04 18:54:49'),
(5, 1, 38, 50.00, 'pending', '2025-12-04 18:58:11'),
(6, 1, 39, 50.00, 'pending', '2025-12-04 19:04:45'),
(7, 13, 40, 50.00, 'pending', '2025-12-04 21:13:36'),
(8, 13, 12, 50.00, 'pending', '2025-12-06 20:50:13'),
(9, 1, 16, 50.00, 'pending', '2025-12-06 20:54:46');

-- --------------------------------------------------------

--
-- Table structure for table `rider_logs`
--

CREATE TABLE `rider_logs` (
  `id` int(11) NOT NULL,
  `rider_id` int(11) NOT NULL,
  `log_type` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rider_logs`
--

INSERT INTO `rider_logs` (`id`, `rider_id`, `log_type`, `description`, `created_at`) VALUES
(1, 1, 'accepted_delivery', 'Accepted delivery ID 1', '2025-12-02 21:47:58'),
(2, 1, 'picked_up', 'Picked up delivery ID 1', '2025-12-02 21:48:03'),
(3, 1, 'uploaded_proof', 'Uploaded proof for delivery ID 1', '2025-12-02 21:48:32'),
(4, 1, 'delivery_verified', 'Admin verified delivery ID 1 via dashboard', '2025-12-02 22:02:26'),
(5, 1, 'accepted_delivery', 'Accepted delivery ID 2', '2025-12-03 20:23:16'),
(6, 1, 'picked_up', 'Picked up delivery ID 2', '2025-12-03 20:23:30'),
(7, 1, 'uploaded_proof', 'Uploaded proof for delivery ID 2', '2025-12-03 20:23:56'),
(8, 1, 'delivery_verified', 'Admin verified delivery ID 2 via dashboard', '2025-12-03 20:24:24'),
(9, 7, 'accepted_delivery', 'Accepted delivery ID 3', '2025-12-04 18:17:39'),
(10, 7, 'accepted_delivery', 'Accepted delivery ID 4', '2025-12-04 18:17:42'),
(11, 7, 'picked_up', 'Picked up delivery ID 3', '2025-12-04 18:17:43'),
(12, 7, 'picked_up', 'Picked up delivery ID 4', '2025-12-04 18:17:45'),
(13, 7, 'uploaded_proof', 'Uploaded proof for delivery ID 3', '2025-12-04 18:17:55'),
(14, 1, 'accepted_delivery', 'Accepted delivery ID 5', '2025-12-04 18:21:53'),
(15, 1, 'picked_up', 'Picked up delivery ID 5', '2025-12-04 18:21:56'),
(16, 1, 'uploaded_proof', 'Uploaded proof for delivery ID 5', '2025-12-04 18:22:00'),
(17, 1, 'accepted_delivery', 'Accepted delivery ID 6', '2025-12-04 18:27:54'),
(18, 1, 'picked_up', 'Picked up delivery ID 6', '2025-12-04 18:27:56'),
(19, 1, 'uploaded_proof', 'Uploaded proof for delivery ID 6', '2025-12-04 18:28:00'),
(20, 1, 'accepted_delivery', 'Accepted delivery ID 7', '2025-12-04 18:30:17'),
(21, 1, 'picked_up', 'Picked up delivery ID 7', '2025-12-04 18:30:19'),
(22, 1, 'uploaded_proof', 'Uploaded proof for delivery ID 7', '2025-12-04 18:30:24'),
(23, 1, 'delivery_verified', 'Admin verified delivery ID 7 via dashboard', '2025-12-04 18:30:27'),
(24, 1, 'accepted_delivery', 'Accepted delivery ID 8', '2025-12-04 18:54:34'),
(25, 1, 'picked_up', 'Picked up delivery ID 8', '2025-12-04 18:54:35'),
(26, 1, 'uploaded_proof', 'Uploaded proof for delivery ID 8', '2025-12-04 18:54:43'),
(27, 1, 'delivery_verified', 'Admin verified delivery ID 8 via dashboard', '2025-12-04 18:54:49'),
(28, 1, 'accepted_delivery', 'Accepted delivery ID 9', '2025-12-04 18:57:48'),
(29, 1, 'picked_up', 'Picked up delivery ID 9', '2025-12-04 18:57:54'),
(30, 1, 'uploaded_proof', 'Uploaded proof for delivery ID 9', '2025-12-04 18:58:01'),
(31, 1, 'delivery_verified', 'Admin verified delivery ID 9 via dashboard', '2025-12-04 18:58:11'),
(32, 1, 'accepted_delivery', 'Accepted delivery ID 10', '2025-12-04 19:04:36'),
(33, 1, 'picked_up', 'Picked up delivery ID 10', '2025-12-04 19:04:37'),
(34, 1, 'uploaded_proof', 'Uploaded proof for delivery ID 10', '2025-12-04 19:04:41'),
(35, 1, 'delivery_verified', 'Admin verified delivery ID 10 via dashboard', '2025-12-04 19:04:45'),
(36, 13, 'accepted_delivery', 'Accepted delivery ID 11', '2025-12-04 20:04:03'),
(37, 13, 'accepted_delivery', 'Accepted delivery ID 12', '2025-12-04 20:04:04'),
(38, 13, 'picked_up', 'Picked up delivery ID 11', '2025-12-04 20:04:05'),
(39, 13, 'picked_up', 'Picked up delivery ID 12', '2025-12-04 20:04:07'),
(40, 13, 'uploaded_proof', 'Uploaded proof for delivery ID 11', '2025-12-04 20:04:15'),
(41, 13, 'picked_up', 'Picked up delivery ID 12', '2025-12-04 20:14:12'),
(42, 13, 'picked_up', 'Picked up delivery ID 12', '2025-12-04 20:17:10'),
(43, 13, 'delivery_verified', 'Admin verified delivery ID 11 via dashboard', '2025-12-04 21:13:36'),
(44, 13, 'uploaded_proof', 'Uploaded proof for delivery ID 12', '2025-12-06 20:49:55'),
(45, 13, 'delivery_verified', 'Admin verified delivery ID 12 via orders page', '2025-12-06 20:50:13'),
(46, 1, 'accepted_delivery', 'Accepted delivery ID 16', '2025-12-06 20:54:23'),
(47, 1, 'picked_up', 'Picked up delivery ID 16', '2025-12-06 20:54:27'),
(48, 1, 'uploaded_proof', 'Uploaded proof for delivery ID 16', '2025-12-06 20:54:33'),
(49, 1, 'delivery_verified', 'Admin verified delivery ID 16 via orders page', '2025-12-06 20:54:46');

-- --------------------------------------------------------

--
-- Table structure for table `rider_status`
--

CREATE TABLE `rider_status` (
  `rider_id` int(11) NOT NULL,
  `status` enum('offline','available','on_delivery','suspended') NOT NULL DEFAULT 'offline',
  `last_update` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rider_status`
--

INSERT INTO `rider_status` (`rider_id`, `status`, `last_update`) VALUES
(1, 'available', '2025-12-06 20:54:46'),
(7, 'on_delivery', '2025-12-04 18:17:42'),
(13, 'available', '2025-12-06 20:50:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `fb_id` varchar(255) DEFAULT NULL,
  `role` enum('customer','admin','rider') NOT NULL DEFAULT 'customer',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `fb_id`, `role`, `created_at`) VALUES
(1, 'Admin', 'admin@shop.com', NULL, '$2y$10$O4BqyoJDDakmbWDOefEP..dnVXqPa/VRStPVgWBXgvnWkZdgpmmGq', NULL, 'admin', '2025-11-30 01:32:34'),
(7, 'Rheinier Cuenca', 'cuencarenren@gmail.com', NULL, '', NULL, 'rider', '2025-11-30 11:57:16'),
(12, 'Rheinier Cuenca', 'rheiniercuenca2@gmail.com', NULL, '', NULL, 'rider', '2025-12-04 09:34:16'),
(13, 'Rheinier Cuenca', 'rheiniercuenca554@gmail.com', NULL, '', NULL, 'rider', '2025-12-04 09:39:07'),
(14, 'Test Customer', 'test@example.com', NULL, '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NULL, 'rider', '2025-12-04 09:49:39'),
(15, 'michael jonard', 'jonard@shop.com', NULL, '$2y$10$HpqGFkTgt/DDtH30NjbRFOtav26GtHIGzKFkeQGti/PlK2KWmmKB.', NULL, 'customer', '2025-12-04 11:16:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `deliveries`
--
ALTER TABLE `deliveries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rider_id` (`rider_id`);

--
-- Indexes for table `delivery_proofs`
--
ALTER TABLE `delivery_proofs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `delivery_id` (`delivery_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `payout_settings`
--
ALTER TABLE `payout_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rider_earnings`
--
ALTER TABLE `rider_earnings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_rider` (`rider_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_order` (`order_id`);

--
-- Indexes for table `rider_logs`
--
ALTER TABLE `rider_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rider_id` (`rider_id`);

--
-- Indexes for table `rider_status`
--
ALTER TABLE `rider_status`
  ADD PRIMARY KEY (`rider_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `fb_id` (`fb_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `deliveries`
--
ALTER TABLE `deliveries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `delivery_proofs`
--
ALTER TABLE `delivery_proofs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `rider_earnings`
--
ALTER TABLE `rider_earnings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `rider_logs`
--
ALTER TABLE `rider_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `deliveries`
--
ALTER TABLE `deliveries`
  ADD CONSTRAINT `deliveries_ibfk_1` FOREIGN KEY (`rider_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `delivery_proofs`
--
ALTER TABLE `delivery_proofs`
  ADD CONSTRAINT `delivery_proofs_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `rider_logs`
--
ALTER TABLE `rider_logs`
  ADD CONSTRAINT `rider_logs_ibfk_1` FOREIGN KEY (`rider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
