<?php
$page_title = "Menu – Cheeze Tea Alaminos";

require 'includes/db.php';
require 'includes/header.php';
require 'includes/navbar.php';

/* Safe query */
try {
    $stmt = $pdo->query("SELECT id, name, price, image, category FROM products ORDER BY id DESC");
} catch (PDOException $e) {
    $stmt = $pdo->query("SELECT id, name, price, image FROM products ORDER BY id DESC");
}
// Support simple search via ?q=term
$q = trim($_GET['q'] ?? '');
if ($q !== '') {
    $search = '%' . $q . '%';
    $stmt = $pdo->prepare("SELECT id, name, price, image, category FROM products WHERE name LIKE :q OR category LIKE :q ORDER BY id DESC");
    $stmt->execute([':q' => $search]);
    $all_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $all_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/* Enhanced Categories with Beautiful Icons */
$categories = [
    'milktea' => [
        'name' => 'Cheese Milk Tea',
        'icon' => '🧋',
        'emoji' => '🧀',
        'gradient' => 'from-amber-400 via-orange-400 to-amber-500',
        'bg' => 'bg-gradient-to-br from-amber-50 to-orange-50',
        'description' => 'Creamy, dreamy perfection in every sip'
    ],
    'milkshake' => [
        'name' => 'Milkshakes',
        'icon' => '🥤',
        'emoji' => '🍦',
        'gradient' => 'from-pink-400 via-rose-400 to-pink-500',
        'bg' => 'bg-gradient-to-br from-pink-50 to-rose-50',
        'description' => 'Thick, indulgent shakes that satisfy'
    ],
    'fruittea' => [
        'name' => 'Fresh Fruit Tea',
        'icon' => '🍹',
        'emoji' => '🍓',
        'gradient' => 'from-green-400 via-emerald-400 to-green-500',
        'bg' => 'bg-gradient-to-br from-green-50 to-emerald-50',
        'description' => 'Refreshing fruity goodness, naturally sweet'
    ],
    'sparkling' => [
        'name' => 'Sparkling Soda',
        'icon' => '✨',
        'emoji' => '💫',
        'gradient' => 'from-blue-400 via-cyan-400 to-blue-500',
        'bg' => 'bg-gradient-to-br from-blue-50 to-cyan-50',
        'description' => 'Fizzy, fun, and full of flavor'
    ],
    'coffee' => [
        'name' => 'Premium Coffee',
        'icon' => '☕',
        'emoji' => '☕',
        'gradient' => 'from-amber-600 via-yellow-600 to-amber-700',
        'bg' => 'bg-gradient-to-br from-amber-50 to-yellow-50',
        'description' => 'Bold brews for coffee connoisseurs'
    ],
    'food' => [
        'name' => 'Snacks & Treats',
        'icon' => '🍰',
        'emoji' => '🍪',
        'gradient' => 'from-purple-400 via-indigo-400 to-purple-500',
        'bg' => 'bg-gradient-to-br from-purple-50 to-indigo-50',
        'description' => 'Perfect pairings for your drinks'
    ]
];

/* Group products */
$grouped = [];
foreach ($all_products as $p) {
    $cat = 'milktea';
    if (!empty($p['category'])) {
        $candidate = strtolower(trim($p['category']));
        if (isset($categories[$candidate])) {
            $cat = $candidate;
        }
    }
    $grouped[$cat][] = $p;
}
?>

<style>
    /* Animated Gradient Background */
    @keyframes gradient-shift {

        0%,
        100% {
            background-position: 0% 50%;
        }

        50% {
            background-position: 100% 50%;
        }
    }

    /* Floating Bubbles */
    @keyframes float {

        0%,
        100% {
            transform: translateY(0) translateX(0) scale(1);
            opacity: 0.6;
        }

        25% {
            transform: translateY(-30px) translateX(15px) scale(1.1);
            opacity: 0.8;
        }

        50% {
            transform: translateY(-60px) translateX(-15px) scale(0.9);
            opacity: 0.7;
        }

        75% {
            transform: translateY(-30px) translateX(10px) scale(1.05);
            opacity: 0.9;
        }
    }

    /* Bubble Pop Animation */
    @keyframes bubble-pop {
        0% {
            transform: scale(0);
            opacity: 0;
        }

        50% {
            transform: scale(1.2);
            opacity: 1;
        }

        100% {
            transform: scale(1);
            opacity: 1;
        }
    }

    /* Premium Card Hover - More Dynamic */
    .product-card {
        transition: all 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
        position: relative;
        overflow: hidden;
        transform-style: preserve-3d;
    }

    .product-card::before {
        content: '';
        position: absolute;
        top: -2px;
        left: -2px;
        right: -2px;
        bottom: -2px;
        background: linear-gradient(45deg, #f59e0b, #f97316, #fbbf24, #f59e0b);
        background-size: 400% 400%;
        border-radius: 1.75rem;
        z-index: -1;
        opacity: 0;
        transition: opacity 0.6s;
        animation: gradient-shift 3s ease infinite;
    }

    .product-card:hover::before {
        opacity: 1;
    }

    .product-card:hover {
        transform: translateY(-20px) scale(1.03) rotateX(2deg);
        box-shadow: 0 40px 80px rgba(245, 158, 11, 0.3);
    }

    /* Image Zoom & Tilt */
    .product-image-wrapper {
        position: relative;
        overflow: hidden;
        border-radius: 1.5rem 1.5rem 0 0;
    }

    .product-card img {
        transition: transform 0.8s cubic-bezier(0.34, 1.56, 0.64, 1);
    }

    .product-card:hover img {
        transform: scale(1.2) rotate(3deg);
    }

    /* Shimmer Effect on Image */
    @keyframes shimmer {
        0% {
            background-position: -200% 0;
        }

        100% {
            background-position: 200% 0;
        }
    }

    .image-shimmer::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
        background-size: 200% 100%;
        opacity: 0;
        transition: opacity 0.3s;
    }

    .product-card:hover .image-shimmer::after {
        opacity: 1;
        animation: shimmer 1.5s infinite;
    }

    /* Category Tab - More Interactive */
    .tab-btn {
        position: relative;
        transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
        transform-origin: center;
    }

    .tab-btn::before {
        content: '';
        position: absolute;
        inset: -2px;
        border-radius: 1rem;
        background: linear-gradient(45deg, transparent, rgba(245, 158, 11, 0.3), transparent);
        opacity: 0;
        transition: opacity 0.4s;
    }

    .tab-btn:hover::before {
        opacity: 1;
    }

    .tab-btn.active {
        transform: scale(1.1);
        box-shadow: 0 10px 30px rgba(245, 158, 11, 0.4);
    }

    .tab-btn:hover {
        transform: translateY(-3px) scale(1.05);
    }

    /* Price Badge - 3D Effect */
    .price-badge {
        background: linear-gradient(135deg, #f59e0b 0%, #f97316 100%);
        box-shadow: 0 8px 16px rgba(245, 158, 11, 0.4),
            inset 0 -2px 8px rgba(0, 0, 0, 0.2),
            inset 0 2px 8px rgba(255, 255, 255, 0.3);
        position: relative;
        overflow: hidden;
    }

    .price-badge::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.5), transparent);
        transition: left 0.5s;
    }

    .product-card:hover .price-badge::before {
        left: 100%;
    }

    /* Button - Liquid Effect */
    .btn-liquid {
        position: relative;
        overflow: hidden;
        transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
    }

    .btn-liquid::before {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 0;
        height: 0;
        background: rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        transform: translate(-50%, -50%);
        transition: width 0.6s, height 0.6s;
    }

    .btn-liquid:hover::before {
        width: 400px;
        height: 400px;
    }

    .btn-liquid:hover {
        transform: scale(1.05);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    }

    /* Cart Button Bounce */
    @keyframes cart-bounce {

        0%,
        100% {
            transform: scale(1);
        }

        50% {
            transform: scale(1.2);
        }
    }

    .cart-btn:active {
        animation: cart-bounce 0.3s ease;
    }

    /* Emoji Float */
    @keyframes emoji-float {

        0%,
        100% {
            transform: translateY(0) rotate(0deg);
        }

        25% {
            transform: translateY(-10px) rotate(-5deg);
        }

        75% {
            transform: translateY(-5px) rotate(5deg);
        }
    }

    .emoji-float {
        animation: emoji-float 3s ease-in-out infinite;
        display: inline-block;
    }

    /* Staggered Fade In */
    .fade-in-up {
        opacity: 0;
        transform: translateY(40px);
        animation: fadeInUp 0.8s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
    }

    @keyframes fadeInUp {
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* Search Bar Glow */
    .search-glow:focus {
        box-shadow: 0 0 0 4px rgba(245, 158, 11, 0.2),
            0 8px 24px rgba(245, 158, 11, 0.3);
    }

    /* Category Header Parallax */
    .category-header {
        transition: transform 0.3s ease-out;
    }

    /* Pulsing Badge */
    @keyframes pulse-badge {

        0%,
        100% {
            transform: scale(1);
            box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.7);
        }

        50% {
            transform: scale(1.05);
            box-shadow: 0 0 0 10px rgba(245, 158, 11, 0);
        }
    }

    .badge-pulse {
        animation: pulse-badge 2s infinite;
    }

    /* Scroll Reveal */
    .reveal {
        opacity: 0;
        transform: translateY(30px);
        transition: all 0.8s cubic-bezier(0.34, 1.56, 0.64, 1);
    }

    .reveal.active {
        opacity: 1;
        transform: translateY(0);
    }

    /* Sticky Nav Shadow */
    .sticky-shadow {
        transition: box-shadow 0.3s ease;
    }

    .sticky-shadow.scrolled {
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
    }

    /* Enhanced Tooltip */
    .tooltip {
        position: relative;
    }

    .tooltip::after {
        content: attr(data-tooltip);
        position: absolute;
        bottom: 100%;
        left: 50%;
        transform: translateX(-50%) translateY(-5px);
        background: rgba(0, 0, 0, 0.9);
        color: white;
        padding: 8px 12px;
        border-radius: 8px;
        white-space: nowrap;
        opacity: 0;
        pointer-events: none;
        transition: all 0.3s;
        font-size: 14px;
    }

    .tooltip:hover::after {
        opacity: 1;
        transform: translateX(-50%) translateY(-10px);
    }
</style>

<!-- Enhanced Animated Background -->
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <div class="absolute inset-0 bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50"></div>

    <!-- Larger decorative bubbles -->
    <?php for ($i = 1; $i <= 30; $i++):
        $s = rand(30, 80);
        $d = 15 + rand(0, 25);
        $del = $i * 0.5;
        $l = rand(-10, 110);
        $t = rand(-10, 110);
        $colors = ['from-amber-300/20 to-orange-300/20', 'from-yellow-300/20 to-amber-300/20', 'from-orange-300/20 to-yellow-300/20'];
        $color = $colors[array_rand($colors)];
        ?>
        <div style="position:absolute; left:<?= $l ?>%; top:<?= $t ?>%; animation-delay:<?= $del ?>s;">
            <div class="rounded-full bg-gradient-to-br <?= $color ?> backdrop-blur-sm"
                style="width:<?= $s ?>px; height:<?= $s ?>px; animation: float <?= $d ?>s ease-in-out infinite;">
            </div>
        </div>
    <?php endfor; ?>

    <!-- Floating emoji decorations -->
    <div class="absolute top-20 left-10 text-6xl opacity-10 emoji-float" style="animation-delay: 0s;">🧋</div>
    <div class="absolute top-40 right-20 text-5xl opacity-10 emoji-float" style="animation-delay: 1s;">🍓</div>
    <div class="absolute bottom-40 left-20 text-7xl opacity-10 emoji-float" style="animation-delay: 2s;">☕</div>
    <div class="absolute bottom-20 right-10 text-6xl opacity-10 emoji-float" style="animation-delay: 1.5s;">🥤</div>
</div>

<!-- HERO SECTION - Enhanced -->
<section class="py-32 text-center relative z-10 overflow-hidden">
    <div class="max-w-6xl mx-auto px-6">
        <!-- Animated emoji with bubble pop -->
        <div class="mb-8 relative" data-aos="zoom-in">
            <span class="text-9xl inline-block transform hover:scale-125 transition-transform duration-500 emoji-float"
                style="filter: drop-shadow(0 10px 30px rgba(245, 158, 11, 0.3));">
                🧀
            </span>
            <div class="absolute inset-0 animate-ping opacity-20">
                <span class="text-9xl">🧀</span>
            </div>
        </div>

        <!-- Main heading with animated gradient -->
        <h1 class="text-7xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-600 via-orange-500 to-amber-600 mb-6 leading-tight"
            data-aos="fade-up"
            style="background-size: 200% auto; animation: gradient-shift 4s ease infinite; filter: drop-shadow(0 4px 8px rgba(245, 158, 11, 0.2));">
            Our Full Menu
        </h1>

        <!-- Subheading with sparkle effect -->
        <p class="text-3xl md:text-4xl text-amber-800 font-bold mb-6 relative inline-block" data-aos="fade-up"
            data-aos-delay="200">
            <span class="relative z-10">Choose your kind of happiness</span>
            <span class="absolute -top-2 -right-8 text-4xl emoji-float" style="animation-delay: 0.5s;">✨</span>
            <span class="absolute -bottom-2 -left-8 text-3xl emoji-float" style="animation-delay: 1s;">💛</span>
        </p>

        <!-- Description -->
        <p class="text-xl md:text-2xl text-amber-700 max-w-2xl mx-auto" data-aos="fade-up" data-aos-delay="300">
            Handcrafted with <span class="font-bold text-orange-600">premium ingredients</span>, made <span
                class="font-bold text-orange-600">fresh daily</span> just for you
        </p>

        <!-- Scroll indicator -->
        <div class="mt-12 animate-bounce" data-aos="fade-up" data-aos-delay="500">
            <svg class="w-8 h-8 mx-auto text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M19 14l-7 7m0 0l-7-7m7 7V3">
                </path>
            </svg>
        </div>
    </div>
</section>

<!-- ENHANCED CATEGORY TABS - Sticky with blur -->
<div class="sticky top-0 z-50 bg-white/90 backdrop-blur-xl border-b-2 border-amber-200 shadow-lg sticky-shadow"
    id="categoryNav">
    <div class="max-w-7xl mx-auto px-6 py-6">

        <!-- Search Bar -->
        <form method="GET" action="products.php" class="w-full max-w-3xl mx-auto mb-6" data-aos="fade-down">
            <div class="flex items-center gap-3">
                <div class="relative flex-1">
                    <input type="search" name="q" placeholder="🔍 Search your favorite drink or snack..."
                        value="<?= htmlspecialchars($q ?? '') ?>"
                        class="search-glow w-full px-6 py-4 pl-14 border-2 border-amber-300 rounded-full focus:outline-none focus:border-amber-500 text-lg transition-all duration-300 bg-white">
                    <span class="absolute left-5 top-1/2 -translate-y-1/2 text-2xl">🔍</span>
                </div>
                <button type="submit"
                    class="btn-liquid px-8 py-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-full font-bold text-lg shadow-lg hover:shadow-xl transition-all">
                    Search
                </button>
                <?php if (!empty($q)): ?>
                    <a href="products.php"
                        class="px-6 py-4 bg-gray-200 text-gray-700 rounded-full font-semibold hover:bg-gray-300 transition-colors">
                        Clear
                    </a>
                <?php endif; ?>
            </div>
        </form>

        <!-- Category Pills -->
        <div class="flex justify-center gap-3 flex-wrap" data-aos="fade-up">
            <?php foreach ($categories as $key => $cat): ?>
                <button onclick="showCategory('<?= $key ?>')"
                    class="tab-btn <?= $key === 'milktea' ? 'active' : '' ?> group px-6 py-4 rounded-2xl text-base font-bold transition-all bg-white shadow-md hover:shadow-xl border-2 <?= $key === 'milktea' ? 'border-amber-400' : 'border-transparent' ?>"
                    data-cat="<?= $key ?>">
                    <div class="flex items-center gap-2">
                        <span class="text-3xl transform group-hover:scale-125 transition-transform duration-300">
                            <?= $cat['icon'] ?>
                        </span>
                        <span class="text-gray-800 group-hover:text-amber-700 transition-colors">
                            <?= $cat['name'] ?>
                        </span>
                    </div>
                </button>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- PRODUCTS SECTION -->
<section class="py-20 relative z-10">
    <div class="max-w-7xl mx-auto px-6">

        <?php foreach ($categories as $key => $cat):
            $products = $grouped[$key] ?? [];
            ?>

            <div id="<?= $key ?>" class="category-section <?= $key === 'milktea' ? '' : 'hidden' ?>">

                <!-- Category Header - More Dynamic -->
                <div class="category-header text-center mb-16 <?= $cat['bg'] ?> py-16 rounded-3xl shadow-2xl relative overflow-hidden"
                    data-aos="fade-down">

                    <!-- Background decoration -->
                    <div class="absolute inset-0 opacity-10">
                        <div class="absolute top-10 left-10 text-9xl"><?= $cat['emoji'] ?></div>
                        <div class="absolute bottom-10 right-10 text-9xl"><?= $cat['emoji'] ?></div>
                        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[200px] opacity-50">
                            <?= $cat['emoji'] ?>
                        </div>
                    </div>

                    <div class="relative z-10">
                        <!-- Icon -->
                        <div class="inline-block p-8 bg-white rounded-full shadow-2xl mb-6 badge-pulse">
                            <span class="text-7xl">
                                <?= $cat['icon'] ?>
                            </span>
                        </div>

                        <!-- Title -->
                        <h2 class="text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r <?= $cat['gradient'] ?> mb-4"
                            style="filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.1));">
                            <?= $cat['name'] ?>
                        </h2>

                        <!-- Description -->
                        <p class="text-2xl text-gray-700 font-semibold max-w-2xl mx-auto">
                            <?= $cat['description'] ?>
                        </p>

                        <!-- Decorative line -->
                        <div class="mt-8 flex items-center justify-center gap-4">
                            <div class="w-20 h-1 bg-gradient-to-r <?= $cat['gradient'] ?> rounded-full"></div>
                            <span class="text-3xl"><?= $cat['emoji'] ?></span>
                            <div class="w-20 h-1 bg-gradient-to-l <?= $cat['gradient'] ?> rounded-full"></div>
                        </div>
                    </div>
                </div>

                <?php if (empty($products)): ?>
                    <!-- Empty State - Enhanced -->
                    <div class="text-center py-32 bg-white/70 rounded-3xl backdrop-blur-sm shadow-xl relative overflow-hidden"
                        data-aos="zoom-in">
                        <div class="absolute inset-0 bg-gradient-to-br from-amber-50/50 to-orange-50/50"></div>
                        <div class="relative z-10">
                            <div class="mb-8">
                                <span class="text-9xl block mb-4 animate-bounce">🎉</span>
                                <div class="flex justify-center gap-4 text-6xl">
                                    <span class="emoji-float" style="animation-delay: 0s;">✨</span>
                                    <span class="emoji-float" style="animation-delay: 0.5s;">💫</span>
                                    <span class="emoji-float" style="animation-delay: 1s;">⭐</span>
                                </div>
                            </div>
                            <p class="text-4xl font-black text-amber-700 mb-6">Coming Soon!</p>
                            <p class="text-2xl text-gray-600 mb-8">Amazing new items are on the way</p>
                            <div
                                class="inline-block px-8 py-4 bg-gradient-to-r from-amber-400 to-orange-400 text-white rounded-full font-bold text-xl shadow-lg">
                                Stay Tuned 🚀
                            </div>
                        </div>
                    </div>
                <?php else: ?>

                    <!-- Products Grid -->
                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">

                        <?php foreach ($products as $i => $p):
                            $image = (!empty($p['image']) && file_exists(__DIR__ . "/uploads/" . $p['image']))
                                ? $p['image']
                                : "placeholder.jpg";
                            ?>

                            <div class="fade-in-up reveal" style="animation-delay: <?= ($i % 8) * 0.1 ?>s" data-aos="fade-up"
                                data-aos-delay="<?= ($i % 8) * 100 ?>">
                                <div
                                    class="product-card bg-white rounded-3xl shadow-xl border-2 border-amber-100 overflow-hidden flex flex-col h-full group">

                                    <!-- Product Image with enhanced overlay -->
                                    <div class="product-image-wrapper image-shimmer h-80 relative">
                                        <img src="uploads/<?= $image ?>" class="w-full h-full object-cover"
                                            alt="<?= htmlspecialchars($p['name']) ?>" loading="lazy">

                                        <!-- Gradient Overlay -->
                                        <div
                                            class="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                                        </div>

                                        <!-- Top Badge -->
                                        <div class="absolute top-4 right-4 badge-pulse">
                                            <div
                                                class="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg flex items-center gap-2">
                                                <span class="animate-pulse">⭐</span>
                                                Fresh Daily
                                            </div>
                                        </div>

                                        <!-- Quick View Button -->
                                        <div
                                            class="absolute bottom-4 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-y-4 group-hover:translate-y-0">
                                            <div class="bg-white text-amber-700 px-6 py-2 rounded-full font-bold shadow-xl text-sm">
                                                👁️ Quick View
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Product Info -->
                                    <div class="p-6 flex flex-col flex-grow bg-gradient-to-b from-white to-amber-50/30">

                                        <!-- Product Name -->
                                        <h3
                                            class="text-2xl font-black text-gray-800 mb-4 group-hover:text-amber-700 transition-colors leading-tight min-h-[60px]">
                                            <?= htmlspecialchars($p['name']) ?>
                                        </h3>

                                        <!-- Price Badge - Enhanced 3D -->
                                        <div class="mb-6">
                                            <div
                                                class="price-badge inline-flex items-center gap-2 text-white font-black text-3xl px-6 py-3 rounded-2xl shadow-xl">
                                                <span class="text-2xl">₱</span>
                                                <span><?= number_format($p['price'], 2) ?></span>
                                            </div>
                                        </div>

                                        <!-- Features/Benefits -->
                                        <div class="flex gap-2 mb-6 flex-wrap">
                                            <span class="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-semibold">
                                                ✓ Fresh
                                            </span>
                                            <span class="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">
                                                ⭐ Popular
                                            </span>
                                        </div>

                                        <!-- Action Buttons -->
                                        <div class="flex gap-3 mt-auto">
                                            <a href="view_product.php?id=<?= $p['id'] ?>"
                                                class="btn-liquid flex-1 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold py-4 rounded-2xl transition-all duration-300 shadow-lg hover:shadow-2xl text-center relative overflow-hidden group/btn">
                                                <span class="relative z-10 flex items-center justify-center gap-2">
                                                    <span>View Details</span>
                                                    <span class="group-hover/btn:translate-x-1 transition-transform">→</span>
                                                </span>
                                            </a>

                                            <form action="add_to_cart.php" method="POST" class="flex-shrink-0">
                                                <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                                                <button type="submit"
                                                    class="cart-btn btn-liquid bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white rounded-2xl w-16 h-16 font-bold shadow-lg hover:shadow-2xl transition-all duration-300 flex items-center justify-center relative overflow-hidden tooltip"
                                                    data-tooltip="Add to Cart">
                                                    <i class="fa fa-cart-plus text-2xl relative z-10"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php endforeach; ?>

                    </div>
                <?php endif; ?>
            </div>

        <?php endforeach; ?>
    </div>
</section>

<!-- Enhanced Call to Action with Parallax Effect -->
<section class="py-20 relative z-10">
    <div class="max-w-5xl mx-auto px-6">
        <div class="relative bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 rounded-3xl shadow-2xl p-16 overflow-hidden"
            data-aos="zoom-in" style="background-size: 200% auto; animation: gradient-shift 5s ease infinite;">

            <!-- Decorative elements -->
            <div class="absolute top-0 left-0 w-64 h-64 bg-white/10 rounded-full -translate-x-32 -translate-y-32"></div>
            <div class="absolute bottom-0 right-0 w-80 h-80 bg-white/10 rounded-full translate-x-40 translate-y-40">
            </div>

            <div class="relative z-10 text-center">
                <!-- Animated emoji -->
                <div class="mb-8 flex justify-center gap-4">
                    <span class="text-7xl emoji-float" style="animation-delay: 0s;">🎊</span>
                    <span class="text-7xl emoji-float" style="animation-delay: 0.5s;">✨</span>
                    <span class="text-7xl emoji-float" style="animation-delay: 1s;">💫</span>
                </div>

                <h3 class="text-5xl md:text-6xl font-black text-white mb-6 drop-shadow-lg">
                    Can't Decide?
                </h3>
                <p class="text-2xl text-white/95 mb-8 max-w-2xl mx-auto font-semibold">
                    Try our staff recommendations or create your own custom blend!
                </p>

                <!-- CTA Buttons -->
                <div class="flex flex-col sm:flex-row gap-4 justify-center">
                    <a href="#milktea" onclick="showCategory('milktea')"
                        class="btn-liquid inline-block bg-white text-amber-700 px-10 py-5 rounded-full font-black text-xl shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-300">
                        🌟 Explore Best Sellers
                    </a>
                    <a href="#"
                        class="btn-liquid inline-block bg-amber-700 text-white px-10 py-5 rounded-full font-black text-xl shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-300 border-2 border-white">
                        🎯 Surprise Me!
                    </a>
                </div>

                <!-- Social proof -->
                <div class="mt-12 flex items-center justify-center gap-8 text-white/90">
                    <div class="text-center">
                        <div class="text-3xl font-black mb-1">1000+</div>
                        <div class="text-sm font-semibold">Happy Customers</div>
                    </div>
                    <div class="w-px h-12 bg-white/30"></div>
                    <div class="text-center">
                        <div class="text-3xl font-black mb-1">50+</div>
                        <div class="text-sm font-semibold">Unique Flavors</div>
                    </div>
                    <div class="w-px h-12 bg-white/30"></div>
                    <div class="text-center">
                        <div class="text-3xl font-black mb-1">⭐ 4.9</div>
                        <div class="text-sm font-semibold">Average Rating</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Customer Reviews Snippet -->
<section class="py-16 bg-white/50 backdrop-blur-sm">
    <div class="max-w-7xl mx-auto px-6">
        <h3 class="text-4xl font-black text-center text-gray-800 mb-12" data-aos="fade-up">
            💛 What Our Customers Say
        </h3>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php
            $reviews = [
                ['name' => 'Maria S.', 'text' => 'Best cheese milk tea in town! The quality is amazing!', 'rating' => 5],
                ['name' => 'John D.', 'text' => 'Fresh ingredients, great taste. Highly recommended!', 'rating' => 5],
                ['name' => 'Sarah L.', 'text' => 'My go-to place for refreshing drinks. Love it!', 'rating' => 5]
            ];
            foreach ($reviews as $i => $review): ?>
                <div class="bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow" data-aos="fade-up"
                    data-aos-delay="<?= $i * 100 ?>">
                    <div class="flex gap-1 mb-4">
                        <?php for ($j = 0; $j < $review['rating']; $j++): ?>
                            <span class="text-2xl">⭐</span>
                        <?php endfor; ?>
                    </div>
                    <p class="text-gray-700 mb-4 text-lg italic">"<?= $review['text'] ?>"</p>
                    <p class="font-bold text-amber-700">- <?= $review['name'] ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php require 'includes/footer.php'; ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Initialize AOS
        if (typeof AOS !== 'undefined') {
            AOS.init({
                duration: 1000,
                once: true,
                offset: 100,
                easing: 'ease-out-cubic'
            });
        }

        // Sticky nav shadow on scroll
        const nav = document.getElementById('categoryNav');
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                nav.classList.add('scrolled');
            } else {
                nav.classList.remove('scrolled');
            }
        });

        // Reveal on scroll
        const reveals = document.querySelectorAll('.reveal');
        const revealObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('active');
                }
            });
        }, { threshold: 0.1 });

        reveals.forEach(reveal => revealObserver.observe(reveal));

        // Category switching with smooth animations
        window.showCategory = function (id) {
            // Smooth scroll to top of products section
            const productsSection = document.querySelector('.category-section');
            if (productsSection) {
                productsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }

            // Fade out all sections
            document.querySelectorAll('.category-section').forEach(el => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(30px)';
                setTimeout(() => {
                    el.classList.add('hidden');
                }, 400);
            });

            // Fade in target section
            setTimeout(() => {
                const target = document.getElementById(id);
                if (target) {
                    target.classList.remove('hidden');
                    setTimeout(() => {
                        target.style.opacity = '1';
                        target.style.transform = 'translateY(0)';
                    }, 50);
                }
            }, 400);

            // Update tab styles
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active', 'border-amber-400', 'shadow-xl');
                btn.classList.add('border-transparent', 'shadow-md');
            });

            const active = document.querySelector('[data-cat="' + id + '"]');
            if (active) {
                active.classList.add('active', 'border-amber-400', 'shadow-xl');
                active.classList.remove('border-transparent');
            }
        };

        // Add smooth transition to all category sections
        document.querySelectorAll('.category-section').forEach(el => {
            el.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
        });

        // Add to cart animation
        document.querySelectorAll('.cart-btn').forEach(btn => {
            btn.addEventListener('click', function (e) {
                // Create floating notification
                const notification = document.createElement('div');
                notification.textContent = '✓ Added to cart!';
                notification.className = 'fixed top-24 right-6 bg-green-500 text-white px-6 py-3 rounded-full shadow-xl font-bold z-50 animate-bounce';
                document.body.appendChild(notification);

                setTimeout(() => {
                    notification.style.opacity = '0';
                    notification.style.transform = 'translateY(-20px)';
                    notification.style.transition = 'all 0.3s ease';
                    setTimeout(() => notification.remove(), 300);
                }, 2000);
            });
        });

        // Parallax effect for category headers
        // Use header's viewport position (rect.top) so the translation is relative
        // to where the header actually is, and clamp the value to avoid large shifts.
        window.addEventListener('scroll', () => {
            document.querySelectorAll('.category-header').forEach(header => {
                // reset transform for hidden sections to avoid layout drift
                if (header.closest('.hidden')) {
                    header.style.transform = '';
                    return;
                }

                const rect = header.getBoundingClientRect();
                // position relative to center of viewport (-vh/2 .. +vh/2)
                const centerOffset = rect.top - (window.innerHeight / 2);
                // gentle parallax factor (smaller value = subtler movement)
                const factor = 0.04;
                // compute translate value and clamp to [-80px, 80px]
                let rate = Math.round(centerOffset * factor);
                rate = Math.max(Math.min(rate, 80), -80);
                header.style.transform = `translateY(${rate}px)`;
            });
        });
    });
</script>