<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/../vendor/autoload.php'; // PHPMailer

function sendEmail($to, $subject, $body)
{
    $mail = new PHPMailer(true);

    try {
        // Gmail SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        // Use the Cheeze Tea Gmail account. Set an app password in the environment variable EMAIL_PASSWORD.
        $mail->Username = 'cheezeeteaa@gmail.com';
        // Resolve password: prefer getenv, then local config file (useful for Apache/PHP), then fallback.
        $password = getenv('EMAIL_PASSWORD');
        if (empty($password)) {
            $configFile = __DIR__ . '/email_config.php';
            if (file_exists($configFile)) {
                $pw = include $configFile;
                if (is_string($pw) && $pw !== '') {
                    $password = $pw;
                }
            }
        }
        // Temporary fallback (not for production)
        $mail->Password = $password ?: 'cheeze12345';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Sender (use the same Gmail address)
        $mail->setFrom('cheezeeteaa@gmail.com', 'Cheeze Tea');

        // Recipient
        $mail->addAddress($to);

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;

        return $mail->send();
    } catch (Exception $e) {
        // Ensure log directory exists
        $logDir = __DIR__ . '/../paymongo/logs';
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0755, true);
        }
        $logFile = $logDir . '/email_errors.log';

        $message = date('Y-m-d H:i:s') . " | To: {$to} | Subject: {$subject} | Exception: " . $e->getMessage() . " | PHPMailer: " . $mail->ErrorInfo . PHP_EOL;
        // Append to log for later inspection
        @file_put_contents($logFile, $message, FILE_APPEND | LOCK_EX);

        // Also echo when running from CLI so tests show immediate feedback
        if (php_sapi_name() === 'cli') {
            echo "[EMAIL ERROR] " . $message;
        }

        return false;
    }
}
