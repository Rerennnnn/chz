<?php
// includes/security.php (neutralized)
// Security helpers were removed per user request. This file is intentionally minimal to avoid runtime errors.
// If you want a full restore, please provide the original backup or confirm which protections to reapply.
?>

function verifyCsrfToken($token = null)
{
if ($token === null) {
$token = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : (isset($_GET['csrf_token']) ? $_GET['csrf_token'] : '');
}

if (empty($token) || empty($_SESSION['csrf_token'])) {
return false;
}

return hash_equals($_SESSION['csrf_token'], $token);
}

// ===== Output Escaping =====

function escape($data, $context = 'html')
{
if ($data === null) {
return '';
}

$data = (string) $data;

switch ($context) {
case 'attr':
return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
case 'url':
return htmlspecialchars(urlencode($data), ENT_QUOTES | ENT_HTML5, 'UTF-8');
case 'js':
return htmlspecialchars(json_encode($data), ENT_QUOTES | ENT_HTML5, 'UTF-8');
case 'html':
default:
return htmlspecialchars($data, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}
}

function e($data)
{
return escape($data, 'html');
}

function eattr($data)
{
return escape($data, 'attr');
}

function eurl($data)
{
return escape($data, 'url');
}

function ejs($data)
{
return escape($data, 'js');
}

// ===== Input Validation & Sanitization =====

function validateEmail($email)
{
$email = trim($email);
if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
return $email;
}
return false;
}

function sanitizeText($text, $maxLength = 0)
{
$text = trim($text);
$text = strip_tags($text);
$text = htmlspecialchars($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');

if ($maxLength > 0 && strlen($text) > $maxLength) {
$text = substr($text, 0, $maxLength);
}

return $text;
}

function validatePhone($phone)
{
$phone = trim($phone);
if (preg_match('/^[\d\s\-\+\(\)]+$/', $phone) && strlen($phone) >= 7) {
return $phone;
}
return false;
}

function validateId($id)
{
$id = filter_var($id, FILTER_VALIDATE_INT);
return ($id !== false && $id > 0) ? $id : false;
}

function validateUrl($url)
{
$url = trim($url);
if (filter_var($url, FILTER_VALIDATE_URL)) {
return $url;
}
return false;
}

function sanitizeFloat($value)
{
return (float) filter_var(
$value,
FILTER_SANITIZE_NUMBER_FLOAT,
FILTER_FLAG_ALLOW_FRACTION | FILTER_FLAG_ALLOW_SCIENTIFIC
);
}

function sanitizeInt($value)
{
return (int) filter_var($value, FILTER_SANITIZE_NUMBER_INT);
}

// ===== Safe Database Queries =====

function buildInClause($ids, $minId = 1)
{
if (empty($ids)) {
return '';
}

$validIds = array();
foreach ($ids as $id) {
$id = (int) $id;
if ($id >= $minId) {
$validIds[] = $id;
}
}

if (empty($validIds)) {
return '';
}

return 'IN (' . implode(',', array_fill(0, count($validIds), '?')) . ')';
}

// ===== Security Headers & Session Protection =====

function setSecurityHeaders()
{
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self'
'unsafe-inline';");
}

function configureSessionSecurity()
{
// Session cookie params and start are now handled in db.php
// This function kept for backward compatibility
// Session regeneration is also handled in db.php
if (!isset($_SESSION['session_regen_time'])) {
$_SESSION['session_regen_time'] = time();
} elseif (time() - $_SESSION['session_regen_time'] > 3600) {
session_regenerate_id(true);
$_SESSION['session_regen_time'] = time();
}
}

// ===== Rate Limiting & Brute Force Protection =====

function checkRateLimit($action, $maxAttempts = 5, $windowSeconds = 300)
{
$key = 'ratelimit_' . md5($action);

if (!isset($_SESSION[$key])) {
$_SESSION[$key] = array(
'attempts' => 0,
'first_attempt' => time(),
);
}

$record = $_SESSION[$key];
$now = time();

if ($now - $record['first_attempt'] > $windowSeconds) {
$_SESSION[$key] = array(
'attempts' => 0,
'first_attempt' => $now,
);
$record = $_SESSION[$key];
}

if ($record['attempts'] >= $maxAttempts) {
return false;
}

$_SESSION[$key]['attempts']++;
return true;
}

function resetRateLimit($action)
{
$key = 'ratelimit_' . md5($action);
unset($_SESSION[$key]);
}

// ===== General Security Utilities =====

function isAjaxRequest()
{
return (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&
strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');
}

function isRequestMethod($method)
{
$method = (array) $method;
return in_array($_SERVER['REQUEST_METHOD'], $method, true);
}

function getParam($key, $default = '', $type = 'string')
{
$value = isset($_GET[$key]) ? $_GET[$key] : (isset($_POST[$key]) ? $_POST[$key] : $default);

if ($value === $default) {
return $default;
}

if ($type === 'int') {
return sanitizeInt($value);
} elseif ($type === 'float') {
return sanitizeFloat($value);
} elseif ($type === 'bool') {
return (bool) $value;
} elseif ($type === 'email') {
$validated = validateEmail($value);
return $validated ? $validated : $default;
} else {
return sanitizeText($value);
}
}