<!-- SENIOR-DEV PROFESSIONAL FOOTER -->
<footer class="bg-gradient-to-t from-amber-950 to-amber-900 text-white relative overflow-hidden" role="contentinfo"
    aria-label="Site footer">
    <!-- Subtle Golden Wave Background -->
    <div class="absolute inset-0 opacity-10">
        <svg class="w-full h-full" viewBox="0 0 1440 320" preserveAspectRatio="none">
            <path fill="#fbbf24"
                d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,112C672,96,768,96,864,112C960,128,1056,160,1152,160C1248,160,1344,128,1392,112L1440,96L1440,320L0,320Z">
            </path>
        </svg>
    </div>

    <div class="relative z-10 container mx-auto px-6 py-20">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-12 max-w-7xl mx-auto">

            <!-- Brand + Tagline -->
            <div class="md:col-span-1 animate-on-scroll" data-delay="0">
                <h2 class="text-4xl md:text-5xl font-black tracking-tight mb-4 text-white">
                    Cheeze Tea
                </h2>
                <p class="text-amber-200 text-lg md:text-xl leading-relaxed opacity-95">
                    Creamy sunshine in every cup.<br>
                    <span class="text-base md:text-lg block mt-3 text-amber-300">Alaminos, Laguna</span>
                </p>
                <div class="mt-8 flex gap-5">
                    <a href="https://www.facebook.com/profile.php?id=100076206880064"
                        class="w-12 h-12 rounded-full bg-amber-800/50 backdrop-blur-sm flex items-center justify-center hover:bg-amber-700 transition-all duration-300 hover:scale-110"
                        aria-label="Cheeze Tea on Facebook">
                        <i class="fab fa-facebook-f" aria-hidden="true"></i>
                    </a>
                    <a href="https://www.instagram.com/mfcheezetea/?hl=en" target="_blank"
                        class="w-12 h-12 rounded-full bg-amber-800/50 backdrop-blur-sm flex items-center justify-center hover:bg-pink-600 transition-all duration-300 hover:scale-110"
                        aria-label="Cheeze Tea on Instagram">
                        <i class="fab fa-instagram" aria-hidden="true"></i>
                    </a>
                    <a href="#"
                        class="w-12 h-12 rounded-full bg-amber-800/50 backdrop-blur-sm flex items-center justify-center hover:bg-black transition-all duration-300 hover:scale-110"
                        aria-label="Cheeze Tea on TikTok">
                        <i class="fab fa-tiktok" aria-hidden="true"></i>
                    </a>
                </div>
            </div>

            <!-- Quick Links -->
            <nav class="animate-on-scroll" data-delay="200" aria-label="Footer quick links">
                <h3 class="text-xl md:text-2xl font-bold mb-6 text-amber-300">Quick Links</h3>
                <ul class="space-y-3">
                    <li><a href="#creations"
                            class="text-amber-100 text-lg md:text-xl underline-offset-2 hover:underline focus:underline">Menu</a>
                    </li>
                    <li><a href="#gallery"
                            class="text-amber-100 text-lg md:text-xl underline-offset-2 hover:underline focus:underline">Gallery</a>
                    </li>
                    <li><a href="products.php"
                            class="text-amber-100 text-lg md:text-xl underline-offset-2 hover:underline focus:underline">All
                            Drinks</a></li>
                    <li><a href="#"
                            class="text-amber-100 text-lg md:text-xl underline-offset-2 hover:underline focus:underline">Promos</a>
                    </li>
                </ul>
            </nav>

            <!-- Visit Us -->
            <div class="animate-on-scroll" data-delay="400">
                <h3 class="text-xl md:text-2xl font-bold mb-6 text-amber-300">Visit Us</h3>
                <address class="not-italic space-y-4 text-amber-100">
                    <p class="flex items-center gap-3 text-lg md:text-xl">
                        <i class="fas fa-map-marker-alt text-amber-300" aria-hidden="true"></i>
                        <span class="text-amber-200">National Highway, Brgy. San Roque<br>Alaminos, Laguna</span>
                    </p>
                    <p class="flex items-center gap-3 text-lg md:text-xl">
                        <i class="fas fa-clock text-amber-300" aria-hidden="true"></i>
                        <span class="text-amber-200">Mon–Sun: 10:00 AM – 9:00 PM</span>
                    </p>
                    <p class="flex items-center gap-3 text-lg md:text-xl">
                        <i class="fas fa-phone text-amber-300" aria-hidden="true"></i>
                        <span><a href="tel:+639171234567" class="text-amber-200 underline hover:text-amber-100">+63 917
                                123 4567</a></span>
                    </p>
                </address>
            </div>

            <!-- Newsletter (Optional Future Feature) -->
            <div class="animate-on-scroll" data-delay="600">
                <h3 class="text-xl md:text-2xl font-bold mb-6 text-amber-300">Stay Cheezy</h3>
                <p class="text-amber-100 mb-4 text-lg md:text-xl">Get first dibs on new drinks & promos</p>
                <form class="flex flex-col sm:flex-row gap-3" aria-label="Subscribe to newsletter">
                    <input aria-label="Email address" type="email" placeholder="your@email.com"
                        class="px-5 py-3 rounded-full bg-amber-900/60 backdrop-blur border border-amber-700 focus:border-amber-400 focus:outline-none text-white placeholder-amber-300 text-lg md:text-base">
                    <button aria-label="Subscribe" type="submit"
                        class="px-8 py-3 bg-amber-600 hover:bg-amber-500 rounded-full font-bold transition hover:scale-105 text-lg">
                        Subscribe
                    </button>
                </form>
            </div>
        </div>

        <!-- Bottom Bar -->
        <div class="mt-16 pt-10 border-t border-amber-800/50 text-center">
            <p class="text-amber-200 text-base md:text-lg">
                © <?= date('Y') ?> Cheeze Tea Alaminos. Crafted with
                <span class="text-red-500">♥</span> & premium cheese foam.
            </p>
            <p class="text-amber-400 text-sm md:text-base mt-3 opacity-80">
                Designed & developed with love
            </p>
        </div>
    </div>

    <!-- Floating Golden Accent -->
    <div class="absolute top-10 right-10 w-64 h-64 bg-amber-600/10 rounded-full blur-3xl animate-pulse"
        aria-hidden="true"></div>
</footer>

<!-- Enhanced Footer Animation Script (add this just before </body>) -->
<script>
    // Smooth reveal with stagger effect
    document.querySelectorAll('.animate-on-scroll').forEach((el, i) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.8s cubic-bezier(0.23, 1, 0.32, 1)';

        const delay = el.getAttribute('data-delay') || 0;

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    setTimeout(() => {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }, delay);
                }
            });
        }, { threshold: 0.1 });

        observer.observe(el);
    });
</script>

<style>
    .animate-on-scroll {
        transition: all 0.9s cubic-bezier(0.23, 1, 0.32, 1);
    }
</style>