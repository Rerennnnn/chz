<?php
// riders.php - FULLY FIXED & CLEANED VERSION

require '../includes/auth.php';
requireAdmin(); // Make sure only admin can access
require '../includes/db.php'; // Connects to "ecommerce" DB

$page_title = "Manage Riders - Cheeze Tea";

$success_message = $error_message = $settings_success = $settings_error = null;

// === ENSURE payout_settings TABLE & DEFAULT ROW ===
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS payout_settings (
        id INT PRIMARY KEY DEFAULT 1,
        base_pay DECIMAL(10,2) NOT NULL DEFAULT 35.00
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("INSERT IGNORE INTO payout_settings (id, base_pay) VALUES (1, 35.00);");

    $stmt = $pdo->query("SELECT base_pay FROM payout_settings WHERE id = 1");
    $payout_settings = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['base_pay' => 35.00];
} catch (Exception $e) {
    $payout_settings = ['base_pay' => 35.00];
    $settings_error = "Payout settings error: " . $e->getMessage();
}

// === SAVE PAYOUT SETTINGS ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_payout_settings'])) {
    $base_pay = max(0, (float) ($_POST['base_pay'] ?? 0));
    try {
        $pdo->prepare("INSERT INTO payout_settings (id, base_pay) VALUES (1, ?) 
                       ON DUPLICATE KEY UPDATE base_pay = VALUES(base_pay)")
            ->execute([$base_pay]);
        $payout_settings['base_pay'] = $base_pay;
        $settings_success = "Base pay updated to ₱" . number_format($base_pay, 2);
    } catch (Exception $e) {
        $settings_error = "Failed to save payout settings.";
    }
}

// === ASSIGN USER AS RIDER ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_rider'])) {
    $user_id = (int) $_POST['user_id'];
    try {
        $stmt = $pdo->prepare("UPDATE users SET role = 'rider' WHERE id = ? AND role != 'admin'");
        $stmt->execute([$user_id]);
        if ($stmt->rowCount()) {
            header("Location: riders.php?success=assigned");
            exit;
        } else {
            $error_message = "User not found or is already an admin/rider.";
        }
    } catch (Exception $e) {
        $error_message = "Error: " . $e->getMessage();
    }
}

// === REMOVE RIDER (back to customer) ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_rider'])) {
    $rider_id = (int) $_POST['rider_id'];
    $pdo->prepare("UPDATE users SET role = 'customer' WHERE id = ? AND role = 'rider'")
        ->execute([$rider_id]);
    header("Location: riders.php?success=removed");
    exit;
}

// Success messages
if (isset($_GET['success'])) {
    $success_message = $_GET['success'] === 'assigned' ? "Rider assigned successfully!" :
        "Rider removed successfully!";
}

// === FETCH DATA ===
try {
    $users = $pdo->query("SELECT id, name, email FROM users WHERE role NOT IN ('rider', 'admin') ORDER BY name")->fetchAll();
    $riders = $pdo->query("SELECT id, name, email, phone, created_at FROM users WHERE role = 'rider' ORDER BY id DESC")->fetchAll();

    // Earnings summary
    $earnings = [];
    $stmt = $pdo->query("SELECT rider_id, COUNT(*) AS deliveries, SUM(total) AS earned 
                         FROM rider_earnings WHERE status = 'paid' GROUP BY rider_id");
    foreach ($stmt->fetchAll() as $row) {
        $earnings[$row['rider_id']] = $row;
    }
} catch (Exception $e) {
    $users = $riders = [];
    $error_message = "Database error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title>

    <!-- Tailwind + DaisyUI -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet">

    <!-- Fonts & Icons -->
    <link
        href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            background: linear-gradient(135deg, #fffbeb 0%, #fefce8 100%);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
        }

        .playfair {
            font-family: 'Playfair Display', serif;
        }

        .glass {
            background: rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 15px 35px rgba(251, 191, 36, 0.15);
        }

        .table-row:hover {
            background: rgba(253, 230, 138, 0.15) !important;
        }
    </style>
    <link rel="stylesheet" href="admin.css">
</head>

<body class="text-gray-800">

    <div class="flex min-h-screen">

        <!-- Sidebar -->
        <div class="w-64 sidebar bg-white shadow-2xl fixed h-full z-10 border-r border-yellow-100">
            <div class="p-8 text-center border-b border-yellow-100">
                <h1 class="playfair text-4xl font-bold text-yellow-600">Cheeze Tea</h1>
                <p class="text-yellow-700 text-sm">Admin Panel</p>
            </div>
            <?php $current_page = basename($_SERVER['PHP_SELF']); ?>
            <nav class="mt-8">
                <a href="dashboard.php"
                    class="<?php echo $current_page === 'dashboard.php' ? 'block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold' : 'block py-4 px-8 hover:bg-yellow-50 transition'; ?>">
                    <i class="fas fa-tachometer-alt mr-3"></i> Dashboard
                </a>
                <a href="products.php"
                    class="<?php echo $current_page === 'products.php' ? 'block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold' : 'block py-4 px-8 hover:bg-yellow-50 transition'; ?>">
                    <i class="fas fa-coffee mr-3"></i> Products
                </a>
                <a href="orders.php"
                    class="<?php echo $current_page === 'orders.php' ? 'block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold' : 'block py-4 px-8 hover:bg-yellow-50 transition'; ?>">
                    <i class="fas fa-shopping-bag mr-3"></i> Orders
                </a>
                <a href="customers.php"
                    class="<?php echo $current_page === 'customers.php' ? 'block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold' : 'block py-4 px-8 hover:bg-yellow-50 transition'; ?>">
                    <i class="fas fa-users mr-3"></i> Customers
                </a>
                <a href="riders.php"
                    class="<?php echo $current_page === 'riders.php' ? 'block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold' : 'block py-4 px-8 hover:bg-yellow-50 transition'; ?>">
                    <i class="fas fa-motorcycle mr-3"></i> Riders
                </a>
                <a href="analytics.php"
                    class="<?php echo $current_page === 'analytics.php' ? 'block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold' : 'block py-4 px-8 hover:bg-yellow-50 transition'; ?>">
                    <i class="fas fa-chart-line mr-3"></i> Analytics
                </a>
                <a href="../logout.php" class="block py-4 px-8 hover:bg-red-50 hover:text-red-600 transition mt-32">
                    <i class="fas fa-sign-out-alt mr-3"></i> Logout
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 ml-64 p-10">

            <!-- Header -->
            <div class="admin-topbar">
                <div>
                    <h1 class="playfair text-5xl font-bold text-yellow-700">Manage Riders</h1>
                    <p class="text-gray-600 mt-2">View, assign, and configure rider payouts.</p>
                </div>
                <div class="flex items-center gap-4">
                    <a href="../index.php" target="_blank" class="view-site-btn">View Site</a>
                </div>
            </div>

            <!-- Messages -->
            <?php if ($settings_success): ?>
                <div class="alert alert-success mb-4">
                    <?php echo htmlspecialchars($settings_success); ?>
                </div>
            <?php endif; ?>
            <?php if ($settings_error): ?>
                <div class="alert alert-error mb-4">
                    <?php echo htmlspecialchars($settings_error); ?>
                </div>
            <?php endif; ?>

            <?php if ($success_message): ?>
                <div class="alert alert-success mb-4">
                    <?php echo htmlspecialchars($success_message); ?>
                </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
                <div class="alert alert-error mb-4">
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>

            <!-- Rider Payout Settings Panel -->
            <div class="glass rounded-3xl p-6 mb-8">
                <h3 class="text-2xl font-semibold text-yellow-700 mb-4 flex items-center gap-2">
                    <i class="fas fa-wallet"></i> Rider Payout Settings
                </h3>
                <p class="text-gray-600 mb-4 text-sm">
                    This is the fixed amount each rider earns for every verified delivery.
                </p>

                <form method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
                    <div>
                        <label class="label text-sm font-semibold text-gray-700">
                            Base Pay per Delivery (₱)
                        </label>
                        <input type="number" name="base_pay" step="0.01" min="0"
                            value="<?php echo htmlspecialchars($payout_settings['base_pay']); ?>"
                            class="input input-bordered w-full bg-white text-gray-800">
                    </div>
                    <div class="md:col-span-1 mt-4 md:mt-7">
                        <button type="submit" name="save_payout_settings" class="btn btn-success">
                            <i class="fas fa-save mr-2"></i> Save Payout Settings
                        </button>
                    </div>
                </form>
            </div>

            <!-- Add Rider Panel -->
            <div class="glass rounded-3xl p-6 mb-6">
                <h3 class="text-xl font-semibold text-yellow-700 mb-4 flex items-center gap-2">
                    <i class="fas fa-user-plus mr-2"></i> Add New Rider
                </h3>
                <div class="space-y-2 max-h-96 overflow-y-auto">
                    <?php if (!empty($users)): ?>
                        <?php foreach ($users as $user): ?>
                            <div
                                class="flex justify-between items-center p-3 bg-white rounded-lg shadow hover:bg-yellow-50 transition">
                                <div>
                                    <p class="font-semibold">
                                        <?php echo htmlspecialchars($user['name'] ?? 'No Name'); ?>
                                    </p>
                                    <p class="text-gray-600 text-sm">
                                        <?php echo htmlspecialchars($user['email'] ?? 'No Email'); ?>
                                    </p>
                                </div>
                                <form method="POST" class="ml-4">
                                    <input type="hidden" name="user_id" value="<?php echo (int) $user['id']; ?>">
                                    <button type="submit" name="assign_rider" class="btn btn-success btn-sm">
                                        <i class="fas fa-user-plus mr-1"></i> Make Rider
                                    </button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-gray-500 text-center py-8">No available users to assign as riders.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Riders Table -->
            <div class="glass rounded-3xl overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="bg-gradient-to-r from-yellow-400 to-amber-500 text-white">
                                <th class="px-8 py-6 text-left">ID</th>
                                <th class="px-8 py-6 text-left">Name</th>
                                <th class="px-8 py-6 text-left">Email</th>
                                <th class="px-8 py-6 text-left">Phone</th>
                                <th class="px-8 py-6 text-center">Deliveries</th>
                                <th class="px-8 py-6 text-center">Total Earned</th>
                                <th class="px-8 py-6 text-center">Joined</th>
                                <th class="px-8 py-6 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-yellow-100">
                            <?php if (!empty($riders)): ?>
                                <?php foreach ($riders as $rider):
                                    $rid = (int) $rider['id'];
                                    $earnSummary = $earnings[$rid] ?? null;
                                    ?>
                                    <tr class="table-row transition-all duration-300 hover:bg-yellow-50/50">
                                        <td class="px-8 py-6">
                                            <p class="font-semibold text-lg text-gray-800">
                                                #<?php echo htmlspecialchars($rider['id']); ?>
                                            </p>
                                        </td>
                                        <td class="px-8 py-6">
                                            <p class="font-semibold text-gray-800">
                                                <?php echo htmlspecialchars($rider['name']); ?>
                                            </p>
                                        </td>
                                        <td class="px-8 py-6">
                                            <p class="text-gray-600"><?php echo htmlspecialchars($rider['email']); ?></p>
                                        </td>
                                        <td class="px-8 py-6">
                                            <p class="text-gray-600">
                                                <?php echo htmlspecialchars($rider['phone'] ?? 'N/A'); ?>
                                            </p>
                                        </td>
                                        <td class="px-8 py-6 text-center">
                                            <?php if ($earnSummary): ?>
                                                <span class="font-semibold">
                                                    <?php echo (int) $earnSummary['deliveries']; ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="text-gray-400 text-sm">0</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-8 py-6 text-center">
                                            <?php if ($earnSummary): ?>
                                                <span class="font-bold text-green-600">
                                                    ₱<?php echo number_format((float) $earnSummary['earned'], 2); ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="text-gray-400 text-sm">₱0.00</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-8 py-6 text-center">
                                            <p class="text-sm text-gray-600">
                                                <?php echo date('M d, Y', strtotime($rider['created_at'] ?? date('Y-m-d'))); ?>
                                            </p>
                                        </td>
                                        <td class="px-8 py-6 text-center">
                                            <div class="flex gap-3 justify-center">
                                                <form method="POST"
                                                    onsubmit="return confirm('Remove this rider? They will be converted back to customer.');"
                                                    style="display:inline">
                                                    <input type="hidden" name="rider_id"
                                                        value="<?php echo (int) $rider['id']; ?>">
                                                    <button type="submit" name="remove_rider"
                                                        class="px-4 py-2 bg-red-500 text-white rounded-xl hover:bg-red-600 transition shadow">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center py-16 text-gray-500">
                                        <i class="fas fa-motorcycle text-6xl mb-4 block text-yellow-300"></i>
                                        <p class="text-2xl">No riders yet.</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Floating Action Button (Mobile) -->
            <a href="dashboard.php"
                class="fixed bottom-8 right-8 w-16 h-16 bg-yellow-500 text-white rounded-full shadow-2xl flex items-center justify-center text-3xl hover:bg-amber-600 transform hover:scale-110 transition z-50 md:hidden">
                <i class="fas fa-home"></i>
            </a>

        </div>
    </div>

</body>

</html>