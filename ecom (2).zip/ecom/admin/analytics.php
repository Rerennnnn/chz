<?php
require '../includes/auth.php';
requireAdmin();
require '../includes/db.php';

$page_title = "Analytics - Cheeze Tea Admin";

// Prepare analytics data (safe: uses try/catch and checks table/column existence)
try {
    // Helper: check table exists
    function table_exists($pdo, $name)
    {
        $res = $pdo->query("SHOW TABLES LIKE '" . str_replace("'", "\\'", $name) . "'")->fetchAll();
        return !empty($res);
    }

    // Totals
    $total_orders = table_exists($pdo, 'orders') ? (int) $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn() : 0;
    $total_revenue = 0;
    if (table_exists($pdo, 'orders')) {
        $total_revenue = (float) $pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE (payment_status = 'paid' OR status = 'completed')")->fetchColumn();
    }

    $total_customers = table_exists($pdo, 'users') ? (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn() : 0;

    // New customers (last 30 days)
    $new_customers = 'N/A';
    $prev_customers = 0;
    if (table_exists($pdo, 'users')) {
        $col = $pdo->query("SHOW COLUMNS FROM users LIKE 'created_at'")->fetchAll();
        if (!empty($col)) {
            $new_customers = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer' AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetchColumn();
            $prev_customers = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer' AND created_at BETWEEN DATE_SUB(NOW(), INTERVAL 60 DAY) AND DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetchColumn();
        }
    }

    // Calculate growth percentages
    $prev_orders = table_exists($pdo, 'orders') ? (int) $pdo->query("SELECT COUNT(*) FROM orders WHERE created_at BETWEEN DATE_SUB(NOW(), INTERVAL 60 DAY) AND DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetchColumn() : 0;
    $orders_growth = $prev_orders > 0 ? round((($total_orders - $prev_orders) / $prev_orders) * 100, 1) : 0;

    $prev_revenue = 0;
    if (table_exists($pdo, 'orders')) {
        $prev_revenue = (float) $pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE (payment_status = 'paid' OR status = 'completed') AND created_at BETWEEN DATE_SUB(NOW(), INTERVAL 60 DAY) AND DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetchColumn();
    }
    $revenue_growth = $prev_revenue > 0 ? round((($total_revenue - $prev_revenue) / $prev_revenue) * 100, 1) : 0;

    $customer_growth = $prev_customers > 0 ? round((($new_customers - $prev_customers) / $prev_customers) * 100, 1) : 0;

    $avg_order_value = 0;
    if ($total_orders > 0) {
        $avg_order_value = round($total_revenue / max(1, $total_orders));
    }

    // Sales last 30 days (daily)
    $sales_labels = [];
    $sales_data = [];
    $orders_count_data = [];
    if (table_exists($pdo, 'orders')) {
        $days = [];
        for ($i = 29; $i >= 0; $i--) {
            $d = new DateTime();
            $d->modify("-{$i} days");
            $days[] = $d->format('Y-m-d');
        }

        $placeholders = implode(',', array_fill(0, count($days), '?'));
        $stmt = $pdo->prepare("SELECT DATE(created_at) as day, COALESCE(SUM(total),0) as revenue, COUNT(*) as orders FROM orders WHERE DATE(created_at) IN ($placeholders) GROUP BY day ORDER BY day ASC");
        $stmt->execute($days);
        $rows = $stmt->fetchAll();
        $map = [];
        foreach ($rows as $r) {
            $map[$r['day']] = ['revenue' => (float) $r['revenue'], 'orders' => (int) $r['orders']];
        }

        foreach ($days as $d) {
            $sales_labels[] = date('M j', strtotime($d));
            $sales_data[] = isset($map[$d]) ? $map[$d]['revenue'] : 0;
            $orders_count_data[] = isset($map[$d]) ? $map[$d]['orders'] : 0;
        }
    }

    // Top products by revenue
    $top_products = [];
    if (table_exists($pdo, 'order_items') && table_exists($pdo, 'products')) {
        $stmt = $pdo->query("SELECT p.name, p.category, COALESCE(SUM(oi.quantity * oi.price),0) AS revenue, COALESCE(SUM(oi.quantity),0) AS qty FROM order_items oi JOIN products p ON oi.product_id = p.id GROUP BY p.id ORDER BY revenue DESC LIMIT 5");
        $top_products = $stmt->fetchAll();
    }

    // Top categories (by revenue and quantity)
    $cat_labels = [];
    $cat_revenue = [];
    $cat_quantity = [];
    if (table_exists($pdo, 'order_items') && table_exists($pdo, 'products')) {
        $stmt = $pdo->query("SELECT p.category, COALESCE(SUM(oi.quantity * oi.price),0) AS revenue, COALESCE(SUM(oi.quantity),0) AS qty FROM order_items oi JOIN products p ON oi.product_id = p.id GROUP BY p.category ORDER BY revenue DESC LIMIT 6");
        $rows = $stmt->fetchAll();
        foreach ($rows as $r) {
            $cat_labels[] = $r['category'] ?: 'Uncategorized';
            $cat_revenue[] = (float) $r['revenue'];
            $cat_quantity[] = (int) $r['qty'];
        }
    }

    // Orders by status
    $status_labels = [];
    $status_data = [];
    if (table_exists($pdo, 'orders')) {
        $stmt = $pdo->query("SELECT status, COUNT(*) as cnt FROM orders GROUP BY status ORDER BY cnt DESC");
        $rows = $stmt->fetchAll();
        foreach ($rows as $r) {
            $status_labels[] = ucfirst($r['status']);
            $status_data[] = (int) $r['cnt'];
        }
    }

    // Orders by hour (aggregated across all days)
    $hour_labels = [];
    $hour_data = array_fill(0, 24, 0);
    if (table_exists($pdo, 'orders')) {
        $rows = $pdo->query("SELECT HOUR(created_at) as hr, COUNT(*) as cnt FROM orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY hr")->fetchAll();
        foreach ($rows as $r) {
            $hour_data[(int) $r['hr']] = (int) $r['cnt'];
        }
        for ($h = 0; $h < 24; $h++)
            $hour_labels[] = sprintf('%02d:00', $h);
    }

    // Payment methods distribution
    $payment_labels = [];
    $payment_data = [];
    if (table_exists($pdo, 'orders')) {
        $col = $pdo->query("SHOW COLUMNS FROM orders LIKE 'payment_method'")->fetchAll();
        if (!empty($col)) {
            $stmt = $pdo->query("SELECT payment_method, COUNT(*) as cnt FROM orders WHERE payment_method IS NOT NULL GROUP BY payment_method");
            $rows = $stmt->fetchAll();
            foreach ($rows as $r) {
                $payment_labels[] = ucfirst($r['payment_method']);
                $payment_data[] = (int) $r['cnt'];
            }
        }
    }

    // Customer retention - returning customers
    $returning_customers = 0;
    $one_time_customers = 0;
    if (table_exists($pdo, 'orders')) {
        $stmt = $pdo->query("SELECT customer_name, COUNT(*) as order_count FROM orders WHERE customer_name IS NOT NULL GROUP BY customer_name");
        $rows = $stmt->fetchAll();
        foreach ($rows as $r) {
            if ((int) $r['order_count'] > 1) {
                $returning_customers++;
            } else {
                $one_time_customers++;
            }
        }
    }
    $retention_rate = ($returning_customers + $one_time_customers) > 0 ? round(($returning_customers / ($returning_customers + $one_time_customers)) * 100, 1) : 0;

    // Peak hours analysis
    $peak_hour = 0;
    $peak_hour_orders = 0;
    if (!empty($hour_data)) {
        $peak_hour_orders = max($hour_data);
        $peak_hour = array_search($peak_hour_orders, $hour_data);
    }

    // Recent orders list
    $recent_orders = [];
    if (table_exists($pdo, 'orders')) {
        $stmt = $pdo->query("SELECT id, customer_name, total, status, created_at FROM orders ORDER BY created_at DESC LIMIT 8");
        $recent_orders = $stmt->fetchAll();
    }

} catch (Exception $e) {
    // Fallback to safe values
    $total_orders = $total_revenue = $total_customers = 0;
    $new_customers = 'N/A';
    $avg_order_value = 0;
    $orders_growth = $revenue_growth = $customer_growth = 0;
    $sales_labels = $sales_data = $orders_count_data = [];
    $top_products = $cat_labels = $cat_revenue = $cat_quantity = [];
    $status_labels = $status_data = [];
    $hour_labels = $hour_data = [];
    $payment_labels = $payment_data = [];
    $returning_customers = $one_time_customers = 0;
    $retention_rate = 0;
    $peak_hour = 0;
    $peak_hour_orders = 0;
    $recent_orders = [];
}

// JSON encode datasets
$sales_labels_json = json_encode($sales_labels);
$sales_data_json = json_encode($sales_data);
$orders_count_json = json_encode($orders_count_data);
$cat_labels_json = json_encode($cat_labels);
$cat_revenue_json = json_encode($cat_revenue);
$cat_quantity_json = json_encode($cat_quantity);
$status_labels_json = json_encode($status_labels);
$status_data_json = json_encode($status_data);
$hour_labels_json = json_encode($hour_labels);
$hour_data_json = json_encode($hour_data);
$payment_labels_json = json_encode($payment_labels);
$payment_data_json = json_encode($payment_data);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title><?php echo $page_title; ?></title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="stylesheet" href="admin.css" />

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        .kpi {
            background: linear-gradient(135deg, #fffaf0 0%, #fff7ed 100%);
            position: relative;
            overflow: hidden;
        }

        .kpi::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(251, 191, 36, 0.1) 0%, transparent 70%);
            animation: pulse 3s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.5; }
            50% { transform: scale(1.1); opacity: 0.8; }
        }

        .growth-positive {
            color: #10b981;
        }

        .growth-negative {
            color: #ef4444;
        }

        .insight-card {
            background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
            border-left: 4px solid #f59e0b;
        }

        .chart-container {
            position: relative;
            height: 300px;
        }

        .metric-icon {
            font-size: 2.5rem;
            opacity: 0.15;
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
        }
    </style>
</head>

<body class="text-gray-800 bg-gray-50">
    <div class="flex min-h-screen">

        <!-- Sidebar -->
        <div class="w-64 sidebar bg-white shadow-2xl fixed h-full z-10 border-r border-yellow-100">
            <div class="p-8 text-center border-b border-yellow-100">
                <h1 class="playfair text-4xl font-bold text-yellow-600">Cheeze Tea</h1>
                <p class="text-yellow-700 text-sm">Admin Panel</p>
            </div>
            <nav class="mt-8">
                <a href="dashboard.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                    <i class="fas fa-tachometer-alt mr-3"></i> Dashboard
                </a>
                <a href="products.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                    <i class="fas fa-coffee mr-3"></i> Products
                </a>
                <a href="orders.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                    <i class="fas fa-shopping-bag mr-3"></i> Orders
                </a>
                <a href="customers.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                    <i class="fas fa-users mr-3"></i> Customers
                </a>
                <a href="riders.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                    <i class="fas fa-motorcycle mr-3"></i> Riders
                </a>
                <a href="analytics.php"
                    class="block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold">
                    <i class="fas fa-chart-line mr-3"></i> Analytics
                </a>
                <a href="../logout.php" class="block py-4 px-8 hover:bg-red-50 hover:text-red-600 transition mt-32">
                    <i class="fas fa-sign-out-alt mr-3"></i> Logout
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 ml-64 p-10">

            <div class="admin-topbar mb-8 flex items-center justify-between">
                <div>
                    <h1 class="playfair text-5xl font-bold text-yellow-700">Advanced Analytics</h1>
                    <p class="text-gray-600 mt-2">Comprehensive insights and performance metrics</p>
                </div>
                <div class="flex gap-3">
                    <button onclick="window.print()" class="px-4 py-2 bg-white border border-yellow-300 rounded-lg hover:bg-yellow-50 transition">
                        <i class="fas fa-print mr-2"></i>Export Report
                    </button>
                    <a href="../index.php" target="_blank" class="view-site-btn">View Site</a>
                </div>
            </div>

            <!-- KPI Cards with Growth Indicators -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="kpi rounded-2xl p-6 shadow-lg relative">
                    <i class="fas fa-shopping-cart metric-icon text-yellow-600"></i>
                    <div class="text-sm text-gray-600 font-semibold">Total Orders</div>
                    <div class="text-4xl font-bold mt-2 text-gray-800"><?php echo number_format($total_orders); ?></div>
                    <div class="text-sm mt-2 <?php echo $orders_growth >= 0 ? 'growth-positive' : 'growth-negative'; ?>">
                        <i class="fas fa-<?php echo $orders_growth >= 0 ? 'arrow-up' : 'arrow-down'; ?>"></i>
                        <?php echo abs($orders_growth); ?>% vs last period
                    </div>
                </div>
                <div class="kpi rounded-2xl p-6 shadow-lg relative">
                    <i class="fas fa-peso-sign metric-icon text-yellow-600"></i>
                    <div class="text-sm text-gray-600 font-semibold">Total Revenue</div>
                    <div class="text-4xl font-bold mt-2 text-gray-800">₱<?php echo number_format($total_revenue, 0); ?></div>
                    <div class="text-sm mt-2 <?php echo $revenue_growth >= 0 ? 'growth-positive' : 'growth-negative'; ?>">
                        <i class="fas fa-<?php echo $revenue_growth >= 0 ? 'arrow-up' : 'arrow-down'; ?>"></i>
                        <?php echo abs($revenue_growth); ?>% vs last period
                    </div>
                </div>
                <div class="kpi rounded-2xl p-6 shadow-lg relative">
                    <i class="fas fa-user-plus metric-icon text-yellow-600"></i>
                    <div class="text-sm text-gray-600 font-semibold">New Customers (30d)</div>
                    <div class="text-4xl font-bold mt-2 text-gray-800">
                        <?php echo is_numeric($new_customers) ? number_format($new_customers) : $new_customers; ?>
                    </div>
                    <div class="text-sm mt-2 <?php echo $customer_growth >= 0 ? 'growth-positive' : 'growth-negative'; ?>">
                        <i class="fas fa-<?php echo $customer_growth >= 0 ? 'arrow-up' : 'arrow-down'; ?>"></i>
                        <?php echo abs($customer_growth); ?>% vs last period
                    </div>
                </div>
                <div class="kpi rounded-2xl p-6 shadow-lg relative">
                    <i class="fas fa-chart-line metric-icon text-yellow-600"></i>
                    <div class="text-sm text-gray-600 font-semibold">Avg. Order Value</div>
                    <div class="text-4xl font-bold mt-2 text-gray-800">₱<?php echo number_format($avg_order_value, 0); ?></div>
                    <div class="text-sm mt-2 text-gray-500">
                        <i class="fas fa-info-circle"></i>
                        Per transaction
                    </div>
                </div>
            </div>

            <!-- Quick Insights -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div class="insight-card p-4 rounded-xl shadow">
                    <div class="flex items-center gap-3">
                        <i class="fas fa-clock text-yellow-600 text-2xl"></i>
                        <div>
                            <div class="text-sm text-gray-600">Peak Hour</div>
                            <div class="text-xl font-bold"><?php echo sprintf('%02d:00', $peak_hour); ?></div>
                            <div class="text-xs text-gray-500"><?php echo $peak_hour_orders; ?> orders</div>
                        </div>
                    </div>
                </div>
                <div class="insight-card p-4 rounded-xl shadow">
                    <div class="flex items-center gap-3">
                        <i class="fas fa-repeat text-yellow-600 text-2xl"></i>
                        <div>
                            <div class="text-sm text-gray-600">Customer Retention</div>
                            <div class="text-xl font-bold"><?php echo $retention_rate; ?>%</div>
                            <div class="text-xs text-gray-500"><?php echo $returning_customers; ?> returning customers</div>
                        </div>
                    </div>
                </div>
                <div class="insight-card p-4 rounded-xl shadow">
                    <div class="flex items-center gap-3">
                        <i class="fas fa-users text-yellow-600 text-2xl"></i>
                        <div>
                            <div class="text-sm text-gray-600">Total Customers</div>
                            <div class="text-xl font-bold"><?php echo number_format($total_customers); ?></div>
                            <div class="text-xs text-gray-500"><?php echo $one_time_customers; ?> first-time buyers</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Revenue & Orders Trend -->
            <div class="glass p-6 rounded-2xl shadow-lg mb-6">
                <div class="flex justify-between items-center mb-4">
                    <div>
                        <h3 class="text-2xl font-bold text-gray-800">Revenue & Orders Trend</h3>
                        <p class="text-sm text-gray-500">Last 30 days performance overview</p>
                    </div>
                    <div class="flex gap-4 text-sm">
                        <div class="flex items-center gap-2">
                            <div class="w-4 h-4 bg-amber-500 rounded"></div>
                            <span>Revenue</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <div class="w-4 h-4 bg-blue-500 rounded"></div>
                            <span>Orders</span>
                        </div>
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="salesChart"></canvas>
                </div>
            </div>

            <!-- Charts Grid -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <div class="glass p-6 rounded-2xl shadow-lg">
                    <h3 class="text-xl font-bold mb-2">Category Performance</h3>
                    <p class="text-sm text-gray-500 mb-4">Revenue distribution by category</p>
                    <div class="chart-container">
                        <canvas id="categoryChart"></canvas>
                    </div>
                </div>

                <div class="glass p-6 rounded-2xl shadow-lg">
                    <h3 class="text-xl font-bold mb-2">Order Status Distribution</h3>
                    <p class="text-sm text-gray-500 mb-4">Current order pipeline</p>
                    <div class="chart-container">
                        <canvas id="statusChart"></canvas>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <div class="glass p-6 rounded-2xl shadow-lg">
                    <h3 class="text-xl font-bold mb-2">Order Volume by Hour</h3>
                    <p class="text-sm text-gray-500 mb-4">30-day aggregated hourly distribution</p>
                    <div class="chart-container">
                        <canvas id="hourChart"></canvas>
                    </div>
                </div>

                <?php if (!empty($payment_labels)): ?>
                    <div class="glass p-6 rounded-2xl shadow-lg">
                        <h3 class="text-xl font-bold mb-2">Payment Methods</h3>
                        <p class="text-sm text-gray-500 mb-4">Customer payment preferences</p>
                        <div class="chart-container">
                            <canvas id="paymentChart"></canvas>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Top Products Table -->
            <?php if (!empty($top_products)): ?>
                <div class="glass p-6 rounded-2xl shadow-lg mb-6">
                    <h3 class="text-2xl font-bold mb-4">Top Performing Products</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead>
                                <tr class="bg-gradient-to-r from-yellow-400 to-amber-500 text-white">
                                    <th class="px-4 py-3 rounded-tl-lg">Rank</th>
                                    <th class="px-4 py-3">Product Name</th>
                                    <th class="px-4 py-3">Category</th>
                                    <th class="px-4 py-3">Units Sold</th>
                                    <th class="px-4 py-3 rounded-tr-lg">Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $rank = 1;
                                foreach ($top_products as $product): ?>
                                        <tr class="border-b hover:bg-yellow-50 transition">
                                            <td class="px-4 py-4">
                                                <span class="inline-flex items-center justify-center w-8 h-8 rounded-full bg-yellow-100 text-yellow-700 font-bold">
                                                    <?php echo $rank++; ?>
                                                </span>
                                            </td>
                                            <td class="px-4 py-4 font-semibold"><?php echo htmlspecialchars($product['name']); ?></td>
                                            <td class="px-4 py-4">
                                                <span class="px-3 py-1 bg-amber-100 text-amber-700 rounded-full text-sm">
                                                    <?php echo htmlspecialchars($product['category']); ?>
                                                </span>
                                            </td>
                                            <td class="px-4 py-4"><?php echo number_format($product['qty']); ?></td>
                                            <td class="px-4 py-4 font-bold text-green-600">₱<?php echo number_format($product['revenue'], 2); ?></td>
                                        </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Recent Orders -->
            <div class="glass p-6 rounded-2xl shadow-lg">
                <h3 class="text-2xl font-bold mb-4">Recent Orders</h3>
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead>
                            <tr class="bg-gradient-to-r from-yellow-400 to-amber-500 text-white">
                                <th class="px-4 py-3 rounded-tl-lg">Order ID</th>
                                <th class="px-4 py-3">Customer</th>
                                <th class="px-4 py-3">Amount</th>
                                <th class="px-4 py-3">Status</th>
                                <th class="px-4 py-3 rounded-tr-lg">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($recent_orders)): ?>
                                    <?php foreach ($recent_orders as $order): ?>
                                            <tr class="border-b hover:bg-yellow-50 transition">
                                                <td class="px-4 py-3 font-mono text-sm">#<?php echo htmlspecialchars($order['id']); ?></td>
                                                <td class="px-4 py-3">
                                                    <?php echo htmlspecialchars($order['customer_name'] ?? 'Guest'); ?>
                                                </td>
                                                <td class="px-4 py-3 font-semibold">₱<?php echo number_format((float) ($order['total'] ?? 0), 2); ?></td>
                                                <td class="px-4 py-3">
                                                    <?php $st = $order['status'] ?? 'pending'; ?>
                                                    <?php if ($st === 'completed' || $st === 'delivered'): ?>
                                                            <span class="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium">
                                                                <i class="fas fa-check-circle mr-1"></i><?php echo ucfirst($st); ?>
                                                            </span>
                                                    <?php elseif ($st === 'processing' || $st === 'paid'): ?>
                                                            <span class="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                                                                <i class="fas fa-sync mr-1"></i><?php echo ucfirst($st); ?>
                                                            </span>
                                                    <?php elseif ($st === 'pending'): ?>
                                                            <span class="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-sm font-medium">
                                                                <i class="fas fa-clock mr-1"></i><?php echo ucfirst($st); ?>
                                                            </span>
                                                    <?php else: ?>
                                                            <span class="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm font-medium">
                                                                <?php echo ucfirst($st); ?>
                                                            </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="px-4 py-3 text-sm text-gray-600">
                                                    <?php echo date('M j, Y g:i A', strtotime($order['created_at'])); ?>
                                                </td>
                                            </tr>
                                    <?php endforeach; ?>
                            <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="px-4 py-8 text-center text-gray-500">
                                            <i class="fas fa-inbox text-4xl mb-2 opacity-30"></i>
                                            <p>No recent orders found</p>
                                        </td>
                                    </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>

    <script>
        // Chart.js default settings
        Chart.defaults.font.family = "'Inter', sans-serif";
        Chart.defaults.color = '#6b7280';

        // Parse server-side data
        const salesLabels = <?php echo $sales_labels_json ?? '[]'; ?>;
        const salesData = <?php echo $sales_data_json ?? '[]'; ?>;
        const ordersData = <?php echo $orders_count_json ?? '[]'; ?>;
        const catLabels = <?php echo $cat_labels_json ?? '[]'; ?>;
        const catRevenue = <?php echo $cat_revenue_json ?? '[]'; ?>;
        const statusLabels = <?php echo $status_labels_json ?? '[]'; ?>;
        const statusData = <?php echo $status_data_json ?? '[]'; ?>;
        const hourLabels = <?php echo $hour_labels_json ?? '[]'; ?>;
        const hourData = <?php echo $hour_data_json ?? '[]'; ?>;
        const paymentLabels = <?php echo $payment_labels_json ?? '[]'; ?>;
        const paymentData = <?php echo $payment_data_json ?? '[]'; ?>;

        // Revenue & Orders Combo Chart
        const salesCtx = document.getElementById('salesChart')?.getContext('2d');
        if (salesCtx) {
            new Chart(salesCtx, {
                type: 'line',
                data: {
                    labels: salesLabels,
                    datasets: [
                        {
                            label: 'Revenue (₱)',
                            data: salesData,
                            backgroundColor: 'rgba(245, 158, 11, 0.1)',
                            borderColor: '#f59e0b',
                            borderWidth: 3,
                            fill: true,
                            tension: 0.4,
                            yAxisID: 'y',
                        },
                        {
                            label: 'Orders',
                            data: ordersData,
                            backgroundColor: 'rgba(59, 130, 246, 0.1)',
                            borderColor: '#3b82f6',
                            borderWidth: 3,
                            fill: true,
                            tension: 0.4,
                            yAxisID: 'y1',
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        mode: 'index',
                        intersect: false,
                    },
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            padding: 12,
                            titleFont: { size: 14 },
                            bodyFont: { size: 13 },
                            callbacks: {
                                label: function(context) {
                                    let label = context.dataset.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    if (context.parsed.y !== null) {
                                        if (context.datasetIndex === 0) {
                                            label += '₱' + context.parsed.y.toLocaleString('en-PH', {minimumFractionDigits: 2});
                                        } else {
                                            label += context.parsed.y.toLocaleString();
                                        }
                                    }
                                    return label;
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            type: 'linear',
                            display: true,
                            position: 'left',
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)',
                            },
                            ticks: {
                                callback: function(value) {
                                    return '₱' + value.toLocaleString();
                                }
                            }
                        },
                        y1: {
                            type: 'linear',
                            display: true,
                            position: 'right',
                            grid: {
                                drawOnChartArea: false,
                            },
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }

        // Category Horizontal Bar Chart
        const catCtx = document.getElementById('categoryChart')?.getContext('2d');
        if (catCtx && catLabels.length > 0) {
            new Chart(catCtx, {
                type: 'bar',
                data: {
                    labels: catLabels,
                    datasets: [{
                        label: 'Revenue',
                        data: catRevenue,
                        backgroundColor: [
                            '#f59e0b',
                            '#fb7185',
                            '#f97316',
                            '#fbbf24',
                            '#60a5fa',
                            '#34d399'
                        ],
                        borderRadius: 8,
                        borderWidth: 0
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            padding: 12,
                            callbacks: {
                                label: function(context) {
                                    return 'Revenue: ₱' + context.parsed.x.toLocaleString('en-PH', {minimumFractionDigits: 2});
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)',
                            },
                            ticks: {
                                callback: function(value) {
                                    return '₱' + value.toLocaleString();
                                }
                            }
                        },
                        y: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }

        // Order Status Doughnut
        const statusCtx = document.getElementById('statusChart')?.getContext('2d');
        if (statusCtx && statusLabels.length > 0) {
            new Chart(statusCtx, {
                type: 'doughnut',
                data: {
                    labels: statusLabels,
                    datasets: [{
                        data: statusData,
                        backgroundColor: [
                            '#10b981',
                            '#3b82f6',
                            '#fbbf24',
                            '#f59e0b',
                            '#ef4444',
                            '#8b5cf6'
                        ],
                        borderWidth: 0,
                        hoverOffset: 10
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right',
                            labels: {
                                padding: 15,
                                font: {
                                    size: 12
                                },
                                usePointStyle: true,
                                pointStyle: 'circle'
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            padding: 12,
                            callbacks: {
                                label: function(context) {
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = ((context.parsed / total) * 100).toFixed(1);
                                    return context.label + ': ' + context.parsed + ' (' + percentage + '%)';
                                }
                            }
                        }
                    }
                }
            });
        }

        // Hour Bar Chart
        const hourCtx = document.getElementById('hourChart')?.getContext('2d');
        if (hourCtx) {
            new Chart(hourCtx, {
                type: 'bar',
                data: {
                    labels: hourLabels,
                    datasets: [{
                        label: 'Orders',
                        data: hourData,
                        backgroundColor: function(context) {
                            const value = context.parsed.y;
                            const max = Math.max(...hourData);
                            const intensity = value / max;
                            return `rgba(245, 158, 11, ${0.3 + intensity * 0.7})`;
                        },
                        borderRadius: 6,
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            padding: 12
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)',
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }

        // Payment Methods Pie Chart
        const paymentCtx = document.getElementById('paymentChart')?.getContext('2d');
        if (paymentCtx && paymentLabels.length > 0) {
            new Chart(paymentCtx, {
                type: 'pie',
                data: {
                    labels: paymentLabels,
                    datasets: [{
                        data: paymentData,
                        backgroundColor: [
                            '#f59e0b',
                            '#3b82f6',
                            '#10b981',
                            '#8b5cf6',
                            '#f97316'
                        ],
                        borderWidth: 3,
                        borderColor: '#fff',
                        hoverOffset: 15
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 15,
                                font: {
                                    size: 12
                                },
                                usePointStyle: true,
                                pointStyle: 'circle'
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            padding: 12,
                            callbacks: {
                                label: function(context) {
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = ((context.parsed / total) * 100).toFixed(1);
                                    return context.label + ': ' + context.parsed + ' (' + percentage + '%)';
                                }
                            }
                        }
                    }
                }
            });
        }
    </script>

</body>

</html>