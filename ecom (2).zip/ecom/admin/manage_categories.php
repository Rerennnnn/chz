<?php
// manage_categories.php removed per admin request. Redirect back to dashboard.
header('Location: dashboard.php');
exit;
?>