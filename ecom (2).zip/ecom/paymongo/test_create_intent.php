<?php
// paymongo/test_create_intent.php
// CLI test to create a PayMongo Payment Intent using server config.

require __DIR__ . '/../includes/config.php';

$order_id = $argv[1] ?? null;
$amount = $argv[2] ?? null; // in pesos (e.g. 42.00) or centavos (4200)

if (!$order_id || !$amount) {
    echo "Usage: php test_create_intent.php <order_id> <amount>\n";
    echo "Example: php test_create_intent.php 2 42.00\n";
    exit(1);
}

// Normalize amount to centavos
$amount_raw = trim((string)$amount);
$amount_raw = preg_replace('/[^0-9\.]/', '', $amount_raw);
if (strpos($amount_raw, '.') !== false) {
    $amount_cents = (int) round(floatval($amount_raw) * 100);
} else {
    $amtInt = (int)$amount_raw;
    $amount_cents = ($amtInt < 1000) ? $amtInt * 100 : $amtInt;
}

$paymentData = [
    "data" => [
        "attributes" => [
            "amount" => (int)$amount_cents,
            "payment_method_allowed" => ["gcash", "card"],
            "payment_method_options" => [
                "card" => ["request_three_d_secure" => "any"]
            ],
            "currency" => "PHP",
            "capture_type" => "automatic",
            "description" => "Test Order #" . $order_id
        ]
    ]
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, PAYMONGO_API_URL . '/payment_intents');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($paymentData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Accept: application/json',
    'Authorization: Basic ' . base64_encode(PAYMONGO_SECRET_KEY . ':')
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr = curl_error($ch);
curl_close($ch);

echo "HTTP: $httpCode\n";
if ($curlErr) echo "CURL ERR: $curlErr\n";
echo "RESPONSE:\n" . $response . "\n";

// Also log to the same log file used by process_payment.php
$logDir = __DIR__ . '/logs';
if (!is_dir($logDir)) @mkdir($logDir, 0755, true);
$logFile = $logDir . '/paymongo_errors.log';
$logEntry = date('Y-m-d H:i:s') . " | CLI TEST | HTTP:" . $httpCode . " | CURLERR:" . $curlErr . " | REQUEST:" . json_encode($paymentData) . " | RESPONSE:" . $response . "\n";
@file_put_contents($logFile, $logEntry, FILE_APPEND);

if ($httpCode === 200 || $httpCode === 201) {
    echo "OK - payment intent created (see response for details)\n";
    exit(0);
} else {
    echo "FAILED - check paymongo_errors.log for details\n";
    exit(2);
}

?>
