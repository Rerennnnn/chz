<?php
// login.php - Restored simple login page
require 'includes/db.php';

$page_title = "Login - Cheeze Tea";

// Check if already logged in BEFORE including header (before output)
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$error = '';

// Handle login POST BEFORE including header
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 1) {
        $error = 'Please provide a valid email and password.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['role'] = $user['role'];
            header('Location: index.php');
            exit();
        } else {
            $error = 'Invalid email or password.';
        }
    }
}

// Now include header AFTER all header() calls
require 'includes/header.php';
?>
?>

<!-- Background Bubbles -->
<div class="fixed inset-0 overflow-hidden pointer-events-none -z-10">
    <div class="absolute w-96 h-96 bg-yellow-200/30 rounded-full blur-3xl -top-32 -left-32 animate-pulse"></div>
    <div class="absolute w-80 h-80 bg-amber-200/40 rounded-full blur-3xl top-1/2 right-0 animate-pulse delay-1000">
    </div>
</div>

<div class="min-h-screen flex items-center justify-center px-6 py-12">
    <div class="w-full max-w-md">

        <!-- Logo & Title -->
        <div class="text-center mb-10 animate-fade-in">
            <h1 class="playfair text-7xl font-bold text-yellow-600 drop-shadow-md">Cheeze Tea</h1>
            <p class="text-2xl text-amber-700 mt-3">Welcome back!</p>
        </div>

        <!-- Login Card -->
        <div class="bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl p-10 border border-yellow-100">

            <?php if ($error): ?>
                <div
                    class="bg-red-100 border border-red-300 text-red-700 px-6 py-4 rounded-xl mb-6 text-center font-medium">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <!-- Email/Password Form -->
            <form method="POST" class="space-y-6 mb-8">
                <!-- Email Input -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Email Address</label>
                    <input type="email" name="email" required placeholder="Email Address"
                        value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                        class="w-full px-6 py-4 rounded-2xl border-2 border-yellow-200 focus:border-yellow-500 focus:outline-none focus:ring-4 focus:ring-yellow-200/50 transition text-lg">
                </div>

                <!-- Password Input -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Password</label>
                    <input type="password" name="password" required placeholder="Password" value=""
                        class="w-full px-6 py-4 rounded-2xl border-2 border-yellow-200 focus:border-yellow-500 focus:outline-none focus:ring-4 focus:ring-yellow-200/50 transition text-lg">
                </div>

                <button type="submit"
                    class="w-full bg-gradient-to-r from-yellow-500 to-amber-600 text-white font-bold py-5 rounded-2xl text-xl shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300">
                    Login
                </button>
            </form>

            <!-- Divider -->
            <div class="flex items-center my-8">
                <div class="flex-1 border-t border-yellow-200"></div>
                <span class="px-4 text-gray-500 font-medium">or continue with</span>
                <div class="flex-1 border-t border-yellow-200"></div>
            </div>

            <!-- Social Buttons -->
            <div class="grid grid-cols-1 gap-4">
                <!-- Google Login -->
                <a href="oauth/google.php"
                    class="flex items-center justify-center gap-4 bg-white border-2 border-gray-300 hover:border-red-400 px-6 py-5 rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300">
                    <img src="https://www.google.com/favicon.ico" alt="Google" class="w-7 h-7">
                    <span class="font-bold text-gray-700">Continue with Google</span>
                </a>

                <!-- Facebook Login -->
                <a href="oauth/facebook.php"
                    class="flex items-center justify-center gap-4 bg-[#1877F2] text-white px-6 py-5 rounded-2xl shadow-lg hover:shadow-xl hover:bg-[#165FBF] transform hover:scale-105 transition-all duration-300">
                    <i class="fab fa-facebook-f text-2xl"></i>
                    <span class="font-bold">Continue with Facebook</span>
                </a>
            </div>

            <!-- Register Link -->
            <div class="text-center mt-10">
                <p class="text-gray-600">
                    Don't have an account?
                    <a href="register.php" class="text-yellow-600 font-bold hover:underline">Sign up free</a>
                </p>
            </div>

            <!-- Demo Info -->
            <div
                class="mt-8 p-5 bg-gradient-to-r from-amber-50 to-yellow-50 rounded-2xl border border-amber-200 text-center">
                <p class="font-bold text-amber-800 mb-2">Demo Login (Admin)</p>
                <p class="text-sm text-amber-700">Email: <code>admin@shop.com</code> • Password: <code>admin</code></p>
            </div>
        </div>

        <p class="text-center mt-10 text-gray-500 text-sm">
            © 2025 Cheeze Tea • Made with love & cheese foam
        </p>
    </div>
</div>

<style>
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animate-fade-in {
        animation: fadeIn 1s ease-out;
    }
</style>

<?php require 'includes/footer.php'; ?>