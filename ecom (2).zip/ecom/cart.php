<?php
$page_title = "Your Cart";
require 'includes/header.php';
require 'includes/navbar.php';
require 'includes/db.php';

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo '<div class="text-center py-20"><h2 class="text-4xl">Your cart is empty</h2><a href="products.php" class="text-yellow-dark underline text-xl">Continue Shopping</a></div>';
    require 'includes/footer.php';
    exit();
}
?>

<div class="max-w-5xl mx-auto px-4 py-12">
    <h1 class="playfair text-5xl text-center mb-10">Your Cart</h1>
    <div class="bg-white rounded-xl shadow-lg p-8">
        <?php
        $total = 0;
        foreach ($_SESSION['cart'] as $cart_key => $item):
            if (is_array($item)) {
                $product_id = $item['product_id'];
                $qty = $item['qty'];
                $size = $item['size'] ?? null;
            } else {
                $product_id = $cart_key;
                $qty = $item;
                $size = null;
            }

            $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$product_id]);
            $p = $stmt->fetch();
            if (!$p)
                continue;
            $unit_price = isset($item['unit_price']) ? $item['unit_price'] : $p['price'];
            $subtotal = $unit_price * $qty;
            $total += $subtotal;
            ?>
            <div class="flex items-center justify-between border-b py-6">
                <div class="flex items-center gap-6">
                    <img src="uploads/<?php echo htmlspecialchars($p['image']); ?>" class="w-24 h-24 object-cover rounded">
                    <div>
                        <h3 class="text-xl font-semibold"><?php echo htmlspecialchars($p['name']); ?></h3>
                        <p class="text-yellow-dark font-bold">₱<?php echo number_format($unit_price, 2); ?> ×
                            <?php echo $qty; ?>
                            <?php if ($size): ?>
                                <span class="text-gray-600 text-sm"> • <?php echo htmlspecialchars(ucfirst($size)); ?>
                                    (<?php echo $size === 'small' ? '8oz' : ($size === 'medium' ? '16oz' : '24oz'); ?>)</span>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
                <div class="flex items-center gap-4">
                    <p class="text-xl font-bold">₱<?php echo number_format($subtotal, 2); ?></p>
                    <a href="remove_from_cart.php?key=<?php echo urlencode($cart_key); ?>"
                        class="text-red-600 hover:underline">Remove</a>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="text-right mt-8">
            <p class="text-3xl font-bold">Total: ₱<?php echo number_format($total, 2); ?></p>
            <a href="/ecom/checkout.php"
                class="mt-4 inline-block bg-yellow-dark text-gray-900 px-10 py-4 rounded-lg text-xl hover:bg-yellow-warm font-semibold">Proceed
                to Checkout</a>
        </div>
    </div>
</div>

<?php require 'includes/footer.php'; ?>