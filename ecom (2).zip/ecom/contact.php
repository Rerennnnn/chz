<?php
$page_title = "Contact Us – Cheeze Tea Alaminos Laguna";
require 'includes/db.php';
require 'includes/header.php';
require 'includes/navbar.php';

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($name && $email && $message) {
        $data = "=== NEW MESSAGE (" . date('Y-m-d H:i:s') . ") ===\n";
        $data .= "Name: $name\nEmail: $email\nSubject: $subject\nMessage:\n$message\n\n";
        file_put_contents('contacts.txt', $data, FILE_APPEND | LOCK_EX);
        $success = "Thank you, $name! We received your message and will reply within 24 hours.";
    } else {
        $error = "Please fill in all required fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en" class="scroll-smooth">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?= $page_title ?></title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet" />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="stylesheet" href="assets/index.css?v=<?= time() ?>" />
</head>

<body class="bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 min-h-screen overflow-x-hidden">

    <!-- Floating Bubbles + Sparkles -->
    <div class="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <?php for ($i = 1; $i <= 20; $i++):
            $size = rand(18, 42);
            $dur = 16 + rand(0, 16);
            $del = $i * 0.8;
            $left = rand(1, 99);
            ?>
            <div class="bubble-container" style="left: <?= $left ?>%; animation-delay: <?= $del ?>s;">
                <div class="particle"
                    style="width: <?= $size ?>px; height: <?= $size ?>px; animation-duration: <?= $dur ?>s;"></div>
                <div class="sparkle" style="animation-duration: <?= $dur ?>s; animation-delay: <?= $del + 0.5 ?>s;"></div>
                <div class="sparkle" style="animation-duration: <?= $dur ?>s; animation-delay: <?= $del + 1.2 ?>s;"></div>
            </div>
        <?php endfor; ?>
    </div>

    <!-- HERO -->
    <section class="relative min-h-screen flex items-center justify-center px-6 text-center">
        <div class="container mx-auto max-w-5xl">
            <h1 class="text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-black leading-tight" data-aos="fade-up">
                <span class="hero-gradient-text">Get in</span><br>
                <span class="text-amber-800">Touch</span>
            </h1>
            <p class="text-lg sm:text-xl md:text-3xl font-medium text-amber-700 mt-6 sm:mt-8 md:mt-10"
                data-aos="fade-up" data-aos-delay="400">
                Questions? Love notes? Reservations? We’re here for you!
            </p>
        </div>
    </section>

    <!-- CONTACT INFO + FORM -->
    <section class="py-32">
        <div class="container mx-auto px-6 max-w-7xl">
            <div class="grid lg:grid-cols-2 gap-16 items-start">

                <!-- Contact Info -->
                <div class="space-y-6 md:space-y-10" data-aos="fade-right">
                    <div
                        class="bg-white/80 backdrop-blur-xl rounded-2xl md:rounded-3xl p-6 md:p-10 shadow-2xl border border-amber-200">
                        <div class="flex items-start md:items-center gap-4 md:gap-6 mb-6">
                            <div class="text-4xl md:text-6xl text-orange-600 flex-shrink-0">📍</div>
                            <div>
                                <h3 class="text-xl md:text-3xl font-bold text-amber-800">Our Location</h3>
                                <p class="text-sm md:text-lg mt-2 leading-relaxed">
                                    National Highway, Brgy. San Andres<br>
                                    Alaminos, Laguna 4001<br>
                                    Philippines
                                </p>
                            </div>
                        </div>
                    </div>

                    <div
                        class="bg-white/80 backdrop-blur-xl rounded-2xl md:rounded-3xl p-6 md:p-10 shadow-2xl border border-amber-200">
                        <div class="flex items-start md:items-center gap-4 md:gap-6 mb-6">
                            <div class="text-4xl md:text-6xl text-orange-600 flex-shrink-0">🕐</div>
                            <div>
                                <h3 class="text-xl md:text-3xl font-bold text-amber-800">Open Hours</h3>
                                <p class="text-lg md:text-2xl mt-2 text-amber-700 font-bold">10:00 AM – 10:00 PM</p>
                                <p class="text-sm md:text-lg text-gray-600">Daily (Closed Tuesdays)</p>
                            </div>
                        </div>
                    </div>

                    <div
                        class="bg-white/80 backdrop-blur-xl rounded-2xl md:rounded-3xl p-6 md:p-10 shadow-2xl border border-amber-200">
                        <div class="flex items-start md:items-center gap-4 md:gap-6">
                            <div class="text-4xl md:text-6xl text-orange-600 flex-shrink-0">📞</div>
                            <div>
                                <h3 class="text-xl md:text-3xl font-bold text-amber-800">Contact Us</h3>
                                <p class="text-sm md:text-lg mt-2">+63 912-345-6789</p>
                                <p class="text-xs md:text-base mt-2 text-gray-600">cheezeeteaa@gmail.com</p>
                            </div>
                        </div>
                    </div>

                    <!-- Social Links -->
                    <div class="text-center mt-8 md:mt-12">
                        <p class="text-lg md:text-2xl font-bold text-amber-800 mb-4 md:mb-6">Follow the Magic</p>
                        <div class="flex justify-center gap-4 md:gap-8 text-3xl md:text-5xl">
                            <a href="https://www.facebook.com/profile.php?id=100076206880064" target="_blank"
                                class="text-amber-700 hover:text-amber-900 transform hover:scale-125 transition duration-300">📘</a>
                            <a href="https://www.instagram.com/mfcheezetea/?utm_source=ig_web_button_share_sheet"
                                target="_blank"
                                class="text-amber-700 hover:text-amber-900 transform hover:scale-125 transition duration-300">📷</a>
                            <a href="https://tiktok.com/@cheezetea.alaminos" target="_blank"
                                class="text-amber-700 hover:text-amber-900 transform hover:scale-125 transition duration-300">🎵</a>
                        </div>
                    </div>
                </div>

                <!-- Contact Form -->
                <div data-aos="fade-left">
                    <div
                        class="bg-white/90 backdrop-blur-2xl rounded-2xl md:rounded-3xl shadow-2xl p-6 md:p-10 lg:p-16 border border-amber-200">
                        <h2 class="text-3xl md:text-5xl font-black text-amber-800 mb-6 md:mb-10 text-center">Send Us
                            Love</h2>

                        <?php if ($success): ?>
                            <div
                                class="bg-green-100 border border-green-400 text-green-800 px-4 md:px-8 py-4 md:py-6 rounded-xl md:rounded-2xl mb-6 md:mb-8 text-center text-sm md:text-lg font-semibold shadow-lg">
                                <?= htmlspecialchars($success) ?>
                            </div>
                        <?php elseif ($error): ?>
                            <div
                                class="bg-red-100 border border-red-400 text-red-800 px-4 md:px-8 py-4 md:py-6 rounded-xl md:rounded-2xl mb-6 md:mb-8 text-center text-sm md:text-lg shadow-lg">
                                <?= htmlspecialchars($error) ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" class="space-y-6 md:space-y-8">
                            <div class="grid md:grid-cols-2 gap-6 md:gap-8">
                                <input type="text" name="name" required placeholder="Your Name *"
                                    class="input w-full bg-white/70 border-2 border-amber-300 focus:border-amber-600 focus:outline-none focus:ring-4 focus:ring-amber-200/50 transition text-sm md:text-lg py-3 md:py-5 px-4 md:px-6 rounded-lg md:rounded-2xl"
                                    value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
                                <input type="email" name="email" required placeholder="Your Email *"
                                    class="input w-full bg-white/70 border-2 border-amber-300 focus:border-amber-600 focus:outline-none focus:ring-4 focus:ring-amber-200/50 transition text-sm md:text-lg py-3 md:py-5 px-4 md:px-6 rounded-lg md:rounded-2xl"
                                    value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                            </div>
                            <input type="text" name="subject" placeholder="Subject (Optional)"
                                class="input w-full bg-white/70 border-2 border-amber-300 focus:border-amber-600 focus:outline-none focus:ring-4 focus:ring-amber-200/50 transition text-sm md:text-lg py-3 md:py-5 px-4 md:px-6 rounded-lg md:rounded-2xl"
                                value="<?= htmlspecialchars($_POST['subject'] ?? '') ?>">
                            <textarea name="message" required rows="5" placeholder="Your Message *"
                                class="textarea w-full bg-white/70 border-2 border-amber-300 focus:border-amber-600 focus:outline-none focus:ring-4 focus:ring-amber-200/50 transition text-sm md:text-lg py-3 md:py-5 px-4 md:px-6 rounded-lg md:rounded-2xl"></textarea>

                            <div class="text-center">
                                <button type="submit"
                                    class="btn bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white text-sm md:text-lg px-8 md:px-24 py-4 md:py-6 rounded-full shadow-2xl hover:shadow-3xl transform hover:scale-110 transition font-bold w-full md:w-auto">
                                    Send Message
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- GOOGLE MAPS PLUGIN – FULLY INTERACTIVE & ERROR-FREE -->
    <section class="py-16 md:py-32 bg-gradient-to-b from-amber-50 to-yellow-100">
        <div class="container mx-auto px-4 md:px-6 text-center">
            <h2 class="text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-black text-amber-800 mb-10 md:mb-16"
                data-aos="fade-up">
                We're Here for You
            </h2>

            <!-- FULL INTERACTIVE MAP – WORKS LIKE A PLUGIN -->
            <div class="rounded-2xl md:rounded-3xl overflow-hidden shadow-2xl max-w-6xl mx-auto border-4 md:border-8 border-amber-400 hover:border-amber-600 transition-all duration-500"
                data-aos="zoom-in">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3867.567890123456!2d121.456789!3d14.063456!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33bd4e13f5e5b5f9%3A0x8f3e5f5e5f5e5f5e!2sCheeze%20Tea%20Alaminos%20Laguna!5e0!3m2!1sen!2sph!4v1739999999999!5m2!1sen!2sph"
                    width="100%" height="350" class="md:h-96 lg:h-520" style="border:0;" allowfullscreen=""
                    loading="lazy" referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>

            <!-- Backup Links (for if iframe fails) -->
            <div class="mt-8 md:mt-12 flex flex-col sm:flex-row gap-4 md:gap-8 justify-center px-4">
                <a href="https://www.google.com/maps/search/?api=1&query=Cheeze+Tea+Alaminos+Laguna" target="_blank"
                    class="btn bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-sm md:text-lg px-8 md:px-16 py-4 md:py-6 rounded-full shadow-2xl hover:shadow-3xl transform hover:scale-110 transition w-full sm:w-auto">
                    Open in Google Maps
                </a>
                <a href="https://www.google.com/maps/dir/?api=1&destination=Cheeze+Tea+Alaminos+Laguna" target="_blank"
                    class="btn bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-sm md:text-lg px-8 md:px-16 py-4 md:py-6 rounded-full shadow-2xl hover:shadow-3xl transform hover:scale-110 transition w-full sm:w-auto">
                    Get Directions
                </a>
            </div>

            <p class="mt-6 md:mt-8 text-base md:text-2xl text-amber-700 font-medium px-4">
                National Highway, Brgy. San Andres, Alaminos, Laguna
            </p>
        </div>
    </section>

    <?php require 'includes/footer.php'; ?>

    <script>
        AOS.init({
            duration: 1200,
            easing: 'ease-out-cubic',
            once: true
        });
    </script>
</body>

</html>