<?php
require '../includes/auth.php';
requireAdmin();
require '../includes/db.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    header('Location: products.php');
    exit();
}

// Fetch product to get image filename
$stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if ($product) {
    try {
        // Check for related order items to avoid foreign key constraint violation
        $chk = $pdo->prepare("SELECT COUNT(*) FROM order_items WHERE product_id = ?");
        $chk->execute([$id]);
        $refs = (int) $chk->fetchColumn();

        if ($refs > 0) {
            // Can't delete because product exists in past orders — soft-disable instead
            $upd = $pdo->prepare("UPDATE products SET status = 'inactive' WHERE id = ?");
            $upd->execute([$id]);
            header('Location: products.php?archived=1');
            exit();
        }

        // No order references — safe to delete image and product record
        $image_path = '../uploads/' . $product['image'];
        if (file_exists($image_path) && $product['image']) {
            @unlink($image_path);
        }

        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);

        header('Location: products.php?deleted=1');
        exit();
    } catch (Exception $e) {
        // Log or show a friendly message
        header('Location: products.php?error=' . urlencode('Unable to delete product: ' . $e->getMessage()));
        exit();
    }
}

header('Location: products.php');
exit();
?>