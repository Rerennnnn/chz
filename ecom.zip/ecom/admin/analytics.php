<?php
require '../includes/auth.php';
requireAdmin();
require '../includes/db.php';

$page_title = "Analytics - Cheeze Tea Admin";

// Prepare analytics data (safe: uses try/catch and checks table/column existence)
try {
    // Helper: check table exists
    function table_exists($pdo, $name)
    {
        $res = $pdo->query("SHOW TABLES LIKE '" . str_replace("'", "\\'", $name) . "'")->fetchAll();
        return !empty($res);
    }

    // Totals
    $total_orders = table_exists($pdo, 'orders') ? (int) $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn() : 0;
    $total_revenue = 0;
    if (table_exists($pdo, 'orders')) {
        // Sum finished/paid orders where possible
        $total_revenue = (float) $pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE (payment_status = 'paid' OR status = 'completed')")->fetchColumn();
    }

    $total_customers = table_exists($pdo, 'users') ? (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn() : 0;

    // New customers (last 30 days) — only if users.created_at exists
    $new_customers = 'N/A';
    if (table_exists($pdo, 'users')) {
        $col = $pdo->query("SHOW COLUMNS FROM users LIKE 'created_at'")->fetchAll();
        if (!empty($col)) {
            $new_customers = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer' AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetchColumn();
        }
    }

    $avg_order_value = 0;
    if ($total_orders > 0) {
        $avg_order_value = round($total_revenue / max(1, $total_orders));
    }

    // Sales last 30 days (daily)
    $sales_labels = [];
    $sales_data = [];
    if (table_exists($pdo, 'orders')) {
        // build last 30 days labels
        $days = [];
        for ($i = 29; $i >= 0; $i--) {
            $d = new DateTime();
            $d->modify("-{$i} days");
            $days[] = $d->format('Y-m-d');
        }

        $placeholders = implode(',', array_fill(0, count($days), '?'));
        $stmt = $pdo->prepare("SELECT DATE(created_at) as day, COALESCE(SUM(total),0) as revenue FROM orders WHERE DATE(created_at) IN ($placeholders) GROUP BY day ORDER BY day ASC");
        $stmt->execute($days);
        $rows = $stmt->fetchAll();
        $map = [];
        foreach ($rows as $r)
            $map[$r['day']] = (float) $r['revenue'];

        foreach ($days as $d) {
            $sales_labels[] = date('M j', strtotime($d));
            $sales_data[] = isset($map[$d]) ? $map[$d] : 0;
        }
    }

    // Top categories (by quantity sold)
    $cat_labels = [];
    $cat_data = [];
    if (table_exists($pdo, 'order_items') && table_exists($pdo, 'products')) {
        $stmt = $pdo->query("SELECT p.category AS category, COALESCE(SUM(oi.quantity),0) AS qty FROM order_items oi JOIN products p ON oi.product_id = p.id GROUP BY p.category ORDER BY qty DESC LIMIT 8");
        $rows = $stmt->fetchAll();
        foreach ($rows as $r) {
            $cat_labels[] = $r['category'] ?: 'Uncategorized';
            $cat_data[] = (int) $r['qty'];
        }
    }

    // Orders by hour today
    $hour_labels = [];
    $hour_data = array_fill(0, 24, 0);
    if (table_exists($pdo, 'orders')) {
        $rows = $pdo->query("SELECT HOUR(created_at) as hr, COUNT(*) as cnt FROM orders WHERE DATE(created_at) = CURDATE() GROUP BY hr")->fetchAll();
        foreach ($rows as $r) {
            $hour_data[(int) $r['hr']] = (int) $r['cnt'];
        }
        for ($h = 0; $h < 24; $h++)
            $hour_labels[] = sprintf('%02d:00', $h);
    }

    // Recent orders list
    $recent_orders = [];
    if (table_exists($pdo, 'orders')) {
        $stmt = $pdo->query("SELECT id, customer_name, total, status, created_at FROM orders ORDER BY created_at DESC LIMIT 10");
        $recent_orders = $stmt->fetchAll();
    }

} catch (Exception $e) {
    // If anything goes wrong, fall back to zeros and safe placeholders
    $total_orders = $total_revenue = $total_customers = 0;
    $new_customers = 'N/A';
    $avg_order_value = 0;
    $sales_labels = $sales_data = $cat_labels = $cat_data = $hour_labels = $hour_data = $recent_orders = [];
}

// JSON encode datasets for Chart.js
$sales_labels_json = json_encode($sales_labels);
$sales_data_json = json_encode($sales_data);
$cat_labels_json = json_encode($cat_labels);
$cat_data_json = json_encode($cat_data);
$hour_labels_json = json_encode($hour_labels);
$hour_data_json = json_encode($hour_data);
$recent_orders_json = json_encode($recent_orders);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title><?php echo $page_title; ?></title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="stylesheet" href="admin.css" />

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        .kpi {
            background: linear-gradient(90deg, #fffaf0, #fff7ed);
        }
    </style>
</head>

<body class="text-gray-800">
    <div class="flex min-h-screen">

        <!-- Sidebar -->
        <div class="w-64 sidebar bg-white shadow-2xl fixed h-full z-10 border-r border-yellow-100">
            <div class="p-8 text-center border-b border-yellow-100">
                <h1 class="playfair text-4xl font-bold text-yellow-600">Cheeze Tea</h1>
                <p class="text-yellow-700 text-sm">Admin Panel</p>
            </div>
            <nav class="mt-8">
                <a href="dashboard.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                    <i class="fas fa-tachometer-alt mr-3"></i> Dashboard
                </a>
                <a href="products.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                    <i class="fas fa-coffee mr-3"></i> Products
                </a>
                <a href="orders.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                    <i class="fas fa-shopping-bag mr-3"></i> Orders
                </a>
                <a href="customers.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                    <i class="fas fa-users mr-3"></i> Customers
                </a>
                <a href="riders.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                    <i class="fas fa-motorcycle mr-3"></i> Riders
                </a>
                <a href="analytics.php"
                    class="block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold">
                    <i class="fas fa-chart-line mr-3"></i> Analytics
                </a>
                <a href="../logout.php" class="block py-4 px-8 hover:bg-red-50 hover:text-red-600 transition mt-32">
                    <i class="fas fa-sign-out-alt mr-3"></i> Logout
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 ml-64 p-10">

            <div class="admin-topbar mb-8 flex items-center justify-between">
                <div>
                    <h1 class="playfair text-5xl font-bold text-yellow-700">Analytics</h1>
                    <p class="text-gray-600 mt-2">High-level site metrics and reporting</p>
                </div>
                <div>
                    <a href="../index.php" target="_blank" class="view-site-btn">View Site</a>
                </div>
            </div>

            <!-- KPI Cards -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="kpi rounded-2xl p-6 shadow-lg">
                    <div class="text-sm text-gray-600">Total Orders</div>
                    <div class="text-3xl font-bold mt-2"><?php echo number_format($total_orders); ?></div>
                    <div class="text-sm text-green-600 mt-1">&nbsp;</div>
                </div>
                <div class="kpi rounded-2xl p-6 shadow-lg">
                    <div class="text-sm text-gray-600">Revenue</div>
                    <div class="text-3xl font-bold mt-2">₱ <?php echo number_format($total_revenue, 2); ?></div>
                    <div class="text-sm text-green-600 mt-1">&nbsp;</div>
                </div>
                <div class="kpi rounded-2xl p-6 shadow-lg">
                    <div class="text-sm text-gray-600">New Customers (30d)</div>
                    <div class="text-3xl font-bold mt-2">
                        <?php echo is_numeric($new_customers) ? number_format($new_customers) : $new_customers; ?>
                    </div>
                    <div class="text-sm text-green-600 mt-1">&nbsp;</div>
                </div>
                <div class="kpi rounded-2xl p-6 shadow-lg">
                    <div class="text-sm text-gray-600">Avg. Order Value</div>
                    <div class="text-3xl font-bold mt-2">₱ <?php echo number_format($avg_order_value, 2); ?></div>
                    <div class="text-sm text-red-600 mt-1">&nbsp;</div>
                </div>
            </div>

            <!-- Charts -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div class="glass p-6 rounded-2xl shadow-lg">
                    <h3 class="text-xl font-bold mb-4">Sales (Last 30 days)</h3>
                    <canvas id="salesChart" height="220"></canvas>
                </div>

                <div class="glass p-6 rounded-2xl shadow-lg">
                    <h3 class="text-xl font-bold mb-4">Top Selling Categories</h3>
                    <canvas id="categoryChart" height="220"></canvas>
                </div>
            </div>

            <div class="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div class="glass p-6 rounded-2xl shadow-lg">
                    <h3 class="text-xl font-bold mb-4">Orders by Hour (Today)</h3>
                    <canvas id="hourChart" height="160"></canvas>
                </div>

                <div class="glass p-6 rounded-2xl shadow-lg">
                    <h3 class="text-xl font-bold mb-4">Recent Orders</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead>
                                <tr class="bg-gradient-to-r from-yellow-400 to-amber-500 text-white">
                                    <th class="px-4 py-3">Order #</th>
                                    <th class="px-4 py-3">Customer</th>
                                    <th class="px-4 py-3">Total</th>
                                    <th class="px-4 py-3">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($recent_orders)): ?>
                                    <?php foreach ($recent_orders as $order): ?>
                                        <tr class="border-b">
                                            <td class="px-4 py-3">#<?php echo htmlspecialchars($order['id']); ?></td>
                                            <td class="px-4 py-3">
                                                <?php echo htmlspecialchars($order['customer_name'] ?? 'Guest'); ?>
                                            </td>
                                            <td class="px-4 py-3">₱
                                                <?php echo number_format((float) ($order['total'] ?? 0), 2); ?>
                                            </td>
                                            <td class="px-4 py-3">
                                                <?php $st = $order['status'] ?? 'pending'; ?>
                                                <?php if ($st === 'completed' || $st === 'delivered'): ?>
                                                    <span class="badge badge-success"><?php echo ucfirst($st); ?></span>
                                                <?php elseif ($st === 'processing' || $st === 'paid'): ?>
                                                    <span class="badge badge-info"><?php echo ucfirst($st); ?></span>
                                                <?php elseif ($st === 'pending'): ?>
                                                    <span class="badge badge-warning"><?php echo ucfirst($st); ?></span>
                                                <?php else: ?>
                                                    <span class="badge badge-outline"><?php echo ucfirst($st); ?></span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="px-4 py-6 text-center text-gray-500">No recent orders</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- Chart rendering with dummy data - replace with AJAX/JSON endpoints as needed -->
    <script>
        // Parse server-side JSON datasets
        const salesLabels = <?php echo $sales_labels_json ?? '[]'; ?>;
        const salesData = <?php echo $sales_data_json ?? '[]'; ?>;
        const catLabels = <?php echo $cat_labels_json ?? '[]'; ?>;
        const catData = <?php echo $cat_data_json ?? '[]'; ?>;
        const hourLabels = <?php echo $hour_labels_json ?? '[]'; ?>;
        const hourData = <?php echo $hour_data_json ?? '[]'; ?>;

        // Sales line chart
        const salesCtx = document.getElementById('salesChart')?.getContext('2d');
        if (salesCtx) {
            new Chart(salesCtx, {
                type: 'line',
                data: {
                    labels: salesLabels,
                    datasets: [{ label: 'Revenue', data: salesData, backgroundColor: 'rgba(245,158,11,0.08)', borderColor: '#f59e0b', fill: true, tension: 0.35 }]
                },
                options: { responsive: true, plugins: { legend: { display: false } } }
            });
        }

        // Category doughnut
        const catCtx = document.getElementById('categoryChart')?.getContext('2d');
        if (catCtx) {
            new Chart(catCtx, {
                type: 'doughnut',
                data: { labels: catLabels, datasets: [{ data: catData, backgroundColor: ['#f59e0b', '#fb7185', '#f97316', '#fbbf24', '#60a5fa', '#34d399', '#a78bfa', '#f472b6'] }] },
                options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
            });
        }

        // Hour bar chart
        const hourCtx = document.getElementById('hourChart')?.getContext('2d');
        if (hourCtx) {
            new Chart(hourCtx, { type: 'bar', data: { labels: hourLabels, datasets: [{ label: 'Orders', data: hourData, backgroundColor: '#f59e0b' }] }, options: { responsive: true, plugins: { legend: { display: false } } } });
        }
    </script>

</body>

</html>