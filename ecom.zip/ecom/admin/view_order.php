<?php 
require '../includes/auth.php'; 
requireAdmin(); 
require '../includes/db.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    header('Location: orders.php');
    exit();
}

// Check if orders table exists
$tables = $pdo->query("SHOW TABLES LIKE 'orders'")->fetchAll();

if (empty($tables)) {
    header('Location: orders.php');
    exit();
}

// Fetch order
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->execute([$id]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: orders.php');
    exit();
}

$page_title = "Order #" . $id . " - Cheeze Tea";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>

    <!-- Tailwind + DaisyUI -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet">

    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            background: linear-gradient(135deg, #fffbeb 0%, #fefce8 100%);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
        }
        .playfair { font-family: 'Playfair Display', serif; }
        .glass {
            background: rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 15px 35px rgba(251, 191, 36, 0.15);
        }
    </style>
</head>
<body class="text-gray-800">

<div class="flex min-h-screen">

    <!-- Sidebar -->
    <div class="w-64 bg-white shadow-2xl fixed h-full z-10 border-r border-yellow-100">
        <div class="p-8 text-center border-b border-yellow-100">
            <h1 class="playfair text-4xl font-bold text-yellow-600">Cheeze Tea</h1>
            <p class="text-yellow-700 text-sm">Admin Panel</p>
        </div>
        <nav class="mt-8">
            <a href="dashboard.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                <i class="fas fa-tachometer-alt mr-3"></i> Dashboard
            </a>
            <a href="products.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                <i class="fas fa-coffee mr-3"></i> Products
            </a>
            <a href="orders.php" class="block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold">
                <i class="fas fa-shopping-bag mr-3"></i> Orders
            </a>
            <a href="customers.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                <i class="fas fa-users mr-3"></i> Customers
            </a>
            <a href="riders.php" class="block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold">
                <i class="fas fa-motorcycle mr-3"></i> Riders
            </a>
            <a href="../logout.php" class="block py-4 px-8 hover:bg-red-50 hover:text-red-600 transition mt-32">
                <i class="fas fa-sign-out-alt mr-3"></i> Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="flex-1 ml-64 p-10">

        <!-- Header -->
        <div class="mb-10 flex justify-between items-center">
            <div>
                <h1 class="playfair text-5xl font-bold text-yellow-700">Order #<?php echo htmlspecialchars($order['id']); ?></h1>
                <p class="text-gray-600 mt-2">Order Details & Information</p>
            </div>
            <a href="orders.php" class="px-6 py-3 bg-gray-600 text-white rounded-xl hover:bg-gray-700 transition">
                <i class="fas fa-arrow-left mr-2"></i> Back to Orders
            </a>
        </div>

        <!-- Order Info -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <!-- Customer Info -->
            <div class="glass rounded-3xl p-8">
                <h2 class="text-2xl font-bold text-yellow-700 mb-6 flex items-center gap-2">
                    <i class="fas fa-user-circle text-yellow-600"></i> Customer Information
                </h2>
                <div class="space-y-4">
                    <div>
                        <p class="text-sm text-gray-600">Name</p>
                        <p class="text-xl font-semibold text-gray-800"><?php echo htmlspecialchars($order['customer_name'] ?? 'N/A'); ?></p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Email</p>
                        <p class="text-xl font-semibold text-gray-800"><?php echo htmlspecialchars($order['customer_email'] ?? 'N/A'); ?></p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Phone</p>
                        <p class="text-xl font-semibold text-gray-800"><?php echo htmlspecialchars($order['customer_phone'] ?? 'N/A'); ?></p>
                    </div>
                </div>
            </div>

            <!-- Order Status -->
            <div class="glass rounded-3xl p-8">
                <h2 class="text-2xl font-bold text-yellow-700 mb-6 flex items-center gap-2">
                    <i class="fas fa-info-circle text-yellow-600"></i> Order Status
                </h2>
                <div class="space-y-4">
                    <div>
                        <p class="text-sm text-gray-600">Status</p>
                        <p class="text-xl font-semibold">
                            <span class="badge <?php 
                                $status = $order['status'] ?? 'pending';
                                echo $status === 'completed' ? 'badge-success' : ($status === 'processing' ? 'badge-warning' : 'badge-error'); 
                            ?>">
                                <?php echo ucfirst($status); ?>
                            </span>
                        </p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Order Date</p>
                        <p class="text-xl font-semibold text-gray-800"><?php echo date('M d, Y H:i A', strtotime($order['created_at'])); ?></p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Total Amount</p>
                        <p class="text-3xl font-bold text-yellow-600">₱<?php echo number_format($order['total_amount'] ?? 0, 2); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Shipping Address -->
        <div class="glass rounded-3xl p-8 mb-8">
            <h2 class="text-2xl font-bold text-yellow-700 mb-6 flex items-center gap-2">
                <i class="fas fa-map-marker-alt text-yellow-600"></i> Shipping Address
            </h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                    <p class="text-sm text-gray-600">Full Address</p>
                    <p class="text-lg font-semibold text-gray-800"><?php echo htmlspecialchars($order['shipping_address'] ?? 'N/A'); ?></p>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Notes</p>
                    <p class="text-lg font-semibold text-gray-800"><?php echo htmlspecialchars($order['notes'] ?? 'No notes'); ?></p>
                </div>
            </div>
        </div>

        <!-- Back Button -->
        <div class="text-center">
            <a href="orders.php" class="inline-flex items-center gap-2 px-8 py-4 bg-gray-600 text-white font-bold rounded-2xl hover:bg-gray-700 transition">
                <i class="fas fa-arrow-left"></i> Back to Orders
            </a>
        </div>

    </div>
</div>

</body>
</html>
