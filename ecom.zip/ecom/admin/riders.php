<?php
// riders.php

require '../includes/auth.php';
requireAdmin();
require '../includes/db.php'; // must connect to DB "ecommerce"

$page_title = "Manage Riders - Cheeze Tea";

// Messages
$success_message = null; // for assigning rider
$error_message = null;
$settings_success = null; // for payout settings
$settings_error = null;

/**
 * ENSURE payout_settings TABLE EXISTS (only base_pay)
 */
try {
    // Create table if not exists
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS payout_settings (
            id INT PRIMARY KEY DEFAULT 1,
            base_pay DECIMAL(10,2) NOT NULL DEFAULT 30.00
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    // Ensure row id = 1 exists
    $stmt = $pdo->query("SELECT * FROM payout_settings WHERE id = 1");
    $payout_settings = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$payout_settings) {
        $pdo->prepare("
            INSERT INTO payout_settings (id, base_pay)
            VALUES (1, 30.00)
        ")->execute();

        $payout_settings = [
            'id' => 1,
            'base_pay' => 30.00,
        ];
    }
} catch (PDOException $e) {
    $payout_settings = [
        'base_pay' => 30.00,
    ];
    $settings_error = "Error checking payout settings: " . $e->getMessage();
}

/**
 * HANDLE SAVING GLOBAL PAYOUT SETTINGS (base pay only)
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_payout_settings'])) {
    $base_pay = isset($_POST['base_pay']) ? (float) $_POST['base_pay'] : 0;

    try {
        $stmt = $pdo->prepare("
            UPDATE payout_settings
            SET base_pay = ?
            WHERE id = 1
        ");
        $stmt->execute([$base_pay]);

        $payout_settings['base_pay'] = $base_pay;
        $settings_success = "Base payout updated successfully.";
    } catch (PDOException $e) {
        $settings_error = "Error updating payout settings: " . $e->getMessage();
    }
}

/**
 * HANDLE ASSIGNING RIDER (convert user → rider)
 */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['user_id'])
    && !isset($_POST['save_payout_settings'])
) {
    $user_id = (int) $_POST['user_id'];

    try {
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Update role to rider
        $stmt = $pdo->prepare("UPDATE users SET role = 'rider' WHERE id = ?");
        $stmt->execute([$user_id]);

        if ($stmt->rowCount() > 0) {
            // Redirect so refresh doesn't resubmit POST
            header("Location: riders.php?success=1");
            exit;
        } else {
            // No rows changed (ID may not exist, or already rider)
            $error_message = "No user was updated. The user may not exist or is already a rider.";
        }

    } catch (PDOException $e) {
        $error_message = "Database error while assigning rider: " . $e->getMessage();
    }
}

// Success message after redirect
if (isset($_GET['success']) && $_GET['success'] === '1') {
    $success_message = "User assigned as rider successfully!";
}

/**
 * FETCH NON-RIDERS (for Add Rider panel)
 */
try {
    $stmt = $pdo->query("SELECT * FROM users WHERE role NOT IN ('admin', 'rider') ORDER BY name ASC");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $users = [];
    $error_message = "Error loading users: " . $e->getMessage();
}

/**
 * FETCH RIDERS (for main table)
 */
try {
    $stmt = $pdo->query("SELECT * FROM users WHERE role = 'rider' ORDER BY id DESC");
    $riders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $riders = [];
    $error_message = "Error loading riders: " . $e->getMessage();
}

/**
 * FETCH RIDER EARNINGS SUMMARY
 * (relies on rider_earnings.total being final payout per delivery)
 */
$rider_earnings_map = [];
try {
    $hasEarnings = !empty($pdo->query("SHOW TABLES LIKE 'rider_earnings'")->fetchAll());
    if ($hasEarnings) {
        $earnStmt = $pdo->query("
            SELECT rider_id, COUNT(*) AS deliveries_completed, SUM(total) AS total_earned
            FROM rider_earnings
            GROUP BY rider_id
        ");
        foreach ($earnStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $rider_earnings_map[(int) $row['rider_id']] = $row;
        }
    }
} catch (PDOException $e) {
    // silently ignore; page still works
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title>

    <!-- Tailwind + DaisyUI -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet">

    <!-- Fonts & Icons -->
    <link
        href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            background: linear-gradient(135deg, #fffbeb 0%, #fefce8 100%);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
        }

        .playfair {
            font-family: 'Playfair Display', serif;
        }

        .glass {
            background: rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 15px 35px rgba(251, 191, 36, 0.15);
        }

        .table-row:hover {
            background: rgba(253, 230, 138, 0.15) !important;
        }

        /* Fix dark-looking inputs inside glass panels */
        .input,
        input.input-bordered {
            background-color: #ffffff !important;
            color: #1f2933 !important;
        }
    </style>
    <link rel="stylesheet" href="admin.css">
</head>

<body class="text-gray-800">

    <div class="flex min-h-screen">

        <!-- Sidebar -->
        <div class="w-64 sidebar bg-white shadow-2xl fixed h-full z-10 border-r border-yellow-100">
            <div class="p-8 text-center border-b border-yellow-100">
                <h1 class="playfair text-4xl font-bold text-yellow-600">Cheeze Tea</h1>
                <p class="text-yellow-700 text-sm">Admin Panel</p>
            </div>
            <nav class="mt-8">
                <a href="dashboard.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                    <i class="fas fa-tachometer-alt mr-3"></i> Dashboard
                </a>
                <a href="products.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                    <i class="fas fa-coffee mr-3"></i> Products
                </a>
                <a href="orders.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                    <i class="fas fa-shopping-bag mr-3"></i> Orders
                </a>
                <a href="customers.php" class="block py-4 px-8 hover:bg-yellow-50 transition">
                    <i class="fas fa-users mr-3"></i> Customers
                </a>
                <a href="riders.php"
                    class="block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold">
                    <i class="fas fa-motorcycle mr-3"></i> Riders
                </a>
                <a href="analytics.php"
                    class="block py-4 px-8 hover:bg-yellow-50 hover:border-l-4 hover:border-yellow-500 transition">
                    <i class="fas fa-chart-line mr-3"></i> Analytics
                </a>
                <a href="../logout.php" class="block py-4 px-8 hover:bg-red-50 hover:text-red-600 transition mt-32">
                    <i class="fas fa-sign-out-alt mr-3"></i> Logout
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 ml-64 p-10">

            <!-- Header -->
            <div class="admin-topbar">
                <div>
                    <h1 class="playfair text-5xl font-bold text-yellow-700">Manage Riders</h1>
                    <p class="text-gray-600 mt-2">View, assign, and configure rider payouts.</p>
                </div>
                <div class="flex items-center gap-4">
                    <a href="../index.php" target="_blank" class="view-site-btn">View Site</a>
                    <button id="toggleAddRider" class="btn btn-primary">
                        <i class="fas fa-plus mr-2"></i> Add Rider
                    </button>
                </div>
            </div>

            <!-- Messages -->
            <?php if ($settings_success): ?>
                <div class="alert alert-success mb-4">
                    <?php echo htmlspecialchars($settings_success); ?>
                </div>
            <?php endif; ?>
            <?php if ($settings_error): ?>
                <div class="alert alert-error mb-4">
                    <?php echo htmlspecialchars($settings_error); ?>
                </div>
            <?php endif; ?>

            <?php if ($success_message): ?>
                <div class="alert alert-success mb-4">
                    <?php echo htmlspecialchars($success_message); ?>
                </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
                <div class="alert alert-error mb-4">
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>

            <!-- GLOBAL RIDER PAYOUT SETTINGS PANEL (base pay only) -->
            <div class="glass rounded-3xl p-6 mb-8">
                <h3 class="text-2xl font-semibold text-yellow-700 mb-4 flex items-center gap-2">
                    <i class="fas fa-wallet"></i> Rider Payout Settings
                </h3>
                <p class="text-gray-600 mb-4 text-sm">
                    This is the fixed amount each rider earns for every <strong>verified</strong> delivery.
                </p>

                <form method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
                    <div>
                        <label class="label text-sm font-semibold text-gray-700">
                            Base Pay per Delivery (₱)
                        </label>
                        <input type="number" name="base_pay" step="0.01" min="0"
                            value="<?php echo htmlspecialchars($payout_settings['base_pay']); ?>"
                            class="input input-bordered w-full bg-white text-gray-800">
                    </div>
                    <div class="md:col-span-1 mt-4 md:mt-7">
                        <button type="submit" name="save_payout_settings" class="btn btn-success">
                            <i class="fas fa-save mr-2"></i> Save Payout Settings
                        </button>
                    </div>
                </form>
            </div>

            <!-- Add Rider Panel (hidden by default) -->
            <div id="addRiderPanel" class="glass rounded-3xl p-6 mb-6 hidden">
                <h3 class="text-xl font-semibold text-yellow-700 mb-4">Select a user to assign as rider:</h3>
                <input type="text" id="userSearch" placeholder="Search users..."
                    class="input input-bordered w-full mb-4 bg-white text-gray-800" />
                <div id="userList" class="space-y-2 max-h-64 overflow-y-auto">
                    <?php if (!empty($users)): ?>
                        <?php foreach ($users as $user): ?>
                            <div
                                class="flex justify-between items-center p-3 bg-white rounded-lg shadow hover:bg-yellow-50 transition">
                                <div>
                                    <p class="font-semibold">
                                        <?php echo htmlspecialchars($user['name'] ?? 'No Name'); ?>
                                    </p>
                                    <p class="text-gray-600 text-sm">
                                        <?php echo htmlspecialchars($user['email'] ?? 'No Email'); ?>
                                    </p>
                                </div>
                                <form method="POST" class="ml-4">
                                    <input type="hidden" name="user_id" value="<?php echo (int) $user['id']; ?>">
                                    <button type="submit" class="btn btn-success btn-sm">
                                        <i class="fas fa-user-plus mr-1"></i> Make Rider
                                    </button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-gray-500 text-center">No available users to assign as riders.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Riders Table -->
            <div class="glass rounded-3xl overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="bg-gradient-to-r from-yellow-400 to-amber-500 text-white">
                                <th class="px-8 py-6 text-left">ID</th>
                                <th class="px-8 py-6 text-left">Name</th>
                                <th class="px-8 py-6 text-left">Email</th>
                                <th class="px-8 py-6 text-left">Phone</th>
                                <th class="px-8 py-6 text-center">Deliveries</th>
                                <th class="px-8 py-6 text-center">Total Earned</th>
                                <th class="px-8 py-6 text-center">Joined</th>
                                <th class="px-8 py-6 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-yellow-100">
                            <?php if (!empty($riders)): ?>
                                <?php foreach ($riders as $rider):
                                    $rid = (int) $rider['id'];
                                    $earnSummary = $rider_earnings_map[$rid] ?? null;
                                    ?>
                                    <tr class="table-row transition-all duration-300 hover:bg-yellow-50/50">
                                        <td class="px-8 py-6">#<?php echo htmlspecialchars($rider['id']); ?></td>
                                        <td class="px-8 py-6"><?php echo htmlspecialchars($rider['name']); ?></td>
                                        <td class="px-8 py-6"><?php echo htmlspecialchars($rider['email']); ?></td>
                                        <td class="px-8 py-6"><?php echo htmlspecialchars($rider['phone'] ?? 'N/A'); ?></td>
                                        <td class="px-8 py-6 text-center">
                                            <?php if ($earnSummary): ?>
                                                <span class="font-semibold">
                                                    <?php echo (int) $earnSummary['deliveries_completed']; ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="text-gray-400 text-sm">0</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-8 py-6 text-center">
                                            <?php if ($earnSummary): ?>
                                                <span class="font-bold text-green-600">
                                                    ₱<?php echo number_format((float) $earnSummary['total_earned'], 2); ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="text-gray-400 text-sm">₱0.00</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-8 py-6 text-center">
                                            <?php echo !empty($rider['created_at']) ? date('M d, Y', strtotime($rider['created_at'])) : 'N/A'; ?>
                                        </td>
                                        <td class="px-8 py-6 text-center">
                                            <a href="manage_rider.php?id=<?php echo $rider['id']; ?>"
                                                class="btn btn-sm btn-outline btn-primary">
                                                <i class="fas fa-cog mr-1"></i> Manage
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center py-16 text-gray-500">
                                        <i class="fas fa-motorcycle text-6xl mb-4 block text-yellow-300"></i>
                                        <p class="text-2xl">No riders yet.</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>

    <script>
        // Toggle Add Rider Panel
        document.getElementById('toggleAddRider').addEventListener('click', function () {
            const panel = document.getElementById('addRiderPanel');
            panel.classList.toggle('hidden');
        });

        // Simple Search Filter
        const userSearch = document.getElementById('userSearch');
        if (userSearch) {
            userSearch.addEventListener('input', function () {
                const filter = this.value.toLowerCase();
                document.querySelectorAll('#userList > div').forEach(userDiv => {
                    const nameEl = userDiv.querySelector('p');
                    const emailEl = userDiv.querySelectorAll('p')[1];

                    const name = nameEl ? nameEl.textContent.toLowerCase() : '';
                    const email = emailEl ? emailEl.textContent.toLowerCase() : '';

                    if (name.includes(filter) || email.includes(filter)) {
                        userDiv.style.display = 'flex';
                    } else {
                        userDiv.style.display = 'none';
                    }
                });
            });
        }
    </script>

</body>

</html>