<?php
require '../includes/auth.php';
require '../includes/db.php';

// --- ADMIN ACCESS ONLY ---
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

if (!isset($_GET['id'])) {
    die("No rider selected.");
}

$rider_id = (int)$_GET['id'];
$success = null;
$error = null;

/* ============================================================
   FETCH RIDER INFORMATION
============================================================ */
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'rider'");
$stmt->execute([$rider_id]);
$rider = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$rider) {
    die("Rider not found.");
}


/* ============================================================
   VERIFY DELIVERY (ADMIN APPROVAL)
============================================================ */
if (isset($_POST['verify_delivery'])) {
    $delivery_id = (int)$_POST['delivery_id'];

    try {
        // 1. Check delivery exists & belongs to this rider
        $d = $pdo->prepare("SELECT * FROM deliveries WHERE id = ? AND rider_id = ?");
        $d->execute([$delivery_id, $rider_id]);
        $delivery = $d->fetch(PDO::FETCH_ASSOC);

        if (!$delivery) {
            throw new Exception("Delivery not found.");
        }

        // 2. Check proof exists
        $proofCheck = $pdo->prepare("SELECT COUNT(*) FROM delivery_proofs WHERE delivery_id = ?");
        $proofCheck->execute([$delivery_id]);
        if ($proofCheck->fetchColumn() == 0) {
            throw new Exception("Cannot verify. No delivery proof uploaded.");
        }

        // 3. Prevent double verification
        if ($delivery['status'] === 'delivered') {
            throw new Exception("This delivery has already been verified.");
        }

        // 4. Mark as delivered
        $pdo->prepare("
            UPDATE deliveries
            SET status = 'delivered', delivered_at = NOW()
            WHERE id = ?
        ")->execute([$delivery_id]);

        // 5. Insert rider earnings
        $earn = $pdo->prepare("
            INSERT INTO rider_earnings (rider_id, delivery_id, base_pay, distance_km, rate_per_km, bonus, penalty)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        $base_pay    = 30.00;
        $rate_per_km = 10.00;

        $earn->execute([
            $rider_id,
            $delivery_id,
            $base_pay,
            $delivery['distance_km'],
            $rate_per_km,
            0.00,   // bonus
            0.00    // penalty
        ]);

        // 6. Update rider status to AVAILABLE
        $pdo->prepare("
            UPDATE rider_status
            SET status = 'available', last_update = NOW()
            WHERE rider_id = ?
        ")->execute([$rider_id]);

        // 7. Log
        $pdo->prepare("
            INSERT INTO rider_logs (rider_id, log_type, description)
            VALUES (?, 'delivery_verified', CONCAT('Admin verified delivery ID ', ?))
        ")->execute([$rider_id, $delivery_id]);

        $success = "Delivery #$delivery_id successfully verified and payout released.";

    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}


/* ============================================================
   FETCH DELIVERIES FOR THIS RIDER
============================================================ */
$deliveries = $pdo->prepare("
    SELECT * FROM deliveries 
    WHERE rider_id = ?
    ORDER BY created_at DESC
");
$deliveries->execute([$rider_id]);
$deliveries = $deliveries->fetchAll(PDO::FETCH_ASSOC);

/* ============================================================
   FETCH LOGS
============================================================ */
$logs = $pdo->prepare("
    SELECT * FROM rider_logs
    WHERE rider_id = ?
    ORDER BY created_at DESC
");
$logs->execute([$rider_id]);
$logs = $logs->fetchAll(PDO::FETCH_ASSOC);

/* ============================================================
   FETCH EARNINGS
============================================================ */
$earnings = $pdo->prepare("
    SELECT * FROM rider_earnings
    WHERE rider_id = ?
    ORDER BY created_at DESC
");
$earnings->execute([$rider_id]);
$earnings = $earnings->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Rider</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 p-6">

<div class="max-w-5xl mx-auto">

    <h1 class="text-3xl font-bold mb-6">Manage Rider: <?php echo $rider['name']; ?></h1>

    <?php if ($success): ?>
        <div class="bg-green-200 p-4 rounded mb-4"><?php echo $success; ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="bg-red-200 p-4 rounded mb-4"><?php echo $error; ?></div>
    <?php endif; ?>


    <!-- RIDER INFO -->
    <div class="bg-white p-4 rounded shadow mb-8">
        <h2 class="text-xl font-semibold mb-2">Rider Info</h2>
        <p><strong>Name:</strong> <?php echo $rider['name']; ?></p>
        <p><strong>Email:</strong> <?php echo $rider['email']; ?></p>
        <p><strong>Phone:</strong> <?php echo $rider['phone']; ?></p>
        <p><strong>Joined:</strong> <?php echo $rider['created_at']; ?></p>
    </div>



    <!-- RIDER DELIVERIES -->
    <div class="bg-white p-4 rounded shadow mb-8">
        <h2 class="text-xl font-semibold mb-4">Deliveries</h2>

        <?php if (empty($deliveries)): ?>
            <p class="text-gray-500">No deliveries yet.</p>
        <?php else: ?>
            <?php foreach ($deliveries as $d): ?>
                <div class="border-b py-4">

                    <p><strong>Delivery #<?php echo $d['id']; ?></strong></p>
                    <p>Order ID: <?php echo $d['order_id']; ?></p>
                    <p>Status: <span class="font-bold"><?php echo $d['status']; ?></span></p>
                    <p>Distance: <?php echo $d['distance_km']; ?> km</p>

                    <!-- SHOW PROOFS -->
                    <?php
                    $proofs = $pdo->prepare("SELECT * FROM delivery_proofs WHERE delivery_id = ?");
                    $proofs->execute([$d['id']]);
                    $proofs = $proofs->fetchAll(PDO::FETCH_ASSOC);
                    ?>

                    <?php if (!empty($proofs)): ?>
                        <p class="mt-2 font-semibold">Delivery Proof:</p>
                        <div class="flex gap-2 mt-2">
                            <?php foreach ($proofs as $p): ?>
                                <img src="<?php echo $p['image_path']; ?>" alt="proof" class="w-32 h-32 object-cover rounded">
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-red-500 mt-2">No proof uploaded yet.</p>
                    <?php endif; ?>

                    <!-- VERIFY BUTTON (only if not verified yet) -->
                    <?php if ($d['status'] !== 'delivered'): ?>
                        <form method="POST" class="mt-3">
                            <input type="hidden" name="delivery_id" value="<?php echo $d['id']; ?>">
                            <button name="verify_delivery" class="bg-green-600 text-white px-4 py-2 rounded">
                                Verify Successful Delivery & Pay Rider
                            </button>
                        </form>
                    <?php else: ?>
                        <p class="text-green-600 mt-2 font-semibold">Delivery Verified ✓</p>
                    <?php endif; ?>

                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>



    <!-- RIDER EARNINGS -->
    <div class="bg-white p-4 rounded shadow mb-8">
        <h2 class="text-xl font-semibold mb-4">Earnings</h2>

        <?php if (empty($earnings)): ?>
            <p class="text-gray-500">No earnings yet.</p>
        <?php else: ?>
            <?php foreach ($earnings as $e): ?>
                <p class="border-b py-2">
                    Delivery #<?php echo $e['delivery_id']; ?> — 
                    ₱<?php echo number_format($e['total'], 2); ?> earned 
                    (<?php echo $e['distance_km']; ?> km)
                    on <?php echo $e['created_at']; ?>
                </p>
            <?php endforeach; ?>
        <?php endif; ?>

    </div>



    <!-- RIDER LOGS -->
    <div class="bg-white p-4 rounded shadow">
        <h2 class="text-xl font-semibold mb-4">Logs</h2>

        <?php if (empty($logs)): ?>
            <p class="text-gray-500">No logs.</p>
        <?php else: ?>
            <?php foreach ($logs as $log): ?>
                <p class="border-b py-2 text-sm">
                    <strong><?php echo $log['log_type']; ?></strong> — 
                    <?php echo $log['description']; ?> 
                    <span class="text-gray-500">(<?php echo $log['created_at']; ?>)</span>
                </p>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

</div>

</body>
</html>
