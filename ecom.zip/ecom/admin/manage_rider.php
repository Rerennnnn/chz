<?php
require '../includes/auth.php';
require '../includes/db.php';

// --- ADMIN ACCESS ONLY ---
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

if (!isset($_GET['id'])) {
    die("No rider selected.");
}

$rider_id = (int) $_GET['id'];
$success = null;
$error = null;

/* ============================================================
   FETCH RIDER INFORMATION
============================================================ */
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'rider'");
$stmt->execute([$rider_id]);
$rider = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$rider) {
    die("Rider not found.");
}

/**
 * HANDLE UPDATING RIDER INFO
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_rider'])) {
    $name = isset($_POST['rider_name']) ? trim($_POST['rider_name']) : '';
    $email = isset($_POST['rider_email']) ? trim($_POST['rider_email']) : '';
    $phone = isset($_POST['rider_phone']) ? trim($_POST['rider_phone']) : '';

    if (empty($name) || empty($email)) {
        $error = "Name and email are required.";
    } else {
        try {
            $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, phone = ? WHERE id = ? AND role = 'rider'");
            $stmt->execute([$name, $email, $phone, $rider_id]);

            if ($stmt->rowCount() > 0) {
                // Refresh rider data
                $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'rider'");
                $stmt->execute([$rider_id]);
                $rider = $stmt->fetch(PDO::FETCH_ASSOC);
                $success = "Rider information updated successfully!";
            } else {
                $error = "No changes made.";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}


/* ============================================================
   VERIFY DELIVERY (ADMIN APPROVAL)
============================================================ */
if (isset($_POST['verify_delivery'])) {
    $delivery_id = (int) $_POST['delivery_id'];

    try {
        // Begin transaction to make verification and stock updates atomic
        $pdo->beginTransaction();
        // 1. Check delivery exists & belongs to this rider
        $d = $pdo->prepare("SELECT * FROM deliveries WHERE id = ? AND rider_id = ?");
        $d->execute([$delivery_id, $rider_id]);
        $delivery = $d->fetch(PDO::FETCH_ASSOC);

        if (!$delivery) {
            throw new Exception("Delivery not found.");
        }

        // 2. Check proof exists
        $proofCheck = $pdo->prepare("SELECT COUNT(*) FROM delivery_proofs WHERE delivery_id = ?");
        $proofCheck->execute([$delivery_id]);
        if ($proofCheck->fetchColumn() == 0) {
            throw new Exception("Cannot verify. No delivery proof uploaded.");
        }

        // 3. Prevent double verification
        if ($delivery['status'] === 'delivered') {
            throw new Exception("This delivery has already been verified.");
        }

        // 4. Mark as delivered
        $pdo->prepare("
            UPDATE deliveries
            SET status = 'delivered', delivered_at = NOW()
            WHERE id = ?
        ")->execute([$delivery_id]);

        // 5. Insert rider earnings
        $earn = $pdo->prepare("
            INSERT INTO rider_earnings (rider_id, order_id, total, status)
            VALUES (?, ?, ?, ?)
        ");

        $earn->execute([
            $rider_id,
            $delivery['order_id'],
            50.00, // Fixed earnings per delivery
            'pending'
        ]);

        // 6. Update rider status to AVAILABLE
        $pdo->prepare("
            UPDATE rider_status
            SET status = 'available', last_update = NOW()
            WHERE rider_id = ?
        ")->execute([$rider_id]);

        // 7. Log
        $pdo->prepare("
            INSERT INTO rider_logs (rider_id, log_type, description)
            VALUES (?, 'delivery_verified', CONCAT('Admin verified delivery ID ', ?))
        ")->execute([$rider_id, $delivery_id]);

        // Decrement stock for ordered items
        $itemsStmt = $pdo->prepare("SELECT product_id, quantity FROM order_items WHERE order_id = ?");
        $itemsStmt->execute([$delivery['order_id']]);
        $orderItems = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
        if (!empty($orderItems)) {
            $stockUpd = $pdo->prepare("UPDATE products SET stock = GREATEST(COALESCE(stock,0) - ?, 0) WHERE id = ?");
            foreach ($orderItems as $it) {
                $stockUpd->execute([(int) $it['quantity'], (int) $it['product_id']]);
            }
        }

        $pdo->commit();

        $success = "Delivery #$delivery_id successfully verified and payout released. Stock updated.";

    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}


/* ============================================================
   FETCH DELIVERIES FOR THIS RIDER
============================================================ */
$deliveries = $pdo->prepare("
    SELECT * FROM deliveries 
    WHERE rider_id = ?
    ORDER BY created_at DESC
");
$deliveries->execute([$rider_id]);
$deliveries = $deliveries->fetchAll(PDO::FETCH_ASSOC);

/* ============================================================
   FETCH LOGS
============================================================ */
$logs = $pdo->prepare("
    SELECT * FROM rider_logs
    WHERE rider_id = ?
    ORDER BY created_at DESC
");
$logs->execute([$rider_id]);
$logs = $logs->fetchAll(PDO::FETCH_ASSOC);

/* ============================================================
   FETCH EARNINGS
============================================================ */
$earnings = $pdo->prepare("
    SELECT * FROM rider_earnings
    WHERE rider_id = ?
    ORDER BY created_at DESC
");
$earnings->execute([$rider_id]);
$earnings = $earnings->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Rider</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #fffbeb 0%, #fefce8 100%);
            font-family: 'Poppins', sans-serif;
        }

        .playfair {
            font-family: 'Playfair Display', serif;
        }

        .glass {
            background: rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 15px 35px rgba(251, 191, 36, 0.15);
        }
    </style>
</head>

<body class="text-gray-800">

    <div class="min-h-screen p-8">
        <div class="max-w-6xl mx-auto">

            <!-- Header -->
            <div class="mb-8 flex items-center justify-between">
                <div>
                    <a href="riders.php" class="btn btn-sm btn-outline gap-2 mb-4">
                        <i class="fas fa-arrow-left"></i> Back to Riders
                    </a>
                    <h1 class="playfair text-5xl font-bold text-yellow-700">Manage Rider</h1>
                    <p class="text-gray-600 mt-2"><?php echo htmlspecialchars($rider['name']); ?></p>
                </div>
                <div class="flex gap-2">
                    <button
                        onclick="openEditModal('<?php echo htmlspecialchars($rider['name']); ?>', '<?php echo htmlspecialchars($rider['email']); ?>', '<?php echo htmlspecialchars($rider['phone'] ?? ''); ?>')"
                        class="btn btn-warning">
                        <i class="fas fa-edit mr-2"></i> Edit Info
                    </button>
                </div>
            </div>

            <!-- Messages -->
            <?php if ($success): ?>
                <div class="alert alert-success shadow-lg rounded-xl mb-6 border-0 bg-green-100 text-green-800">
                    <div class="flex items-center gap-2">
                        <i class="fas fa-check-circle text-xl"></i>
                        <span><?php echo htmlspecialchars($success); ?></span>
                    </div>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-error shadow-lg rounded-xl mb-6 border-0 bg-red-100 text-red-800">
                    <div class="flex items-center gap-2">
                        <i class="fas fa-exclamation-circle text-xl"></i>
                        <span><?php echo htmlspecialchars($error); ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Rider Info Card -->
            <div class="glass rounded-3xl p-8 mb-8">
                <h2 class="text-2xl font-semibold text-yellow-700 mb-6 flex items-center gap-2">
                    <i class="fas fa-user-circle text-3xl"></i> Rider Information
                </h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="bg-white/50 rounded-xl p-6">
                        <p class="text-gray-600 text-sm font-semibold uppercase tracking-wide">Name</p>
                        <p class="text-2xl font-bold text-gray-800"><?php echo htmlspecialchars($rider['name']); ?></p>
                    </div>
                    <div class="bg-white/50 rounded-xl p-6">
                        <p class="text-gray-600 text-sm font-semibold uppercase tracking-wide">Email</p>
                        <p class="text-lg font-semibold text-gray-800"><?php echo htmlspecialchars($rider['email']); ?>
                        </p>
                    </div>
                    <div class="bg-white/50 rounded-xl p-6">
                        <p class="text-gray-600 text-sm font-semibold uppercase tracking-wide">Phone</p>
                        <p class="text-lg font-semibold text-gray-800">
                            <?php echo htmlspecialchars($rider['phone'] ?? 'N/A'); ?>
                        </p>
                    </div>
                    <div class="bg-white/50 rounded-xl p-6">
                        <p class="text-gray-600 text-sm font-semibold uppercase tracking-wide">Joined</p>
                        <p class="text-lg font-semibold text-gray-800">
                            <?php echo date('M d, Y', strtotime($rider['created_at'])); ?>
                        </p>
                    </div>
                </div>
            </div>

            <!-- Deliveries Section -->
            <div class="glass rounded-3xl p-8 mb-8">
                <h2 class="text-2xl font-semibold text-yellow-700 mb-6 flex items-center gap-2">
                    <i class="fas fa-box text-3xl"></i> Deliveries (<?php echo count($deliveries); ?>)
                </h2>

                <?php if (empty($deliveries)): ?>
                    <p class="text-gray-500 text-center py-8">
                        <i class="fas fa-inbox text-4xl mb-2 block opacity-50"></i>
                        No deliveries yet.
                    </p>
                <?php else: ?>
                    <div class="space-y-4">
                        <?php foreach ($deliveries as $d): ?>
                            <?php
                            $proofs = $pdo->prepare("SELECT * FROM delivery_proofs WHERE delivery_id = ?");
                            $proofs->execute([$d['id']]);
                            $proofs = $proofs->fetchAll(PDO::FETCH_ASSOC);
                            ?>
                            <div class="bg-white/50 rounded-xl p-6 border-l-4 border-yellow-400">
                                <div class="flex justify-between items-start mb-4">
                                    <div>
                                        <h3 class="text-xl font-bold text-gray-800">Delivery
                                            #<?php echo htmlspecialchars($d['id']); ?></h3>
                                        <p class="text-sm text-gray-600">Order ID: <span
                                                class="font-semibold">#<?php echo htmlspecialchars($d['order_id']); ?></span>
                                        </p>
                                    </div>
                                    <span class="badge badge-<?php echo $d['status'] === 'delivered' ? 'success' : 'info'; ?>">
                                        <?php echo ucfirst($d['status']); ?>
                                    </span>
                                </div>

                                <div class="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
                                    <div>
                                        <p class="text-gray-600 text-sm">Distance</p>
                                        <p class="font-semibold text-lg"><?php echo htmlspecialchars($d['distance_km']); ?> km
                                        </p>
                                    </div>
                                    <div>
                                        <p class="text-gray-600 text-sm">Created</p>
                                        <p class="font-semibold text-sm">
                                            <?php echo date('M d, Y', strtotime($d['created_at'])); ?>
                                        </p>
                                    </div>
                                </div>

                                <!-- Delivery Proofs -->
                                <?php if (!empty($proofs)): ?>
                                    <div class="mb-4">
                                        <p class="text-sm font-semibold text-gray-700 mb-2">Delivery Proof:</p>
                                        <div class="flex gap-3 flex-wrap">
                                            <?php foreach ($proofs as $p): ?>
                                                <img src="<?php echo htmlspecialchars($p['image_path']); ?>" alt="proof"
                                                    class="w-32 h-32 object-cover rounded-lg border-2 border-yellow-200 shadow hover:shadow-lg transition">
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <p class="text-red-500 text-sm mb-4">No proof uploaded yet.</p>
                                <?php endif; ?>

                                <!-- Verify Button -->
                                <?php if ($d['status'] !== 'delivered'): ?>
                                    <form method="POST" class="mt-4">
                                        <input type="hidden" name="delivery_id" value="<?php echo htmlspecialchars($d['id']); ?>">
                                        <button name="verify_delivery" class="btn btn-success btn-sm">
                                            <i class="fas fa-check-circle mr-2"></i> Verify & Release Payment
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <p class="text-green-600 text-sm font-semibold">
                                        <i class="fas fa-check-circle mr-1"></i> Delivery Verified ✓
                                    </p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Earnings Section -->
            <div class="glass rounded-3xl p-8 mb-8">
                <h2 class="text-2xl font-semibold text-yellow-700 mb-6 flex items-center gap-2">
                    <i class="fas fa-money-bill text-3xl"></i> Earnings
                </h2>

                <?php if (empty($earnings)): ?>
                    <p class="text-gray-500 text-center py-8">
                        <i class="fas fa-wallet text-4xl mb-2 block opacity-50"></i>
                        No earnings yet.
                    </p>
                <?php else: ?>
                    <div class="bg-white/50 rounded-xl p-6 mb-4">
                        <p class="text-gray-600 text-sm font-semibold uppercase tracking-wide">Total Earned</p>
                        <p class="text-4xl font-bold text-green-600">
                            ₱<?php echo number_format(array_sum(array_column($earnings, 'total')), 2); ?></p>
                    </div>
                    <div class="space-y-2">
                        <?php foreach ($earnings as $e): ?>
                            <div class="flex justify-between items-center p-4 bg-white/40 rounded-lg">
                                <div>
                                    <p class="font-semibold">Delivery #<?php echo $e['delivery_id']; ?></p>
                                    <p class="text-sm text-gray-600"><?php echo date('M d, Y', strtotime($e['created_at'])); ?>
                                        · <?php echo htmlspecialchars($e['distance_km']); ?> km</p>
                                </div>
                                <p class="text-2xl font-bold text-green-600">₱<?php echo number_format($e['total'], 2); ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Logs Section -->
            <div class="glass rounded-3xl p-8">
                <h2 class="text-2xl font-semibold text-yellow-700 mb-6 flex items-center gap-2">
                    <i class="fas fa-history text-3xl"></i> Activity Logs
                </h2>

                <?php if (empty($logs)): ?>
                    <p class="text-gray-500 text-center py-8">No activity logs.</p>
                <?php else: ?>
                    <div class="space-y-3">
                        <?php foreach ($logs as $log): ?>
                            <div class="flex items-start gap-4 p-4 bg-white/40 rounded-lg">
                                <div
                                    class="w-10 h-10 rounded-full bg-yellow-200 flex items-center justify-center text-yellow-700 flex-shrink-0">
                                    <i class="fas fa-circle text-xs"></i>
                                </div>
                                <div class="flex-1">
                                    <p class="font-semibold text-gray-800">
                                        <span
                                            class="badge badge-sm badge-neutral"><?php echo htmlspecialchars($log['log_type']); ?></span>
                                    </p>
                                    <p class="text-gray-600 text-sm mt-1"><?php echo htmlspecialchars($log['description']); ?>
                                    </p>
                                    <p class="text-xs text-gray-400 mt-2">
                                        <?php echo date('M d, Y H:i', strtotime($log['created_at'])); ?>
                                    </p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>

    <!-- Edit Modal -->
    <dialog id="editModal" class="modal">
        <div class="modal-box w-full max-w-md">
            <h3 class="font-bold text-lg mb-4 flex items-center gap-2">
                <i class="fas fa-edit text-yellow-600"></i> Edit Rider Information
            </h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="rider_id" value="<?php echo $rider_id; ?>">

                <div>
                    <label class="label text-sm font-semibold">Name</label>
                    <input type="text" id="editName" name="rider_name" class="input input-bordered w-full bg-white"
                        required>
                </div>

                <div>
                    <label class="label text-sm font-semibold">Email</label>
                    <input type="email" id="editEmail" name="rider_email" class="input input-bordered w-full bg-white"
                        required>
                </div>

                <div>
                    <label class="label text-sm font-semibold">Phone</label>
                    <input type="text" id="editPhone" name="rider_phone" class="input input-bordered w-full bg-white">
                </div>

                <div class="modal-action flex gap-2">
                    <button type="button" onclick="document.getElementById('editModal').close()"
                        class="btn btn-outline">Cancel</button>
                    <button type="submit" name="update_rider" class="btn btn-warning">
                        <i class="fas fa-save mr-1"></i> Save Changes
                    </button>
                </div>
            </form>
        </div>
        <form method="dialog" class="modal-backdrop">
            <button>close</button>
        </form>
    </dialog>

    <script>
        function openEditModal(name, email, phone) {
            document.getElementById('editName').value = name;
            document.getElementById('editEmail').value = email;
            document.getElementById('editPhone').value = phone;
            document.getElementById('editModal').showModal();
        }
    </script>

</body>

</html>