<?php
require '../includes/auth.php';
requireAdmin();
require '../includes/db.php';

$page_title = "Manage Products - Cheeze Tea";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>

    <!-- Tailwind + DaisyUI -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet">

    <!-- Fonts & Icons -->
    <link
        href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            background: linear-gradient(135deg, #fffbeb 0%, #fefce8 100%);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
        }

        .playfair {
            font-family: 'Playfair Display', serif;

            .glass {
                background: rgba(255, 255, 255, 0.3);
                backdrop-filter: blur(12px);
                border: 1px solid rgba(255, 255, 255, 0.5);
                box-shadow: 0 15px 35px rgba(251, 191, 36, 0.15);
            }

            .glow-hover:hover {
                transform: translateY(-10px);
                box-shadow: 0 25px 50px rgba(251, 191, 36, 0.3);
            }

            .product-img {
                transition: all 0.6s ease;
            }

            .product-img:hover {
                transform: scale(2.5);
                z-index: 50;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            }

            .table-row:hover {
                background: rgba(253, 230, 138, 0.15) !important;
            }

            .badge-stock {
                @apply px-3 py-1 rounded-full text-xs font-bold;
            }
    </style>

    <link rel="stylesheet" href="admin.css">

<body class="text-gray-800">

    <div class="flex min-h-screen">

        <!-- Sidebar (Same as Dashboard) -->
        <div class="w-64 sidebar bg-white shadow-2xl fixed h-full z-10 border-r border-yellow-100">
            <div class="p-8 text-center border-b border-yellow-100">
                <h1 class="playfair text-4xl font-bold text-yellow-600">Cheeze Tea</h1>
                <p class="text-yellow-700 text-sm">Admin Panel</p>
            </div>
            <?php $current_page = basename($_SERVER['PHP_SELF']); ?>
            <nav class="mt-8">
                <a href="dashboard.php"
                    class="<?php echo $current_page === 'dashboard.php' ? 'block py-4 px-8 bg-yellow-50 border-l-4 border-yellow-500 text-yellow-800 font-semibold' : 'block py-4 px-8 hover:bg-yellow-50 transition'; ?>">
                    <i class="fas fa-tachometer-alt mr-3"></i> Dashboard
                </a>
                <a href="products.php"
                    class="<?php echo $current_page === 'products.php' ? 'block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold' : 'block py-4 px-8 hover:bg-yellow-50 transition'; ?>">
                    <i class="fas fa-coffee mr-3"></i> Products
                </a>
                <a href="orders.php"
                    class="<?php echo $current_page === 'orders.php' ? 'block py-4 px-8 bg-yellow-50 border-l-4 border-yellow-500 text-yellow-800 font-semibold' : 'block py-4 px-8 hover:bg-yellow-50 transition'; ?>">
                    <i class="fas fa-shopping-bag mr-3"></i> Orders
                </a>
                <a href="customers.php"
                    class="<?php echo $current_page === 'customers.php' ? 'block py-4 px-8 bg-yellow-50 border-l-4 border-yellow-500 text-yellow-800 font-semibold' : 'block py-4 px-8 hover:bg-yellow-50 transition'; ?>">
                    <i class="fas fa-users mr-3"></i> Customers
                </a>
                <a href="riders.php"
                    class="<?php echo $current_page === 'riders.php' ? 'block py-4 px-8 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 font-bold' : 'block py-4 px-8 hover:bg-yellow-50 transition'; ?>">
                    <i class="fas fa-motorcycle mr-3"></i> Riders
                </a>
                <a href="analytics.php"
                    class="<?php echo $current_page === 'analytics.php' ? 'block py-4 px-8 bg-yellow-50 border-l-4 border-yellow-500 text-yellow-800 font-semibold' : 'block py-4 px-8 hover:bg-yellow-50 hover:border-l-4 hover:border-yellow-500 transition'; ?>">
                    <i class="fas fa-chart-line mr-3"></i> Analytics
                </a>
                <a href="../logout.php" class="block py-4 px-8 hover:bg-red-50 hover:text-red-600 transition mt-32">
                    <i class="fas fa-sign-out-alt mr-3"></i> Logout
                </a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 ml-64 p-10">

            <!-- Header -->
            <div class="admin-topbar">
                <div>
                    <h1 class="playfair text-5xl font-bold text-yellow-700">Manage Products</h1>
                    <p class="text-gray-600 mt-2">View, edit, or add new delicious items to your menu.</p>
                </div>
                <div>
                    <a href="../index.php" target="_blank" class="view-site-btn">View Site</a>
                </div>
            </div>

            <!-- Success Messages -->
            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success shadow-lg rounded-2xl mb-8 border-0 bg-green-100 text-green-800 p-4"
                    role="alert">
                    <div class="flex items-center">
                        <i class="fas fa-check-circle mr-3 text-xl"></i>
                        <span><strong>Success!</strong> Product updated successfully.</span>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['deleted'])): ?>
                <div class="alert alert-info shadow-lg rounded-2xl mb-8 border-0 bg-blue-100 text-blue-800 p-4"
                    role="alert">
                    <div class="flex items-center">
                        <i class="fas fa-info-circle mr-3 text-xl"></i>
                        <span><strong>Deleted!</strong> Product has been removed.</span>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['archived'])): ?>
                <div class="alert alert-warning shadow-lg rounded-2xl mb-8 border-0 bg-amber-100 text-amber-800 p-4"
                    role="alert">
                    <div class="flex items-center">
                        <i class="fas fa-archive mr-3 text-xl"></i>
                        <span><strong>Archived:</strong> Product could not be deleted because it exists in past orders. It
                            has been set to <em>inactive</em> to preserve order history.</span>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['error'])): ?>
                <div class="alert alert-error shadow-lg rounded-2xl mb-8 border-0 bg-red-100 text-red-800 p-4" role="alert">
                    <div class="flex items-center">
                        <i class="fas fa-exclamation-triangle mr-3 text-xl"></i>
                        <span><strong>Error:</strong> <?php echo htmlspecialchars($_GET['error']); ?></span>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Add Product Button -->
            <div class="text-right mb-8">
                <a href="add_product.php"
                    class="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-yellow-500 to-amber-500 text-white font-bold rounded-2xl shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300">
                    <i class="fas fa-plus-circle text-xl"></i>
                    Add New Product
                </a>
            </div>

            <!-- Products Table (Beautiful & Animated) -->
            <div class="glass rounded-3xl overflow-hidden">
                <div class="p-6">
                    <form method="get" class="mb-6 flex items-center gap-4">
                        <label for="category" class="font-semibold">Filter by Category:</label>
                        <select id="category" name="category" class="select select-sm" onchange="this.form.submit()">
                            <option value="all" <?php echo (isset($_GET['category']) && $_GET['category'] === 'all') ? 'selected' : ''; ?>>All</option>
                            <option value="milktea" <?php echo (isset($_GET['category']) && $_GET['category'] === 'milktea') ? 'selected' : ''; ?>>Milk Tea</option>
                            <option value="milkshake" <?php echo (isset($_GET['category']) && $_GET['category'] === 'milkshake') ? 'selected' : ''; ?>>Milkshake</option>
                            <option value="fruittea" <?php echo (isset($_GET['category']) && $_GET['category'] === 'fruittea') ? 'selected' : ''; ?>>Fruit Tea</option>
                            <option value="sparkling" <?php echo (isset($_GET['category']) && $_GET['category'] === 'sparkling') ? 'selected' : ''; ?>>Sparkling Soda</option>
                            <option value="coffee" <?php echo (isset($_GET['category']) && $_GET['category'] === 'coffee') ? 'selected' : ''; ?>>Coffee</option>
                            <option value="food" <?php echo (isset($_GET['category']) && $_GET['category'] === 'food') ? 'selected' : ''; ?>>Food & Snacks</option>
                        </select>
                        <noscript><button type="submit" class="btn btn-sm">Apply</button></noscript>
                    </form>
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead>
                                <tr class="bg-gradient-to-r from-yellow-400 to-amber-500 text-white">
                                    <th class="px-8 py-6 text-left">Image</th>
                                    <th class="px-8 py-6 text-left">Product Name</th>
                                    <th class="px-8 py-6 text-center">Price</th>
                                    <th class="px-8 py-6 text-center">Stock</th>
                                    <th class="px-8 py-6 text-center">Status</th>
                                    <th class="px-8 py-6 text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-yellow-100">
                                <?php
                                // Server-side category filter
                                $selected_cat = $_GET['category'] ?? 'all';
                                $allowed = ['milktea', 'milkshake', 'fruittea', 'sparkling', 'coffee', 'food', 'all'];
                                if (!in_array($selected_cat, $allowed))
                                    $selected_cat = 'all';

                                if ($selected_cat === 'all') {
                                    $stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");
                                    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                } else {
                                    $stmt = $pdo->prepare("SELECT * FROM products WHERE category = ? ORDER BY id DESC");
                                    $stmt->execute([$selected_cat]);
                                    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                }

                                foreach ($products as $p):
                                    ?>
                                    <tr class="table-row transition-all duration-300 hover:bg-yellow-50/50">
                                        <td class="px-8 py-6">
                                            <div class="w-20 h-20 rounded-2xl overflow-hidden border-2 border-yellow-200">
                                                <img src="../uploads/<?php echo htmlspecialchars($p['image']); ?>"
                                                    alt="<?php echo htmlspecialchars($p['name']); ?>"
                                                    class="w-full h-full object-cover product-img">
                                            </div>
                                        </td>
                                        <td class="px-8 py-6">
                                            <p class="font-semibold text-lg text-gray-800">
                                                <?php echo htmlspecialchars($p['name']); ?>
                                            </p>
                                            <p class="text-sm text-gray-600">
                                                <?php echo htmlspecialchars(substr($p['description'], 0, 60)) . '...'; ?>
                                            </p>
                                        </td>
                                        <td class="px-8 py-6 text-center">
                                            <span
                                                class="text-3xl font-bold text-yellow-600">₱<?php echo number_format($p['price'], 2); ?></span>
                                        </td>
                                        <td class="px-8 py-6 text-center">
                                            <span class="px-4 py-2 bg-green-100 text-green-800 rounded-full font-bold">
                                                <?php echo $p['stock'] ?? '∞'; ?>
                                            </span>
                                        </td>
                                        <td class="px-8 py-6 text-center">
                                            <span
                                                class="badge <?php echo ($p['status'] ?? 'active') === 'active' ? 'badge-success' : 'badge-error'; ?>">
                                                <?php echo ucfirst($p['status'] ?? 'active'); ?>
                                            </span>
                                        </td>
                                        <td class="px-8 py-6 text-center">
                                            <div class="flex gap-3 justify-center">
                                                <a href="edit_product.php?id=<?php echo $p['id']; ?>"
                                                    class="px-5 py-3 bg-amber-500 text-white rounded-xl hover:bg-amber-600 transition transform hover:scale-110 shadow-lg">
                                                    <i class="fas fa-edit"></i> Edit
                                                </a>
                                                <a href="delete_product.php?id=<?php echo $p['id']; ?>"
                                                    onclick="return confirm('⚠️ Delete this product permanently?')"
                                                    class="px-5 py-3 bg-red-500 text-white rounded-xl hover:bg-red-600 transition transform hover:scale-110 shadow-lg">
                                                    <i class="fas fa-trash"></i> Delete
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>

                                <?php if (count($products) === 0): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-16 text-gray-500">
                                            <i class="fas fa-coffee text-6xl mb-4 block text-yellow-300"></i>
                                            <p class="text-2xl">No products yet. Click "Add New Product" to get started!</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Floating Action Button (Mobile) -->
                <a href="add_product.php"
                    class="fixed bottom-8 right-8 w-16 h-16 bg-yellow-500 text-white rounded-full shadow-2xl flex items-center justify-center text-3xl hover:bg-amber-600 transform hover:scale-110 transition z-50 md:hidden">
                    <i class="fas fa-plus"></i>
                </a>

            </div>
        </div>

        <script>
            // Hover zoom on product images
            document.querySelectorAll('.product-img').forEach(img => {
                img.addEventListener('mouseenter', () => img.style.transform = 'scale(3)');
                img.addEventListener('mouseleave', () => img.style.transform = 'scale(1)');
            });
        </script>

</body>

</html>