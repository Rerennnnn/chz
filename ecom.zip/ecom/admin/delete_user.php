<?php
require 'includes/auth.php';
requireAdmin();
require 'includes/db.php';

$success = null;
$error = null;
$user_to_delete = null;

// Get user ID from URL
$user_id = isset($_GET['id']) ? (int) $_GET['id'] : null;

// Fetch user details if provided
if ($user_id) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user_to_delete = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Handle deletion confirmation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    $user_id = (int) $_POST['user_id'];

    try {
        // Check if user has orders
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $order_count = $stmt->fetchColumn();

        if ($order_count > 0) {
            // Has orders - just set role to customer (safe delete)
            $stmt = $pdo->prepare("UPDATE users SET role = 'customer' WHERE id = ?");
            $stmt->execute([$user_id]);
            $success = "User account preserved (has $order_count orders). Role changed to customer to maintain order history.";
        } else {
            // No orders - safe to fully delete
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $success = "User account deleted successfully.";
            $user_to_delete = null;
        }
    } catch (PDOException $e) {
        $error = "Error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete User - Cheeze Tea</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #fffbeb 0%, #fefce8 100%);
            font-family: 'Poppins', sans-serif;
        }

        .playfair {
            font-family: 'Playfair Display', serif;
        }

        .glass {
            background: rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 15px 35px rgba(251, 191, 36, 0.15);
        }
    </style>
</head>

<body class="text-gray-800">
    <div class="min-h-screen p-8">
        <div class="max-w-2xl mx-auto">
            <a href="admin/riders.php" class="btn btn-sm btn-outline gap-2 mb-4">
                <i class="fas fa-arrow-left"></i> Back to Riders
            </a>

            <h1 class="playfair text-4xl font-bold text-yellow-700 mb-8">Safe Delete User</h1>

            <?php if ($success): ?>
                <div class="alert alert-success shadow-lg mb-6 border-0 bg-green-100 text-green-800">
                    <i class="fas fa-check-circle mr-2"></i><?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error shadow-lg mb-6 border-0 bg-red-100 text-red-800">
                    <i class="fas fa-exclamation-circle mr-2"></i><?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($user_to_delete): ?>
                <div class="glass rounded-3xl p-8">
                    <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6 rounded">
                        <p class="font-semibold text-yellow-800">
                            <i class="fas fa-info-circle mr-2"></i>
                            Important: If this user has orders in the system, their account will be preserved to maintain
                            order history integrity. Only the rider role will be removed.
                        </p>
                    </div>

                    <div class="mb-8">
                        <h2 class="text-2xl font-semibold text-gray-800 mb-4">Confirm Deletion</h2>
                        <div class="space-y-4 bg-white p-6 rounded-xl">
                            <div>
                                <p class="text-gray-600 text-sm">Name</p>
                                <p class="text-2xl font-bold text-gray-800">
                                    <?php echo htmlspecialchars($user_to_delete['name']); ?>
                                </p>
                            </div>
                            <div>
                                <p class="text-gray-600 text-sm">Email</p>
                                <p class="text-lg text-gray-800"><?php echo htmlspecialchars($user_to_delete['email']); ?>
                                </p>
                            </div>
                            <div>
                                <p class="text-gray-600 text-sm">Current Role</p>
                                <p class="text-lg font-semibold">
                                    <span
                                        class="badge badge-<?php echo $user_to_delete['role'] === 'admin' ? 'error' : ($user_to_delete['role'] === 'rider' ? 'warning' : 'info'); ?>">
                                        <?php echo ucfirst($user_to_delete['role']); ?>
                                    </span>
                                </p>
                            </div>
                            <div>
                                <p class="text-gray-600 text-sm">Joined</p>
                                <p class="text-gray-800">
                                    <?php echo date('M d, Y', strtotime($user_to_delete['created_at'])); ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <form method="POST" class="space-y-4">
                        <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user_to_delete['id']); ?>">
                        <div class="flex gap-4">
                            <a href="delete_user.php" class="btn btn-outline flex-1">Cancel</a>
                            <button type="submit" name="confirm_delete" class="btn btn-error flex-1">
                                <i class="fas fa-trash mr-2"></i> Confirm Delete / Remove Role
                            </button>
                        </div>
                    </form>
                </div>
            <?php else: ?>
                <div class="glass rounded-3xl p-8">
                    <h2 class="text-2xl font-semibold text-gray-800 mb-6">Select User to Delete</h2>

                    <?php
                    $stmt = $pdo->query("SELECT id, name, email, role, created_at FROM users WHERE role != 'admin' ORDER BY name ASC");
                    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    ?>

                    <?php if (empty($users)): ?>
                        <p class="text-gray-500 text-center py-8">No users to delete.</p>
                    <?php else: ?>
                        <div class="space-y-3">
                            <?php foreach ($users as $u): ?>
                                <a href="?id=<?php echo htmlspecialchars($u['id']); ?>"
                                    class="block p-4 bg-white rounded-xl hover:bg-yellow-50 transition border-l-4 border-yellow-300">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <p class="font-semibold text-lg text-gray-800">
                                                <?php echo htmlspecialchars($u['name']); ?>
                                            </p>
                                            <p class="text-sm text-gray-600"><?php echo htmlspecialchars($u['email']); ?></p>
                                        </div>
                                        <span class="badge badge-<?php echo $u['role'] === 'rider' ? 'warning' : 'info'; ?>">
                                            <?php echo ucfirst($u['role']); ?>
                                        </span>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>