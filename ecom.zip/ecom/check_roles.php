<?php
require 'includes/db.php';

// Show all roles in the database
$stmt = $pdo->query("SELECT DISTINCT role FROM users");
$roles = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h2>Roles in Database:</h2>";
foreach ($roles as $r) {
    echo "- " . $r['role'] . "<br>";
}

echo "<h2>User Count by Role:</h2>";
foreach ($roles as $r) {
    $cnt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = '" . $r['role'] . "'")->fetchColumn();
    echo $r['role'] . ": " . $cnt . " users<br>";
}

echo "<h2>All Users:</h2>";
$stmt = $pdo->query("SELECT id, name, email, role FROM users ORDER BY role, name");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "<table border='1'>";
foreach ($users as $u) {
    echo "<tr><td>" . $u['id'] . "</td><td>" . htmlspecialchars($u['name']) . "</td><td>" . htmlspecialchars($u['email']) . "</td><td><strong>" . $u['role'] . "</strong></td></tr>";
}
echo "</table>";
?>