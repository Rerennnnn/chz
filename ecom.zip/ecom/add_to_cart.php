<?php
session_start();
require 'includes/db.php';

if (!isset($_POST['product_id'])) {
    header('Location: products.php');
    exit();
}

$id = (int) $_POST['product_id'];
$size = $_POST['size'] ?? 'medium';

$stmt = $pdo->prepare("SELECT id, name, price, category FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();

if ($product) {
    $drink_categories = ['milktea', 'milkshake', 'fruittea', 'sparkling', 'coffee'];
    $is_drink = in_array($product['category'], $drink_categories);

    if ($is_drink) {
        $cart_key = $id . '_' . $size;
    } else {
        $cart_key = $id;
    }

    if (!isset($_SESSION['cart'][$cart_key])) {
        // For drinks use fixed size prices: small=29, medium=39, large=49
        if ($is_drink) {
            if ($size === 'small')
                $unit_price = 29.00;
            elseif ($size === 'medium')
                $unit_price = 39.00;
            elseif ($size === 'large')
                $unit_price = 49.00;
            else
                $unit_price = 39.00; // default medium
        } else {
            // Non-drink: use product price
            $unit_price = round($product['price'], 2);
        }

        $_SESSION['cart'][$cart_key] = [
            'product_id' => $id,
            'qty' => 1,
            'size' => $is_drink ? $size : null,
            'unit_price' => $unit_price
        ];
    } else {
        $_SESSION['cart'][$cart_key]['qty']++;
    }
}

header('Location: cart.php');
exit();
?>