<?php
session_start();
if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    if (isset($_SESSION['cart'][$id])) {
        unset($_SESSION['cart'][$id]);
        if (empty($_SESSION['cart']))
            unset($_SESSION['cart']);
    }
}
// Handle new key format (product_id_size)
if (isset($_GET['key'])) {
    $key = $_GET['key'];
    if (isset($_SESSION['cart'][$key])) {
        unset($_SESSION['cart'][$key]);
        if (empty($_SESSION['cart']))
            unset($_SESSION['cart']);
    }
}
header('Location: cart.php');
exit();
?>