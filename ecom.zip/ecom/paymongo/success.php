<?php
// paymongo/success.php - Payment Success Handler

session_start();
require '../includes/db.php';
require '../includes/header.php';
require '../includes/navbar.php';

$payment_intent_id = $_GET['pi_id'] ?? null;
$order_id = $_GET['order_id'] ?? null;
$payment_method = $_GET['payment_method'] ?? null;

// Debug log
@file_put_contents(
    __DIR__ . '/../logs/success_page.log',
    date('Y-m-d H:i:s') . " | success.php called: order_id=" . $order_id . ", payment_method=" . $payment_method . ", pi_id=" . $payment_intent_id . "\n",
    FILE_APPEND
);

// For COD orders
if ($payment_method === 'cod' && $order_id) {
    @file_put_contents(
        __DIR__ . '/../logs/success_page.log',
        date('Y-m-d H:i:s') . " | Processing COD order: " . $order_id . "\n",
        FILE_APPEND
    );
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
    $stmt->execute([(int) $order_id]);
    $order = $stmt->fetch();

    if (!$order) {
        echo '<div class="text-center py-20"><h1 class="text-3xl playfair text-red-600">Order Not Found</h1><p class="text-lg mt-4">We could not find your order.</p><a href="../index.php" class="mt-8 inline-block bg-yellow-dark text-gray-900 px-8 py-4 rounded-lg font-semibold">Back to Home</a></div>';
        require '../includes/footer.php';
        exit();
    }

    // Update order status for COD - set to pending (awaiting delivery)
    $updateStmt = $pdo->prepare("UPDATE orders SET payment_status = 'cod_pending' WHERE id = ?");
    $updateStmt->execute([(int) $order['id']]);

    // Create a delivery record for COD orders so riders can see and pickup
    try {
        @file_put_contents(
            __DIR__ . '/../logs/success_page.log',
            date('Y-m-d H:i:s') . " | Creating delivery for order " . $order['id'] . " with address: " . $order['shipping_address'] . "\n",
            FILE_APPEND
        );

        $deliveryStmt = $pdo->prepare("
            INSERT INTO deliveries (order_id, pickup_address, dropoff_address, status, created_at)
            VALUES (?, ?, ?, 'assigned', NOW())
        ");

        $result = $deliveryStmt->execute([
            (int) $order['id'],
            'Shop', // pickup location (you can customize this)
            htmlspecialchars($order['shipping_address'] ?? 'N/A')
        ]);

        @file_put_contents(
            __DIR__ . '/../logs/success_page.log',
            date('Y-m-d H:i:s') . " | Delivery creation result: " . ($result ? "success" : "failed") . "\n",
            FILE_APPEND
        );
    } catch (Exception $e) {
        // Log the error for debugging
        @file_put_contents(
            __DIR__ . '/../logs/success_page.log',
            date('Y-m-d H:i:s') . " | Delivery Creation Error: " . $e->getMessage() . "\n",
            FILE_APPEND
        );
    }
} else {
    // For online payments (GCash, Card)
    if (!$payment_intent_id) {
        echo '<div class="text-center py-20"><h1 class="text-3xl playfair text-red-600">Payment Failed</h1><p class="text-lg mt-4">No payment information found.</p><a href="../index.php" class="mt-8 inline-block bg-yellow-dark text-gray-900 px-8 py-4 rounded-lg font-semibold">Back to Home</a></div>';
        require '../includes/footer.php';
        exit();
    }

    // Find order by payment_id and update status
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE payment_id = ?");
    $stmt->execute([$payment_intent_id]);
    $order = $stmt->fetch();

    if (!$order) {
        echo '<div class="text-center py-20"><h1 class="text-3xl playfair text-red-600">Order Not Found</h1><p class="text-lg mt-4">We could not find your order.</p><a href="../index.php" class="mt-8 inline-block bg-yellow-dark text-gray-900 px-8 py-4 rounded-lg font-semibold">Back to Home</a></div>';
        require '../includes/footer.php';
        exit();
    }

    // Update order status to completed
    $updateStmt = $pdo->prepare("UPDATE orders SET status = 'completed', payment_status = 'paid' WHERE id = ?");
    $updateStmt->execute([$order['id']]);
}

// Clear cart from session
unset($_SESSION['cart']);

// Send confirmation email to customer (Gmail)
require_once __DIR__ . '/../includes/email.php';
try {
    // Fetch order items
    $itemsStmt = $pdo->prepare("SELECT oi.quantity, oi.price, p.name FROM order_items oi LEFT JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ?");
    $itemsStmt->execute([$order['id']]);
    $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);

    // Build email body
    $body = '<h2>Thank you for your order!</h2>';
    $body .= '<p>Hi ' . htmlspecialchars($order['customer_name'] ?? '') . ',</p>';
    $body .= '<p>We have received your order. Here are your order details:</p>';
    $body .= '<ul>';
    foreach ($items as $it) {
        $body .= '<li>' . htmlspecialchars($it['name']) . ' &times; ' . (int) $it['quantity'] . ' — ₱' . number_format($it['price'], 2) . '</li>';
    }
    $body .= '</ul>';
    $body .= '<p><strong>Order #: </strong> #' . htmlspecialchars($order['id']) . '</p>';
    $body .= '<p><strong>Total Amount: </strong> ₱' . number_format($order['total'], 2) . '</p>';

    // Add payment status message
    if ($payment_method === 'cod') {
        $body .= '<p>Payment method: <strong>Cash on Delivery (COD)</strong></p>';
        $body .= '<p>Please prepare the exact amount for payment when our delivery personnel arrives at your address.</p>';
    } else {
        $body .= '<p>Payment status: <strong>PAID</strong></p>';
    }

    $body .= '<p>Thank you for supporting Cheeze Tea — we hope you enjoy your drinks!</p>';
    $body .= '<p>— Cheeze Tea</p>';

    $to = $order['customer_email'] ?? null;
    if ($to) {
        $subject = 'Order Confirmation — Cheeze Tea Order #' . $order['id'];
        $sent = sendEmail($to, $subject, $body);
        if (!$sent) {
            // log failure
            @file_put_contents(__DIR__ . '/logs/email_errors.log', date('Y-m-d H:i:s') . " | Failed to send order confirmation to {$to} for order {$order['id']}\n", FILE_APPEND);
        }
    }
} catch (Exception $e) {
    @file_put_contents(__DIR__ . '/logs/email_errors.log', date('Y-m-d H:i:s') . " | Exception while preparing email: " . $e->getMessage() . "\n", FILE_APPEND);
}
?>

<div class="min-h-screen flex items-center justify-center px-4">
    <div class="max-w-2xl w-full text-center">
        <div class="bg-white rounded-3xl shadow-2xl p-12">
            <!-- Success Icon -->
            <div class="mb-8">
                <div class="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                    <i class="fas fa-check-circle text-5xl text-green-600"></i>
                </div>
            </div>

            <!-- Success Message -->
            <h1 class="playfair text-5xl font-bold text-green-600 mb-4">
                <?php
                if ($payment_method === 'cod') {
                    echo 'Order Received!';
                } else {
                    echo 'Payment Successful!';
                }
                ?>
            </h1>

            <div class="bg-green-50 border-2 border-green-200 rounded-2xl p-6 my-8">
                <p class="text-gray-700 text-lg mb-4">
                    <?php
                    if ($payment_method === 'cod') {
                        echo 'Thank you for your order! We will deliver your order soon and collect payment upon delivery.';
                    } else {
                        echo 'Thank you for your purchase! Your payment has been received.';
                    }
                    ?>
                </p>

                <div class="grid grid-cols-2 gap-6 my-8 text-left">
                    <div class="bg-white p-4 rounded-xl">
                        <p class="text-sm text-gray-600">Order Number</p>
                        <p class="text-2xl font-bold text-yellow-600">#<?php echo htmlspecialchars($order['id']); ?></p>
                    </div>
                    <div class="bg-white p-4 rounded-xl">
                        <p class="text-sm text-gray-600">Order Total</p>
                        <p class="text-2xl font-bold text-yellow-600">₱<?php echo number_format($order['total'], 2); ?>
                        </p>
                    </div>
                    <div class="bg-white p-4 rounded-xl">
                        <p class="text-sm text-gray-600">Payment Status</p>
                        <p class="text-2xl font-bold text-green-600">
                            <?php
                            if ($payment_method === 'cod') {
                                echo 'Pending (COD)';
                            } else {
                                echo 'PAID';
                            }
                            ?>
                        </p>
                    </div>
                    <div class="bg-white p-4 rounded-xl">
                        <p class="text-sm text-gray-600">Order Date</p>
                        <p class="text-2xl font-bold text-gray-800">
                            <?php echo date('M d, Y', strtotime($order['created_at'])); ?>
                        </p>
                    </div>
                </div>

                <p class="text-gray-700 mb-4">We will process your order shortly and send you a confirmation email with
                    tracking information.</p>
            </div>

            <!-- Actions -->
            <div class="flex gap-4 justify-center">
                <a href="../index.php"
                    class="px-8 py-4 bg-yellow-dark text-gray-900 rounded-2xl font-bold hover:bg-yellow-warm transition">
                    <i class="fas fa-home mr-2"></i> Back to Home
                </a>
                <a href="../products.php"
                    class="px-8 py-4 bg-gray-600 text-white rounded-2xl font-bold hover:bg-gray-700 transition">
                    <i class="fas fa-shopping-bag mr-2"></i> Continue Shopping
                </a>
            </div>
        </div>
    </div>
</div>

<?php require '../includes/footer.php'; ?>