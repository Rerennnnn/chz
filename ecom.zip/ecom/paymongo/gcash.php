<?php
// paymongo/gcash.php - Server-side GCash redirect flow using PayMongo (based on PaymongoTest)
session_start();
require '../includes/config.php';
require '../includes/db.php';
require '../includes/auth.php';

if (!isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$order_id = $_GET['order_id'] ?? null;
$amount = $_GET['amount'] ?? null; // centavos or pesos

if (!$order_id || !$amount) {
    header('Location: ../cart.php');
    exit();
}

// Verify order belongs to user
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: ../cart.php');
    exit();
}

// Normalize amount to centavos
$amount_raw = trim((string)$amount);
$amount_raw = preg_replace('/[^0-9\.]/', '', $amount_raw);
if (strpos($amount_raw, '.') !== false) {
    $amount_cents = (int) round(floatval($amount_raw) * 100);
} else {
    $amtInt = (int)$amount_raw;
    $amount_cents = ($amtInt < 1000) ? $amtInt * 100 : $amtInt;
}

$secret_key = PAYMONGO_SECRET_KEY;
$api_base = PAYMONGO_API_URL;

// 1) Create payment intent
$data = [
  "data" => [
    "attributes" => [
      "amount" => (int)$amount_cents,
      "payment_method_allowed" => ["gcash"],
      "currency" => "PHP",
      "capture_type" => "automatic",
      "description" => "Order #" . $order_id
    ]
  ]
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $api_base . "/payment_intents");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  "Content-Type: application/json",
  "Accept: application/json",
  "Authorization: Basic " . base64_encode($secret_key . ":")
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr = curl_error($ch);
curl_close($ch);

// Log
$logDir = __DIR__ . '/logs'; if (!is_dir($logDir)) @mkdir($logDir, 0755, true);
@file_put_contents($logDir . '/paymongo_errors.log', date('Y-m-d H:i:s') . " | GCASH CREATE INTENT | HTTP:" . $httpCode . " | ERR:" . $curlErr . " | REQ:" . json_encode($data) . " | RES:" . $response . "\n", FILE_APPEND);

$result = json_decode($response, true);
if (!isset($result['data']['id'])) {
    // show error page
    echo '<h2>PayMongo Error</h2><pre>' . htmlspecialchars($response) . '</pre>';
    exit();
}

$intent_id = $result['data']['id'];
$client_key = $result['data']['attributes']['client_key'] ?? null;

// Update order with payment intent id
$updateStmt = $pdo->prepare("UPDATE orders SET payment_id = ? WHERE id = ?");
$updateStmt->execute([$intent_id, $order_id]);

// 2) Create payment method (gcash)
$pmData = [
  "data" => [
    "attributes" => [
      "type" => "gcash",
      "amount" => $amount_cents,
      "currency" => "PHP",
      "redirect" => [
        "return_url" => (isset($_SERVER['REQUEST_SCHEME']) ? $_SERVER['REQUEST_SCHEME'] : (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')) . '://' . $_SERVER['HTTP_HOST'] . '/ecom/paymongo/success.php'
      ]
    ]
  ]
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $api_base . "/payment_methods");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($pmData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  "Content-Type: application/json",
  "Accept: application/json",
  "Authorization: Basic " . base64_encode($secret_key . ":")
]);

$response2 = curl_exec($ch);
$httpCode2 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr2 = curl_error($ch);
curl_close($ch);

@file_put_contents($logDir . '/paymongo_errors.log', date('Y-m-d H:i:s') . " | GCASH CREATE PM | HTTP:" . $httpCode2 . " | ERR:" . $curlErr2 . " | REQ:" . json_encode($pmData) . " | RES:" . $response2 . "\n", FILE_APPEND);

$pm = json_decode($response2, true);
if (!isset($pm['data']['id'])) {
    echo '<h2>PayMongo PM Error</h2><pre>' . htmlspecialchars($response2) . '</pre>';
    exit();
}

$pm_id = $pm['data']['id'];

// 3) Attach payment method to intent
$attachData = [
  "data" => [
    "attributes" => [
      "payment_method" => $pm_id,
      "client_key" => $client_key,
      "return_url" => (isset($_SERVER['REQUEST_SCHEME']) ? $_SERVER['REQUEST_SCHEME'] : (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')) . '://' . $_SERVER['HTTP_HOST'] . '/ecom/paymongo/success.php'
    ]
  ]
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $api_base . "/payment_intents/" . $intent_id . "/attach");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($attachData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  "Content-Type: application/json",
  "Authorization: Basic " . base64_encode($secret_key . ":")
]);

$res3 = curl_exec($ch);
$httpCode3 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr3 = curl_error($ch);
curl_close($ch);

@file_put_contents($logDir . '/paymongo_errors.log', date('Y-m-d H:i:s') . " | GCASH ATTACH | HTTP:" . $httpCode3 . " | ERR:" . $curlErr3 . " | REQ:" . json_encode($attachData) . " | RES:" . $res3 . "\n", FILE_APPEND);

$resObj = json_decode($res3, true);
if (isset($resObj['data']['attributes']['next_action']['redirect']['url'])) {
    $redirect_url = $resObj['data']['attributes']['next_action']['redirect']['url'];
    header('Location: ' . $redirect_url);
    exit();
} else {
    echo '<h2>PayMongo Attach Error</h2><pre>' . htmlspecialchars($res3) . '</pre>';
    exit();
}

?>
