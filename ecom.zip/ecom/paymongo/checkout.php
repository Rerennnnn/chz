<?php
// paymongo/checkout.php - PayMongo Payment Modal Page

session_start();
require '../includes/config.php';
require '../includes/db.php';
require '../includes/auth.php';

if (!isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$order_id = $_GET['order_id'] ?? null;
$amount = $_GET['amount'] ?? null;
$name = $_GET['name'] ?? $_SESSION['name'];
$email = $_GET['email'] ?? '';

if (!$order_id || !$amount) {
    header('Location: ../cart.php');
    exit();
}

// Verify order belongs to user
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: ../cart.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Payment - Cheeze Tea</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://checkout.paymongo.com/checkout.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Poppins', sans-serif; background: linear-gradient(135deg, #fffbeb 0%, #fefce8 100%); }
        .playfair { font-family: 'Playfair Display', serif; }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center px-4">
    <div class="max-w-md w-full">
        <div class="bg-white rounded-3xl shadow-2xl p-8">
            <!-- Header -->
            <div class="text-center mb-8">
                <h1 class="playfair text-4xl font-bold text-yellow-600 mb-2">Complete Payment</h1>
                <p class="text-gray-600">Order #<?php echo $order['id']; ?></p>
            </div>

            <!-- Order Summary -->
            <div class="bg-yellow-50 rounded-2xl p-6 mb-8">
                <div class="flex justify-between items-center mb-4">
                    <span class="text-gray-700">Order Total:</span>
                    <span class="text-3xl font-bold text-yellow-600">₱<?php echo number_format($order['total'], 2); ?></span>
                </div>
                <div class="text-sm text-gray-600 space-y-2">
                    <p><strong>Customer:</strong> <?php echo htmlspecialchars($name); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
                </div>
            </div>

            <!-- Payment Methods Info -->
            <div class="bg-blue-50 border-2 border-blue-200 rounded-2xl p-4 mb-8">
                <p class="text-sm text-blue-800">
                    <i class="fas fa-info-circle mr-2"></i>
                    You can pay using <strong>GCash</strong> or <strong>Credit/Debit Card</strong>
                </p>
                <div class="mt-4 text-center">
                    <a id="gcash-redirect" href="#" class="inline-block px-6 py-3 bg-green-600 text-white rounded-xl font-semibold hover:bg-green-700">Pay with GCash (Redirect)</a>
                </div>
            </div>

            <!-- Loading State -->
            <div id="loading" class="text-center py-8">
                <div class="inline-block">
                    <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-600"></div>
                </div>
                <p class="text-gray-600 mt-4">Loading payment form...</p>
            </div>

            <!-- Payment Container -->
            <div id="payment-container" style="display: none;"></div>

            <!-- Error Message -->
            <div id="error-message" class="hidden bg-red-100 border-2 border-red-300 text-red-800 px-4 py-3 rounded-xl mt-6"></div>
        </div>
    </div>

    <script>
        const orderId = <?php echo json_encode($order_id); ?>;
        const amount = <?php echo json_encode($amount); ?>;
        const customerName = <?php echo json_encode($name); ?>;
        const customerEmail = <?php echo json_encode($email); ?>;

        // GCash redirect button
        document.getElementById('gcash-redirect').addEventListener('click', function(e) {
            e.preventDefault();
            // Open server-side GCash flow which will redirect to PayMongo
            window.location.href = '../paymongo/gcash.php?order_id=' + encodeURIComponent(orderId) + '&amount=' + encodeURIComponent(amount);
        });

        // Create payment intent
        fetch('../paymongo/process_payment.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                order_id: orderId,
                amount: amount,
                customer_name: customerName,
                customer_email: customerEmail
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Initialize PayMongo Checkout
                const checkout = new PaymongoCheckout({
                    key: data.public_key,
                    redirectUrl: window.location.origin + '/ecom/paymongo/success.php?pi_id=' + data.payment_intent_id
                });

                document.getElementById('loading').style.display = 'none';
                document.getElementById('payment-container').style.display = 'block';

                // Render the checkout form
                checkout.render('#payment-container');

                // Auto-show intent modal
                setTimeout(() => {
                    checkout.showIntentModal({
                        paymentIntentId: data.payment_intent_id,
                        onPaymentSuccess: (paymentIntent) => {
                            window.location.href = 'success.php?pi_id=' + data.payment_intent_id;
                        },
                        onPaymentFailed: (paymentIntent) => {
                            window.location.href = 'failed.php?order_id=' + orderId + '&error=Payment%20was%20declined';
                        }
                    });
                }, 500);
            } else {
                showError(data.error || 'Failed to initialize payment');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showError('An error occurred. Please try again.');
        });

        function showError(message) {
            document.getElementById('loading').style.display = 'none';
            const errorDiv = document.getElementById('error-message');
            errorDiv.textContent = message;
            errorDiv.classList.remove('hidden');
        }
    </script>
</body>
</html>
