<?php
require 'includes/auth.php';
require 'includes/db.php';
require 'includes/header.php';
require 'includes/navbar.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch orders for user with optional delivery info
$stmt = $pdo->prepare("SELECT o.*, d.id AS delivery_id, d.status AS delivery_status, d.distance_km
    FROM orders o
    LEFT JOIN deliveries d ON d.order_id = o.id
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<div class="min-h-screen bg-cream poppins">
    <div class="max-w-6xl mx-auto px-4 py-12">
        <h1 class="playfair text-4xl font-bold text-yellow-dark mb-6">My Orders</h1>

        <?php if (empty($orders)): ?>
            <div class="bg-white rounded-3xl shadow-lg p-8 text-center">
                <p class="text-xl">You have no orders yet.</p>
                <a href="products.php" class="mt-6 inline-block bg-yellow-dark text-gray-900 px-6 py-3 rounded-xl">Order
                    Now</a>
            </div>
        <?php else: ?>
            <div class="space-y-6">
                <?php foreach ($orders as $order): ?>
                    <div class="bg-white rounded-3xl shadow-lg p-6">
                        <div class="flex justify-between items-start gap-4">
                            <div>
                                <h3 class="text-xl font-bold">Order #<?= htmlspecialchars($order['id']) ?></h3>
                                <p class="text-sm text-gray-600">Placed on <?= htmlspecialchars($order['created_at']) ?></p>
                                <p class="text-sm mt-2">Total: <strong>₱<?= number_format($order['total'], 2) ?></strong></p>
                                <p class="text-sm">Payment:
                                    <strong><?= htmlspecialchars($order['payment_status'] ?? 'pending') ?></strong></p>
                                <p class="text-sm">Order status:
                                    <strong><?= htmlspecialchars($order['status'] ?? '') ?></strong></p>
                                <p class="text-sm">Delivery status:
                                    <strong><?= htmlspecialchars($order['delivery_status'] ?? 'n/a') ?></strong></p>
                            </div>

                            <div class="text-right">
                                <a href="view_order.php?id=<?= urlencode($order['id']) ?>"
                                    class="inline-block bg-amber-500 text-white px-4 py-2 rounded-lg">View</a>
                            </div>
                        </div>

                        <?php
                        // fetch items for this order
                        $itemsStmt = $pdo->prepare("SELECT oi.*, p.name, p.image FROM order_items oi LEFT JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ?");
                        $itemsStmt->execute([$order['id']]);
                        $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
                        ?>

                        <div class="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                            <?php foreach ($items as $it): ?>
                                <div class="flex items-center gap-3">
                                    <img src="uploads/<?= htmlspecialchars($it['image'] ?? 'placeholder.jpg') ?>"
                                        class="w-20 h-20 object-cover rounded-lg">
                                    <div>
                                        <div class="font-semibold"><?= htmlspecialchars($it['name']) ?></div>
                                        <div class="text-sm text-gray-600">Qty: <?= (int) $it['quantity'] ?></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require 'includes/footer.php'; ?>