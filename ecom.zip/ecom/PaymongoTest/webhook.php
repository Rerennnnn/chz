<?php

// Get JSON body
$input = @file_get_contents("php://input");
$event = json_decode($input, true);

// Log to file (for testing)
file_put_contents("webhook_log.txt", date("Y-m-d H:i:s") . "\n" . $input . "\n\n", FILE_APPEND);

http_response_code(200);
echo "Webhook received.";
?>

