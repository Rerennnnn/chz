<?php
// PaymongoTest/success.php - handle return from PayMongo (test flow)
session_start();

require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/email.php'; // NEW: send email receipt
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/navbar.php';

$payment_intent_id = $_GET['pi_id'] ?? null;
$order_id = $_GET['order_id'] ?? null;

if (!$payment_intent_id && !$order_id) {
    echo '<div class="text-center py-20"><h1 class="text-3xl playfair text-red-600">Payment Failed</h1><p class="text-lg mt-4">No payment information found.</p><a href="../index.php" class="mt-8 inline-block bg-yellow-dark text-gray-900 px-8 py-4 rounded-lg font-semibold">Back to Home</a></div>';
    require __DIR__ . '/../includes/footer.php';
    exit();
}

// Try loading order
if ($payment_intent_id) {
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE payment_id = ?");
    $stmt->execute([$payment_intent_id]);
    $order = $stmt->fetch();
} elseif ($order_id) {
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch();
}

if (!$order) {
    echo '<div class="text-center py-20"><h1 class="text-3xl playfair text-red-600">Order Not Found</h1><p class="text-lg mt-4">We could not find your order.</p><a href="../index.php" class="mt-8 inline-block bg-yellow-dark text-gray-900 px-8 py-4 rounded-lg font-semibold">Back to Home</a></div>';
    require __DIR__ . '/../includes/footer.php';
    exit();
}

// =========================================
// 1) Mark order as paid + completed
// =========================================
$updateStmt = $pdo->prepare("
    UPDATE orders 
    SET status = 'completed', 
        payment_status = 'paid', 
        payment_id = COALESCE(payment_id, ?) 
    WHERE id = ?
");
$updateStmt->execute([$payment_intent_id, $order['id']]);

// =========================================
// 2) Insert delivery job for riders
// =========================================
try {
    $check = $pdo->prepare("SELECT id FROM deliveries WHERE order_id = ?");
    $check->execute([$order['id']]);
    $existingDelivery = $check->fetch();

    if (!$existingDelivery) {
        $pickupAddress  = 'Cheeze Tea Main Store';
        $dropoffAddress = $order['shipping_address'] ?? 'No address provided';

        $ins = $pdo->prepare("
            INSERT INTO deliveries (order_id, status, pickup_address, dropoff_address, created_at)
            VALUES (?, 'assigned', ?, ?, NOW())
        ");
        $ins->execute([$order['id'], $pickupAddress, $dropoffAddress]);
    }
} catch (Exception $e) {
    // error_log('Delivery creation failed: ' . $e->getMessage());
}

// =========================================
// 3) SEND EMAIL RECEIPT (FREE - Gmail SMTP)
// =========================================

$customerEmail = $order['customer_email'];
$customerName  = $order['customer_name'] ?? "Customer";

$subject = "Your Cheeze Tea Order Receipt (Order #{$order['id']})";

$body = "
    <h2 style='color:#d97706'>Thank you for your order, {$customerName}!</h2>

    <p>Your payment has been successfully received. Below is your receipt:</p>

    <div style='padding:12px; border:1px solid #ffe08a; border-radius:10px; background:#fff8e1;'>
        <p><strong>Order Number:</strong> #{$order['id']}</p>
        <p><strong>Total Amount:</strong> ₱" . number_format($order['total'],2) . "</p>
        <p><strong>Payment Status:</strong> PAID</p>
        <p><strong>Date:</strong> " . date('M d, Y', strtotime($order['created_at'])) . "</p>
    </div>

    <br>

    <p>Your drinks will now be prepared and a rider will deliver your order shortly.</p>
    <p>Thank you for supporting Cheeze Tea!</p>
";

sendEmail($customerEmail, $subject, $body);

// =========================================
// 4) Clear cart
// =========================================
unset($_SESSION['cart']);

?>

<div class="min-h-screen flex items-center justify-center px-4">
    <div class="max-w-2xl w-full text-center">
        <div class="bg-white rounded-3xl shadow-2xl p-12">
            <div class="mb-8">
                <div class="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                    <i class="fas fa-check-circle text-5xl text-green-600"></i>
                </div>
            </div>

            <h1 class="playfair text-5xl font-bold text-green-600 mb-4">Payment Successful!</h1>

            <div class="bg-green-50 border-2 border-green-200 rounded-2xl p-6 my-8">
                <p class="text-gray-700 text-lg mb-4">
                    Thank you for your purchase! Your payment has been received.
                </p>

                <div class="grid grid-cols-2 gap-6 my-8 text-left">
                    <div class="bg-white p-4 rounded-xl">
                        <p class="text-sm text-gray-600">Order Number</p>
                        <p class="text-2xl font-bold text-yellow-600">#<?php echo $order['id']; ?></p>
                    </div>
                    <div class="bg-white p-4 rounded-xl">
                        <p class="text-sm text-gray-600">Order Total</p>
                        <p class="text-2xl font-bold text-yellow-600">₱<?php echo number_format($order['total'], 2); ?></p>
                    </div>
                    <div class="bg-white p-4 rounded-xl">
                        <p class="text-sm text-gray-600">Payment Status</p>
                        <p class="text-2xl font-bold text-green-600">PAID</p>
                    </div>
                    <div class="bg-white p-4 rounded-xl">
                        <p class="text-sm text-gray-600">Order Date</p>
                        <p class="text-2xl font-bold text-gray-800">
                            <?php echo date('M d, Y', strtotime($order['created_at'])); ?>
                        </p>
                    </div>
                </div>

                <p class="text-gray-700 mb-4">
                    A copy of your receipt has been emailed to you.
                </p>
                <p class="text-gray-700 mb-4">
                    Our riders will deliver your order shortly.
                </p>
            </div>

            <div class="flex gap-4 justify-center">
                <a href="../index.php" class="px-8 py-4 bg-yellow-dark text-gray-900 rounded-2xl font-bold hover:bg-yellow-warm transition">
                    <i class="fas fa-home mr-2"></i> Back to Home
                </a>
                <a href="../products.php" class="px-8 py-4 bg-gray-600 text-white rounded-2xl font-bold hover:bg-gray-700 transition">
                    <i class="fas fa-shopping-bag mr-2"></i> Continue Shopping
                </a>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
