<?php
// Modified to accept forwarded order_id and amount and to redirect back into the app's paymongo success handler
if (!isset($_GET['pi_id']) || !isset($_GET['client_key'])) {
  die("Missing Payment Intent details.");
}

$intent_id = $_GET['pi_id'];
$client_key = $_GET['client_key'];
$order_id = $_GET['order_id'] ?? null;
$amount = $_GET['amount'] ?? null;

$cfgPath = __DIR__ . '/../includes/config.php';
if (file_exists($cfgPath)) {
    require $cfgPath;
    $secret_key = defined('PAYMONGO_SECRET_KEY') ? PAYMONGO_SECRET_KEY : 'sk_test_dfZGRR1A9SPwLtHH8woPgKfJ';
    $api_base = defined('PAYMONGO_API_URL') ? rtrim(PAYMONGO_API_URL, '/') : 'https://api.paymongo.com/v1';
} else {
    $secret_key = 'sk_test_dfZGRR1A9SPwLtHH8woPgKfJ';
    $api_base = 'https://api.paymongo.com/v1';
}

// Normalize amount for the payment method if provided (fallback to small amount)
if ($amount !== null) {
    $amount_raw = trim((string)$amount);
    $amount_raw = preg_replace('/[^0-9\.]/', '', $amount_raw);
    if (strpos($amount_raw, '.') !== false) {
        $amount_cents = (int) round(floatval($amount_raw) * 100);
    } else {
        $amtInt = (int)$amount_raw;
        $amount_cents = ($amtInt < 1000) ? $amtInt * 100 : $amtInt;
    }
} else {
    $amount_cents = 500; // default small amount for payment method
}

// Attach GCash payment
$data = [
  "data" => [
    "attributes" => [
      "type" => "gcash",
      "amount" => $amount_cents,
      "currency" => "PHP",
      "redirect" => [
        "return_url" => 'http://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '/ecom/PaymongoTest/success.php?pi_id=' . urlencode($intent_id) . ($order_id ? '&order_id=' . urlencode($order_id) : '')
      ]
    ]
  ]
];


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $api_base . "/payment_methods");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  "Content-Type: application/json",
  "Accept: application/json",
  "Authorization: Basic " . base64_encode($secret_key . ":")
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr = curl_error($ch);
curl_close($ch);

$payment_method = json_decode($response, true);

if (!isset($payment_method['data'])) {
  echo "<pre>";
  print_r($payment_method);
  echo "</pre>";
  die("❌ Error creating payment method.");
}

$pm_id = $payment_method['data']['id'];

// ================= Attach Payment Method =================
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $api_base . "/payment_intents/$intent_id/attach");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt(
  $ch,
  CURLOPT_POSTFIELDS,
  json_encode([
    "data" => [
      "attributes" => [
      "payment_method" => $pm_id,
      "client_key" => $client_key,
      "return_url" => 'http://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '/ecom/PaymongoTest/success.php?pi_id=' . urlencode($intent_id) . ($order_id ? '&order_id=' . urlencode($order_id) : '')
    ]
    ]
  ])
);

curl_setopt($ch, CURLOPT_HTTPHEADER, [
  "Content-Type: application/json",
  "Authorization: Basic " . base64_encode($secret_key . ":")
]);

$res = curl_exec($ch);
$httpCode2 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr2 = curl_error($ch);
curl_close($ch);

$result = json_decode($res, true);

if (!isset($result['data']['attributes']['next_action']['redirect']['url'])) {
  echo "<pre>";
  print_r($result);
  echo "</pre>";
  die("❌ Unable to redirect to GCash.");
}

$redirect_url = $result['data']['attributes']['next_action']['redirect']['url'];

header("Location: $redirect_url");
exit;

?>
