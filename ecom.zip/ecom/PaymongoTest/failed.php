<?php
session_start();
require __DIR__ . '/../includes/db.php';
require __DIR__ . '/../includes/header.php';

$page_title = "Payment Failed - Cheeze Tea";
$order_id = $_GET['order_id'] ?? null;

?>

<body class="bg-gradient-to-br from-red-50 to-orange-50 pt-32">
    <!-- Include Navbar -->
    <?php require __DIR__ . '/../includes/navbar.php'; ?>

    <div class="min-h-screen flex items-center justify-center px-4 pb-12">
        <div class="max-w-2xl w-full text-center">
            <div class="bg-white rounded-3xl shadow-2xl p-12">
                <div class="mb-8">
                    <div class="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center mx-auto">
                        <i class="fas fa-times-circle text-5xl text-red-600"></i>
                    </div>
                </div>

                <h1 class="playfair text-5xl font-bold text-red-600 mb-4">Payment Failed</h1>

                <div class="bg-red-50 border-2 border-red-200 rounded-2xl p-6 my-8">
                    <p class="text-gray-700 text-lg mb-4">
                        Unfortunately, your payment could not be processed.
                    </p>

                    <p class="text-gray-700 mb-4">
                        This may be due to:
                    </p>

                    <ul class="text-left text-gray-600 max-w-md mx-auto mb-6">
                        <li class="mb-2"><i class="fas fa-check text-red-500 mr-2"></i> Insufficient funds</li>
                        <li class="mb-2"><i class="fas fa-check text-red-500 mr-2"></i> Invalid card details</li>
                        <li class="mb-2"><i class="fas fa-check text-red-500 mr-2"></i> Network error</li>
                        <li class="mb-2"><i class="fas fa-check text-red-500 mr-2"></i> Transaction declined by bank
                        </li>
                    </ul>

                    <p class="text-gray-700 mb-4">
                        Please try again or use a different payment method.
                    </p>

                    <?php if ($order_id): ?>
                        <p class="text-sm text-gray-600">
                            Order ID: <strong>#<?php echo htmlspecialchars($order_id); ?></strong>
                        </p>
                    <?php endif; ?>
                </div>

                <div class="flex gap-4 justify-center flex-wrap">
                    <a href="../checkout.php"
                        class="px-8 py-4 bg-amber-600 text-white rounded-2xl font-bold hover:bg-amber-700 transition">
                        <i class="fas fa-redo mr-2"></i> Retry Payment
                    </a>
                    <a href="../cart.php"
                        class="px-8 py-4 bg-gray-600 text-white rounded-2xl font-bold hover:bg-gray-700 transition">
                        <i class="fas fa-shopping-cart mr-2"></i> Back to Cart
                    </a>
                    <a href="../index.php"
                        class="px-8 py-4 bg-yellow-dark text-gray-900 rounded-2xl font-bold hover:bg-yellow-warm transition">
                        <i class="fas fa-home mr-2"></i> Home
                    </a>
                </div>
            </div>
        </div>
    </div>

</body>

<?php require __DIR__ . '/../includes/footer.php'; ?>