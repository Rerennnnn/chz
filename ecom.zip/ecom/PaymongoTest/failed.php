<?php
echo "<h1>❌ PAYMENT FAILED</h1>";
echo "<p>The transaction was not completed.</p>";
?>
