<?php
require 'includes/db.php';
require 'includes/config.php';
require 'includes/auth.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit();
}

$total = 0;
$items = [];

foreach ($_SESSION['cart'] as $cart_key => $item) {
    if (is_array($item)) {
        $product_id = $item['product_id'];
        $qty = $item['qty'];
        $size = $item['size'] ?? null;
    } else {
        $product_id = $cart_key;
        $qty = $item;
        $size = null;
    }

    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $p = $stmt->fetch();
    if ($p) {
        // determine unit price (if item stored unit_price use it, otherwise product price)
        $unit_price = null;
        if (is_array($item) && isset($item['unit_price'])) {
            $unit_price = $item['unit_price'];
        }
        if ($unit_price === null)
            $unit_price = $p['price'];

        $p['qty'] = $qty;
        $p['size'] = $size;
        $p['unit_price'] = $unit_price;
        $items[] = $p;
        $total += $unit_price * $qty;
    }
}

// If form is submitted, create order and process payment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_name = trim($_POST['name'] ?? $_SESSION['name']);
    $customer_email = trim($_POST['email'] ?? '');
    $customer_phone = trim($_POST['phone'] ?? '');
    $shipping_address = trim($_POST['address'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    $payment_method = $_POST['payment_method'] ?? 'card'; // 'gcash' or 'card' (treat Maya as card)

    if (!$customer_email || !$shipping_address) {
        $error = 'Please fill in all required fields.';
    } else {
        // Create order
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("INSERT INTO orders (user_id, total, customer_name, customer_email, customer_phone, shipping_address, notes, payment_status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')");
            $stmt->execute([$_SESSION['user_id'], $total, $customer_name, $customer_email, $customer_phone, $shipping_address, $notes]);
            $order_id = $pdo->lastInsertId();

            // Add order items
            foreach ($_SESSION['cart'] as $cart_key => $item) {
                if (is_array($item)) {
                    $product_id = $item['product_id'];
                    $qty = $item['qty'];
                    $size = $item['size'] ?? null;
                    $unit_price = $item['unit_price'] ?? null;
                } else {
                    $product_id = $cart_key;
                    $qty = $item;
                    $size = null;
                    $unit_price = null;
                }

                // fallback to DB price when unit_price not provided
                if ($unit_price === null) {
                    $stmt = $pdo->prepare("SELECT price FROM products WHERE id = ?");
                    $stmt->execute([$product_id]);
                    $unit_price = $stmt->fetchColumn();
                }

                $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                $stmt->execute([$order_id, $product_id, $qty, $unit_price]);
            }

            $pdo->commit();

            // Redirect depending on chosen payment method
            $amount_in_cents = intval($total * 100);
            if ($payment_method === 'gcash') {
                // Use PaymongoTest GCash flow
                header('Location: PaymongoTest/create_intent.php?order_id=' . $order_id . '&amount=' . $amount_in_cents . '&method=gcash');
                exit();
            } else {
                // Default: use Checkout modal for card-type payments (Card / Maya)
                header('Location: paymongo/checkout.php?order_id=' . $order_id . '&amount=' . $amount_in_cents . '&name=' . urlencode($customer_name) . '&email=' . urlencode($customer_email));
                exit();
            }
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = 'Error creating order: ' . $e->getMessage();
        }
    }
}
?>

<?php
// Include header (outputs HTML head) and navbar after any redirects/processing
require 'includes/header.php';
require 'includes/navbar.php';
?>

<div class="min-h-screen bg-cream poppins">
    <div class="max-w-6xl mx-auto px-4 py-12">
        <h1 class="playfair text-5xl font-bold text-yellow-dark mb-12">Checkout</h1>

        <?php if (isset($error)): ?>
            <div class="bg-red-100 border-2 border-red-300 text-red-800 px-6 py-4 rounded-xl mb-8">
                <i class="fas fa-exclamation-circle mr-2"></i> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Order Summary -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-3xl shadow-lg p-8 mb-8">
                    <h2 class="text-2xl font-bold text-yellow-dark mb-6">Order Summary</h2>

                    <div class="space-y-4 mb-6">
                        <?php
                        // Render items prepared earlier
                        $item_count = 0;
                        foreach ($items as $product):
                            $item_count += (int) ($product['qty'] ?? 0);
                            ?>
                            <div class="flex items-center justify-between border-b border-gray-200 pb-4">
                                <div class="flex items-center gap-4">
                                    <img src="uploads/<?php echo htmlspecialchars($product['image']); ?>"
                                        alt="<?php echo htmlspecialchars($product['name']); ?>"
                                        class="w-20 h-20 rounded-lg object-cover">
                                    <div>
                                        <p class="font-semibold text-gray-800">
                                            <?php echo htmlspecialchars($product['name']); ?>
                                        </p>
                                        <p class="text-sm text-gray-600">Qty: <?php echo (int) $product['qty']; ?>
                                            <?php if (!empty($product['size'])): ?>
                                                · <?php echo htmlspecialchars(ucfirst($product['size'])); ?>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                                <p class="font-bold text-yellow-dark">
                                    ₱<?php echo number_format(($product['unit_price'] ?? $product['price']) * $product['qty'], 2); ?>
                                </p>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="border-t-2 border-yellow-200 pt-6">
                        <div class="flex justify-between items-center text-lg font-bold">
                            <span>Total:</span>
                            <span class="text-3xl text-yellow-dark">₱<?php echo number_format($total, 2); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Checkout Form -->
                <div class="bg-white rounded-3xl shadow-lg p-8">
                    <h2 class="text-2xl font-bold text-yellow-dark mb-6">Delivery Information</h2>

                    <form method="POST" class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Full Name *</label>
                                <input type="text" name="name"
                                    value="<?php echo htmlspecialchars($_SESSION['name'] ?? ''); ?>" required
                                    class="w-full px-4 py-3 border-2 border-yellow-200 rounded-xl focus:outline-none focus:border-yellow-600">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Email *</label>
                                <input type="email" name="email" required
                                    class="w-full px-4 py-3 border-2 border-yellow-200 rounded-xl focus:outline-none focus:border-yellow-600">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Phone Number</label>
                            <input type="tel" name="phone"
                                class="w-full px-4 py-3 border-2 border-yellow-200 rounded-xl focus:outline-none focus:border-yellow-600">
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Delivery Address *</label>
                            <textarea name="address" required rows="4"
                                class="w-full px-4 py-3 border-2 border-yellow-200 rounded-xl focus:outline-none focus:border-yellow-600"
                                placeholder="Street address, city, postal code"></textarea>
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Special Instructions
                                (Optional)</label>
                            <textarea name="notes" rows="3"
                                class="w-full px-4 py-3 border-2 border-yellow-200 rounded-xl focus:outline-none focus:border-yellow-600"
                                placeholder="Any special requests or notes for us..."></textarea>
                        </div>

                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Payment Method *</label>
                                <div class="flex items-center gap-4">
                                    <label class="inline-flex items-center">
                                        <input type="radio" name="payment_method" value="gcash" class="form-radio" />
                                        <span class="ml-2">GCash (redirect)</span>
                                    </label>
                                    <label class="inline-flex items-center">
                                        <input type="radio" name="payment_method" value="card" checked
                                            class="form-radio" />
                                        <span class="ml-2">Maya / Credit or Debit Card (inline)</span>
                                    </label>
                                </div>
                            </div>

                            <div class="flex gap-4">
                                <a href="cart.php"
                                    class="flex-1 px-6 py-4 bg-gray-400 text-white rounded-xl font-bold text-center hover:bg-gray-500 transition">
                                    <i class="fas fa-arrow-left mr-2"></i> Back to Cart
                                </a>
                                <button type="submit"
                                    class="flex-1 px-6 py-4 bg-yellow-dark text-gray-900 rounded-xl font-bold text-center hover:bg-yellow-warm transition">
                                    <i class="fas fa-credit-card mr-2"></i> Proceed to Payment
                                </button>
                            </div>
                    </form>
                </div>
            </div>

            <!-- Price Breakdown -->
            <div class="lg:col-span-1">
                <div class="bg-gradient-to-br from-yellow-100 to-amber-50 rounded-3xl p-8 sticky top-24">
                    <h3 class="text-xl font-bold text-yellow-dark mb-6">Price Breakdown</h3>

                    <div class="space-y-4 mb-6 pb-6 border-b-2 border-yellow-200">
                        <div class="flex justify-between">
                            <span class="text-gray-700">Subtotal (<?php echo $item_count; ?> items)</span>
                            <span class="font-semibold">₱<?php echo number_format($total, 2); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-700">Delivery Fee</span>
                            <span class="font-semibold">FREE</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-700">Discount</span>
                            <span class="font-semibold text-green-600">₱0.00</span>
                        </div>
                    </div>

                    <div class="flex justify-between text-2xl font-bold text-yellow-dark">
                        <span>Total:</span>
                        <span>₱<?php echo number_format($total, 2); ?></span>
                    </div>

                    <p class="text-xs text-gray-600 mt-6 text-center">
                        We accept GCash, Credit/Debit Cards
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require 'includes/footer.php'; ?>