<?php
$page_title = "Menu – Cheeze Tea Alaminos";

require 'includes/db.php';
require 'includes/header.php';
require 'includes/navbar.php';

/* Safe query */
try {
    $stmt = $pdo->query("SELECT id, name, price, image, category FROM products ORDER BY id DESC");
} catch (PDOException $e) {
    $stmt = $pdo->query("SELECT id, name, price, image FROM products ORDER BY id DESC");
}
$all_products = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* Enhanced Categories with Beautiful Icons */
$categories = [
    'milktea' => [
        'name' => 'Cheese Milk Tea',
        'icon' => '<svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M3 2l2.01 18.23C5.13 21.23 5.97 22 7 22h10c1.03 0 1.87-.77 1.99-1.77L21 2H3zm9 17c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3z"/></svg>',
        'gradient' => 'from-amber-400 to-orange-500',
        'bg' => 'bg-gradient-to-br from-amber-50 to-orange-50'
    ],
    'milkshake' => [
        'name' => 'Milkshakes',
        'icon' => '<svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M4 18h16v2H4v-2zM20 2H4v2l8 9v5h-3v2h10v-2h-3v-5l8-9V2zm-6.5 11.5l-.5.5H11l-.5-.5L4.62 4h14.76l-5.88 9.5z"/></svg>',
        'gradient' => 'from-pink-400 to-rose-500',
        'bg' => 'bg-gradient-to-br from-pink-50 to-rose-50'
    ],
    'fruittea' => [
        'name' => 'Fresh Fruit Tea',
        'icon' => '<svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l-5.5 9h11L12 2zm0 3.84L13.93 9h-3.87L12 5.84zM17.5 13c-1.93 0-3.5 1.57-3.5 3.5s1.57 3.5 3.5 3.5 3.5-1.57 3.5-3.5-1.57-3.5-3.5-3.5zm0 5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm-11-5C4.57 13 3 14.57 3 16.5S4.57 20 6.5 20 10 18.43 10 16.5 8.43 13 6.5 13zm0 5c-.83 0-1.5-.67-1.5-1.5S5.67 15 6.5 15s1.5.67 1.5 1.5S7.33 18 6.5 18z"/></svg>',
        'gradient' => 'from-green-400 to-emerald-500',
        'bg' => 'bg-gradient-to-br from-green-50 to-emerald-50'
    ],
    'sparkling' => [
        'name' => 'Sparkling Soda',
        'icon' => '<svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2l-5.5 9h11L12 2zm0 3.84L13.93 9h-3.87L12 5.84zM17.5 13c-1.93 0-3.5 1.57-3.5 3.5s1.57 3.5 3.5 3.5 3.5-1.57 3.5-3.5-1.57-3.5-3.5-3.5zm0 5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm-11-5C4.57 13 3 14.57 3 16.5S4.57 20 6.5 20 10 18.43 10 16.5 8.43 13 6.5 13zm0 5c-.83 0-1.5-.67-1.5-1.5S5.67 15 6.5 15s1.5.67 1.5 1.5S7.33 18 6.5 18z"/></svg>',
        'gradient' => 'from-blue-400 to-cyan-500',
        'bg' => 'bg-gradient-to-br from-blue-50 to-cyan-50'
    ],
    'coffee' => [
        'name' => 'Premium Coffee',
        'icon' => '<svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M20 3H4v10c0 2.21 1.79 4 4 4h6c2.21 0 4-1.79 4-4v-3h2c1.11 0 2-.89 2-2V5c0-1.11-.89-2-2-2zm0 5h-2V5h2v3zM4 19h16v2H4v-2z"/></svg>',
        'gradient' => 'from-amber-600 to-yellow-700',
        'bg' => 'bg-gradient-to-br from-amber-50 to-yellow-50'
    ],
    'food' => [
        'name' => 'Snacks & Treats',
        'icon' => '<svg class="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M18.06 22.99h1.66c.84 0 1.53-.64 1.63-1.46L23 5.05h-5V1h-1.97v4.05h-4.97l.3 2.34c1.71.47 3.31 1.32 4.27 2.26 1.44 1.42 2.43 2.89 2.43 5.29v8.05zM1 21.99V21h15.03v.99c0 .55-.45 1-1.01 1H2.01c-.56 0-1.01-.45-1.01-1zm15.03-7c0-8-15.03-8-15.03 0h15.03zM1.02 17h15v2h-15v-2z"/></svg>',
        'gradient' => 'from-purple-400 to-indigo-500',
        'bg' => 'bg-gradient-to-br from-purple-50 to-indigo-50'
    ]
];

/* Group products */
$grouped = [];
foreach ($all_products as $p) {
    $cat = 'milktea';
    if (!empty($p['category'])) {
        $candidate = strtolower(trim($p['category']));
        if (isset($categories[$candidate])) {
            $cat = $candidate;
        }
    }
    $grouped[$cat][] = $p;
}
?>

<style>
    /* Floating Background Bubbles */
    @keyframes float {

        0%,
        100% {
            transform: translateY(0) translateX(0);
            opacity: 0.6;
        }

        25% {
            transform: translateY(-20px) translateX(10px);
            opacity: 0.8;
        }

        50% {
            transform: translateY(-40px) translateX(-10px);
            opacity: 0.7;
        }

        75% {
            transform: translateY(-20px) translateX(5px);
            opacity: 0.9;
        }
    }

    /* Premium Card Hover Effect */
    .product-card {
        transition: all 0.5s cubic-bezier(0.23, 1, 0.32, 1);
        position: relative;
        overflow: hidden;
    }

    .product-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
        transition: left 0.7s;
    }

    .product-card:hover::before {
        left: 100%;
    }

    .product-card:hover {
        transform: translateY(-12px) scale(1.02);
        box-shadow: 0 30px 60px rgba(0, 0, 0, 0.15);
    }

    .product-card img {
        transition: transform 0.7s cubic-bezier(0.23, 1, 0.32, 1);
    }

    .product-card:hover img {
        transform: scale(1.15) rotate(2deg);
    }

    /* Category Tab Animation */
    .tab-btn {
        position: relative;
        transition: all 0.4s cubic-bezier(0.23, 1, 0.32, 1);
    }

    .tab-btn::after {
        content: '';
        position: absolute;
        bottom: -2px;
        left: 50%;
        width: 0;
        height: 3px;
        background: linear-gradient(90deg, #f59e0b, #f97316);
        transition: all 0.4s cubic-bezier(0.23, 1, 0.32, 1);
        transform: translateX(-50%);
        border-radius: 3px;
    }

    .tab-btn.active::after {
        width: 80%;
    }

    .tab-btn:hover {
        transform: translateY(-2px);
    }

    /* Price Badge Animation */
    @keyframes price-shine {
        0% {
            background-position: -200% center;
        }

        100% {
            background-position: 200% center;
        }
    }

    .price-badge {
        background: linear-gradient(90deg, #f97316, #fbbf24, #f97316);
        background-size: 200% auto;
        animation: price-shine 3s linear infinite;
    }

    /* Button Glow Effect */
    .btn-glow {
        position: relative;
        overflow: hidden;
    }

    .btn-glow::before {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 0;
        height: 0;
        background: rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        transform: translate(-50%, -50%);
        transition: width 0.6s, height 0.6s;
    }

    .btn-glow:hover::before {
        width: 300px;
        height: 300px;
    }

    /* Category Icon Rotation */
    @keyframes icon-float {

        0%,
        100% {
            transform: translateY(0) rotate(0deg);
        }

        50% {
            transform: translateY(-5px) rotate(5deg);
        }
    }

    .category-icon {
        animation: icon-float 3s ease-in-out infinite;
    }

    /* Staggered Fade In */
    .fade-in-up {
        opacity: 0;
        transform: translateY(30px);
        animation: fadeInUp 0.8s cubic-bezier(0.23, 1, 0.32, 1) forwards;
    }

    @keyframes fadeInUp {
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
</style>

<!-- Enhanced Background Animation -->
<div
    class="fixed inset-0 -z-10 pointer-events-none overflow-hidden bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50">
    <?php for ($i = 1; $i <= 25; $i++):
        $s = rand(20, 50);
        $d = 15 + rand(0, 20);
        $del = $i * 0.7;
        $l = rand(0, 100);
        $t = rand(0, 100);
        ?>
        <div style="position:absolute; left:<?= $l ?>%; top:<?= $t ?>%; animation-delay:<?= $del ?>s;">
            <div class="rounded-full bg-gradient-to-br from-amber-300/20 to-orange-300/20 backdrop-blur-sm"
                style="width:<?= $s ?>px; height:<?= $s ?>px; animation: float <?= $d ?>s ease-in-out infinite;">
            </div>
        </div>
    <?php endfor; ?>
</div>

<!-- HERO SECTION -->
<section class="py-32 text-center relative z-10">
    <div class="max-w-5xl mx-auto px-6">
        <div class="mb-6" data-aos="zoom-in">
            <span class="text-8xl inline-block transform hover:scale-110 transition-transform duration-300">🧀</span>
        </div>
        <h1 class="text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-600 via-orange-600 to-amber-600 mb-8 leading-tight"
            data-aos="fade-up" style="background-size: 200% auto; animation: gradient-shift 3s ease infinite;">
            Our Full Menu
        </h1>
        <p class="text-2xl md:text-3xl text-amber-800 font-semibold mb-4" data-aos="fade-up" data-aos-delay="200">
            Choose your kind of happiness ✨
        </p>
        <p class="text-lg md:text-xl text-amber-700" data-aos="fade-up" data-aos-delay="300">
            Handcrafted with premium ingredients, made fresh daily
        </p>
    </div>
</section>

<!-- ENHANCED CATEGORY TABS -->
<div class="z-40 bg-white/80 backdrop-blur-2xl border-b-2 border-amber-200 shadow-lg py-6">
    <div class="max-w-7xl mx-auto px-6">
        <div class="flex justify-center gap-3 md:gap-4 flex-wrap">
            <?php foreach ($categories as $key => $cat): ?>
                <button onclick="showCategory('<?= $key ?>')"
                    class="tab-btn <?= $key === 'milktea' ? 'active' : '' ?> group px-6 py-4 rounded-2xl text-base md:text-lg font-bold transition-all bg-white shadow-md hover:shadow-xl border-2 border-transparent hover:border-amber-300"
                    data-cat="<?= $key ?>">
                    <div class="flex items-center gap-3">
                        <span class="category-icon text-amber-600 group-hover:text-orange-600 transition-colors">
                            <?= $cat['icon'] ?>
                        </span>
                        <span class="text-gray-800 group-hover:text-amber-700 transition-colors">
                            <?= $cat['name'] ?>
                        </span>
                    </div>
                </button>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- PRODUCTS SECTION -->
<section class="py-20 relative z-10">
    <div class="max-w-7xl mx-auto px-6">

        <?php foreach ($categories as $key => $cat):
            $products = $grouped[$key] ?? [];
            ?>

            <div id="<?= $key ?>" class="category-section <?= $key === 'milktea' ? '' : 'hidden' ?>">

                <!-- Category Header -->
                <div class="text-center mb-16 <?= $cat['bg'] ?> py-12 rounded-3xl shadow-lg" data-aos="fade-down">
                    <div class="inline-block p-6 bg-white rounded-full shadow-xl mb-6">
                        <span class="text-5xl text-amber-600">
                            <?= $cat['icon'] ?>
                        </span>
                    </div>
                    <h2
                        class="text-5xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-<?= $cat['gradient'] ?> mb-4">
                        <?= $cat['name'] ?>
                    </h2>
                    <p class="text-xl text-gray-700 font-medium">
                        Discover our finest selection
                    </p>
                </div>

                <?php if (empty($products)): ?>
                    <div class="text-center py-20 bg-white/50 rounded-3xl backdrop-blur-sm">
                        <span class="text-7xl block mb-6">🎉</span>
                        <p class="text-3xl font-bold text-amber-700 mb-4">Coming Soon!</p>
                        <p class="text-xl text-gray-600">Amazing new items are on the way</p>
                    </div>
                <?php else: ?>

                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">

                        <?php foreach ($products as $i => $p):
                            $image = (!empty($p['image']) && file_exists(__DIR__ . "/uploads/" . $p['image']))
                                ? $p['image']
                                : "placeholder.jpg";
                            ?>

                            <div class="fade-in-up" style="animation-delay: <?= ($i % 8) * 0.1 ?>s" data-aos="fade-up"
                                data-aos-delay="<?= ($i % 8) * 80 ?>">
                                <div
                                    class="product-card bg-white rounded-3xl shadow-xl border-2 border-amber-100 overflow-hidden flex flex-col h-full group">

                                    <!-- Product Image -->
                                    <div class="relative overflow-hidden h-72">
                                        <img src="uploads/<?= $image ?>" class="w-full h-full object-cover"
                                            alt="<?= htmlspecialchars($p['name']) ?>">

                                        <!-- Overlay Gradient -->
                                        <div
                                            class="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                                        </div>

                                        <!-- Floating Badge -->
                                        <div
                                            class="absolute top-4 right-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg transform translate-x-0 group-hover:translate-x-1 group-hover:translate-y-1 transition-transform">
                                            Fresh Daily
                                        </div>
                                    </div>

                                    <!-- Product Info -->
                                    <div class="p-6 flex flex-col flex-grow">
                                        <h3
                                            class="text-2xl font-black text-gray-800 mb-3 group-hover:text-amber-700 transition-colors leading-tight">
                                            <?= htmlspecialchars($p['name']) ?>
                                        </h3>

                                        <!-- Price Badge -->
                                        <div class="mb-6">
                                            <div
                                                class="inline-block price-badge text-white font-black text-3xl px-6 py-3 rounded-2xl shadow-lg -webkit-background-clip-text background-clip-text">
                                                ₱<?= number_format($p['price'], 2) ?>
                                            </div>
                                        </div>

                                        <!-- Action Buttons -->
                                        <div class="flex gap-3 mt-auto">
                                            <a href="view_product.php?id=<?= $p['id'] ?>"
                                                class="btn-glow flex-1 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold py-4 rounded-2xl transition-all duration-300 shadow-lg hover:shadow-xl text-center relative overflow-hidden">
                                                <span class="relative z-10">View Details</span>
                                            </a>

                                            <form action="add_to_cart.php" method="POST" class="flex-shrink-0">
                                                <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                                                <button
                                                    class="btn-glow bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white rounded-2xl w-16 h-16 font-bold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center relative overflow-hidden">
                                                    <i class="fa fa-cart-plus text-xl relative z-10"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php endforeach; ?>

                    </div>
                <?php endif; ?>
            </div>

        <?php endforeach; ?>
    </div>
</section>

<!-- Call to Action -->
<section class="py-20 relative z-10">
    <div class="max-w-4xl mx-auto px-6 text-center bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 rounded-3xl shadow-2xl p-12"
        data-aos="zoom-in">
        <span class="text-7xl block mb-6">🎊</span>
        <h3 class="text-4xl md:text-5xl font-black text-white mb-6">
            Can't Decide?
        </h3>
        <p class="text-xl text-white/90 mb-8">
            Try our staff recommendations or create your own custom blend!
        </p>
        <a href="#milktea" onclick="showCategory('milktea')"
            class="inline-block bg-white text-amber-700 px-10 py-5 rounded-full font-black text-xl shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-300">
            Explore Best Sellers
        </a>
    </div>
</section>

<?php require 'includes/footer.php'; ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {

        if (typeof AOS !== 'undefined') {
            AOS.init({
                duration: 900,
                once: true,
                offset: 100,
                easing: 'ease-out-cubic'
            });
        }

        window.showCategory = function (id) {
            // Hide all sections with fade out
            document.querySelectorAll('.category-section').forEach(el => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(20px)';
                setTimeout(() => el.classList.add('hidden'), 300);
            });

            // Show target section with fade in
            setTimeout(() => {
                const target = document.getElementById(id);
                if (target) {
                    target.classList.remove('hidden');
                    setTimeout(() => {
                        target.style.opacity = '1';
                        target.style.transform = 'translateY(0)';
                    }, 50);
                }
            }, 300);

            // Update tab styles
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('active', 'border-amber-400', 'shadow-xl');
                btn.classList.add('border-transparent', 'shadow-md');
            });

            const active = document.querySelector('[data-cat="' + id + '"]');
            if (active) {
                active.classList.add('active', 'border-amber-400', 'shadow-xl');
                active.classList.remove('border-transparent');
            }

            // Smooth scroll to top of products
            window.scrollTo({ top: 400, behavior: 'smooth' });
        };

        // Add transition styles
        document.querySelectorAll('.category-section').forEach(el => {
            el.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        });
    });
</script>