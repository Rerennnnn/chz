<?php
$page_title = "Cheeze Tea Alaminos Laguna - Premium Cheese Foam Milk Tea";
require 'includes/db.php';
require 'includes/header.php';
require 'includes/navbar.php';

$best_sellers = $pdo->query("SELECT * FROM products ORDER BY id DESC LIMIT 10")->fetchAll();
$best_sellers = array_merge($best_sellers, array_slice($best_sellers, 0, 3));
?>

<!DOCTYPE html>
<html lang="en" class="scroll-smooth">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?= $page_title ?></title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
    <link rel="stylesheet" href="assets/index.css?v=<?= time() ?>" />

    <style>
        /* Advanced Particle System */
        @keyframes float-up {
            0% {
                transform: translateY(100vh) translateX(0) scale(0);
                opacity: 0;
            }

            10% {
                opacity: 0.8;
            }

            90% {
                opacity: 0.6;
            }

            100% {
                transform: translateY(-100vh) translateX(var(--drift)) scale(1.5);
                opacity: 0;
            }
        }

        .particle {
            position: absolute;
            background: radial-gradient(circle, rgba(251, 191, 36, 0.6), rgba(245, 158, 11, 0.3));
            border-radius: 50%;
            pointer-events: none;
            animation: float-up linear infinite;
            box-shadow: 0 0 20px rgba(251, 191, 36, 0.4);
            filter: blur(1px);
        }

        /* Magnetic Hero Text Effect */
        .hero-gradient-text {
            background: linear-gradient(135deg, #f59e0b, #fbbf24, #f97316, #fbbf24, #f59e0b);
            background-size: 300% 300%;
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: gradient-shift 8s ease infinite, text-glow 2s ease-in-out infinite;
            text-shadow: 0 0 80px rgba(251, 191, 36, 0.3);
            filter: drop-shadow(0 10px 30px rgba(251, 191, 36, 0.4));
        }

        @keyframes gradient-shift {

            0%,
            100% {
                background-position: 0% 50%;
            }

            50% {
                background-position: 100% 50%;
            }
        }

        @keyframes text-glow {

            0%,
            100% {
                filter: drop-shadow(0 10px 30px rgba(251, 191, 36, 0.4));
            }

            50% {
                filter: drop-shadow(0 15px 50px rgba(251, 191, 36, 0.7));
            }
        }

        /* 3D Card Hover Effect */
        .card-3d {
            transform-style: preserve-3d;
            transition: all 0.6s cubic-bezier(0.23, 1, 0.32, 1);
        }

        .card-3d:hover {
            transform: translateY(-20px) rotateX(5deg) rotateY(5deg);
        }

        .card-3d::before {
            content: '';
            position: absolute;
            inset: -2px;
            background: linear-gradient(45deg, #fbbf24, #f59e0b, #f97316);
            border-radius: 1.5rem;
            opacity: 0;
            transition: opacity 0.6s;
            z-index: -1;
            filter: blur(20px);
        }

        .card-3d:hover::before {
            opacity: 0.6;
            animation: border-glow 2s ease-in-out infinite;
        }

        @keyframes border-glow {

            0%,
            100% {
                filter: blur(20px);
            }

            50% {
                filter: blur(30px);
            }
        }

        /* Staggered Fade In */
        .stagger-fade {
            opacity: 0;
            transform: translateY(30px);
            animation: stagger-in 0.8s cubic-bezier(0.23, 1, 0.32, 1) forwards;
        }

        @keyframes stagger-in {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Interactive Button Ripple */
        .btn-ripple {
            position: relative;
            overflow: hidden;
        }

        .btn-ripple::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.5);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }

        .btn-ripple:hover::after {
            width: 300px;
            height: 300px;
        }

        /* Scroll Reveal Animation */
        .scroll-reveal {
            opacity: 0;
            transform: translateY(50px);
            transition: all 1s cubic-bezier(0.23, 1, 0.32, 1);
        }

        .scroll-reveal.active {
            opacity: 1;
            transform: translateY(0);
        }

        /* Parallax Effect */
        .parallax-layer {
            transition: transform 0.3s cubic-bezier(0.23, 1, 0.32, 1);
        }

        /* Shimmer Effect */
        @keyframes shimmer {
            0% {
                background-position: -1000px 0;
            }

            100% {
                background-position: 1000px 0;
            }
        }

        .shimmer {
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            background-size: 1000px 100%;
            animation: shimmer 3s infinite;
        }

        /* Price Pop Animation */
        @keyframes price-pop {

            0%,
            100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.1);
            }
        }

        .price-pop:hover {
            animation: price-pop 0.6s ease-in-out;
        }

        /* Glowing Dots */
        .dot {
            transition: all 0.5s cubic-bezier(0.23, 1, 0.32, 1);
            cursor: pointer;
        }

        .dot:hover {
            transform: scale(1.5);
            box-shadow: 0 0 20px rgba(251, 191, 36, 0.8);
        }

        /* Hero Subtitle Animation */
        @keyframes fade-slide-up {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .hero-subtitle {
            animation: fade-slide-up 1s ease-out 0.5s backwards;
        }

        /* CTA Pulse */
        @keyframes pulse-glow {

            0%,
            100% {
                box-shadow: 0 0 40px rgba(251, 191, 36, 0.4);
            }

            50% {
                box-shadow: 0 0 80px rgba(251, 191, 36, 0.8);
            }
        }

        .cta-pulse {
            animation: pulse-glow 2s ease-in-out infinite;
        }
    </style>
</head>

<body class="bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 text-gray-800 overflow-x-hidden">

    <!-- Enhanced Floating Bubbles with Dynamic Movement -->
    <div class="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <?php for ($i = 1; $i <= 25; $i++):
            $drift = rand(-100, 100);
            ?>
            <div class="particle" style="
            left: <?= rand(0, 100) ?>%;
            --drift: <?= $drift ?>px;
            animation-delay: <?= $i * 0.6 ?>s;
            animation-duration: <?= 15 + rand(0, 20) ?>s;
            width: <?= rand(10, 40) ?>px;
            height: <?= rand(10, 40) ?>px;
        "></div>
        <?php endfor; ?>
    </div>

    <!-- HERO with Magnetic Text & Parallax -->
    <section class="relative min-h-screen flex items-center justify-center px-6 parallax-section">
        <div class="hero-half-gradient absolute inset-y-0 left-0 w-1/2 pointer-events-none z-0"></div>
        <div class="container mx-auto text-center max-w-5xl relative z-10">
            <div class="stagger-fade" style="animation-delay: 0.2s">
                <h1
                    class="hero-gradient-text text-7xl sm:text-8xl md:text-9xl lg:text-[12rem] font-black leading-tight mb-8 cursor-default">
                    Cheeze Tea
                </h1>
            </div>

            <p
                class="hero-subtitle text-2xl sm:text-3xl md:text-4xl font-medium text-amber-800 mb-16 max-w-3xl mx-auto">
                Creamy • Dreamy • Made with Love in Alaminos, Laguna
            </p>

            <div class="flex flex-col sm:flex-row gap-8 justify-center stagger-fade" style="animation-delay: 0.8s">
                <a href="#creations"
                    class="btn btn-lg btn-ripple bg-gradient-to-r from-yellow-500 to-amber-600 text-white border-0 text-xl px-14 py-7 rounded-full shadow-2xl hover:shadow-3xl transform hover:scale-110 transition-all duration-500 cta-pulse">
                    <span class="relative z-10">Explore Menu</span>
                </a>
                <a href="#gallery"
                    class="btn btn-lg btn-ripple bg-white/90 backdrop-blur-md text-amber-700 border-4 border-amber-400 hover:bg-amber-50 text-xl px-14 py-7 rounded-full shadow-2xl hover:scale-110 transition-all duration-500">
                    <span class="relative z-10">See Moments</span>
                </a>
            </div>
        </div>

        <!-- Scroll Indicator -->
        <div class="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
            <i class="fas fa-chevron-down text-4xl text-amber-600 opacity-70"></i>
        </div>
    </section>

    <!-- SIGNATURE CREATIONS with 3D Cards -->
    <section id="creations" class="py-32 bg-white relative scroll-reveal">
        <div class="container mx-auto px-6 max-w-7xl">
            <h2 class="text-6xl md:text-8xl font-black text-center text-transparent bg-clip-text bg-gradient-to-r from-amber-600 to-orange-600 mb-24"
                data-aos="fade-down">
                Signature Creations
            </h2>

            <div
                class="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-50/70 to-yellow-50/70 glass py-12 shadow-2xl">
                <div class="carousel-track flex transition-transform duration-1000 ease-in-out" id="carouselTrack">
                    <?php foreach ($best_sellers as $p): ?>
                        <div class="carousel-slide flex-shrink-0 w-full md:w-1/3 px-6">
                            <div
                                class="card card-3d bg-white/95 backdrop-blur-xl rounded-3xl overflow-hidden shadow-xl h-full border border-amber-100 relative group">
                                <figure class="relative overflow-hidden">
                                    <img src="uploads/<?= htmlspecialchars($p['image'] ?? 'placeholder.jpg') ?>"
                                        class="w-full h-80 object-cover group-hover:scale-125 transition-transform duration-1000">
                                    <div
                                        class="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                                    </div>
                                    <div
                                        class="absolute top-6 right-6 badge badge-lg bg-amber-500/90 text-white border-0 font-bold text-lg px-5 py-3 shadow-lg shimmer">
                                        Popular</div>
                                </figure>
                                <div class="card-body text-center p-10">
                                    <h3
                                        class="text-3xl font-bold text-amber-700 mb-4 group-hover:text-amber-600 transition-colors duration-300">
                                        <?= htmlspecialchars($p['name']) ?>
                                    </h3>
                                    <p class="text-5xl font-black text-orange-600 mb-8 price-pop">
                                        ₱<?= number_format($p['price'], 2) ?>
                                    </p>
                                    <a href="view_product.php?id=<?= $p['id'] ?>"
                                        class="btn btn-ripple bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0 w-full rounded-full hover:from-amber-600 hover:to-orange-600 text-lg py-5 shadow-lg hover:shadow-2xl transform hover:scale-105 transition-all duration-500">
                                        <span class="relative z-10">View Details</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="flex justify-center gap-4 mt-12">
                    <?php for ($i = 0; $i < count($best_sellers) - 3; $i++): ?>
                        <button
                            class="dot w-3 h-3 rounded-full <?= $i === 0 ? 'bg-amber-600 w-12 shadow-lg' : 'bg-gray-300' ?> transition-all duration-500"></button>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- GALLERY with Enhanced Swiper -->
    <section id="gallery" class="py-32 bg-gradient-to-b from-amber-50 to-yellow-50 scroll-reveal">
        <div class="container mx-auto px-6 max-w-7xl">
            <div class="text-center mb-20" data-aos="fade-up">
                <h2 class="text-5xl sm:text-6xl md:text-7xl font-black text-amber-800 mb-6">Our Moments</h2>
                <p class="text-xl md:text-2xl text-amber-700 max-w-4xl mx-auto leading-relaxed">
                    Real smiles. Real drinks. Real love from Alaminos, Laguna.
                </p>
            </div>

            <div class="swiper gallery-swiper my-12" data-aos="zoom-in" data-aos-delay="200">
                <div class="swiper-wrapper">
                    <div class="swiper-slide rounded-2xl overflow-hidden shadow-2xl"><img
                            src="uploads/gallery/cheeze1.jpg" alt=""
                            class="w-full h-96 object-cover hover:scale-110 transition-transform duration-700"></div>
                    <div class="swiper-slide rounded-2xl overflow-hidden shadow-2xl"><img
                            src="uploads/gallery/cheeze2.jpg" alt=""
                            class="w-full h-96 object-cover hover:scale-110 transition-transform duration-700"></div>
                    <div class="swiper-slide rounded-2xl overflow-hidden shadow-2xl"><img
                            src="uploads/gallery/cheeze3.jpg" alt=""
                            class="w-full h-96 object-cover hover:scale-110 transition-transform duration-700"></div>
                    <div class="swiper-slide rounded-2xl overflow-hidden shadow-2xl"><img
                            src="uploads/gallery/cheeze4.jpg" alt=""
                            class="w-full h-96 object-cover hover:scale-110 transition-transform duration-700"></div>
                    <div class="swiper-slide rounded-2xl overflow-hidden shadow-2xl"><img
                            src="uploads/gallery/cheeze5.jpg" alt=""
                            class="w-full h-96 object-cover hover:scale-110 transition-transform duration-700"></div>
                    <div class="swiper-slide rounded-2xl overflow-hidden shadow-2xl"><img
                            src="uploads/gallery/cheeze6.jpg" alt=""
                            class="w-full h-96 object-cover hover:scale-110 transition-transform duration-700"></div>
                </div>
                <div class="swiper-button-next text-amber-700 hover:scale-125 transition-transform"></div>
                <div class="swiper-button-prev text-amber-700 hover:scale-125 transition-transform"></div>
                <div class="swiper-pagination"></div>
            </div>

            <div class="text-center mt-12" data-aos="fade-up" data-aos-delay="400">
                <a href="https://instagram.com" target="_blank"
                    class="inline-flex items-center gap-4 text-2xl font-bold text-amber-700 hover:text-amber-900 transition-all duration-300 group">
                    <i
                        class="fab fa-instagram text-5xl group-hover:scale-125 group-hover:rotate-12 transition-all duration-500"></i>
                    <span class="group-hover:translate-x-2 transition-transform duration-300">Follow @cheezetea.alaminos
                        for daily magic</span>
                </a>
            </div>
        </div>
    </section>

    <!-- FINAL CTA with Epic Animation -->
    <section
        class="py-32 bg-gradient-to-r from-amber-700 via-orange-600 to-amber-800 text-white text-center relative overflow-hidden scroll-reveal">
        <div class="absolute inset-0 bg-black/30"></div>

        <!-- Animated Background Elements -->
        <div class="absolute inset-0 opacity-20">
            <?php for ($i = 0; $i < 15; $i++): ?>
                <div class="absolute w-64 h-64 bg-white/10 rounded-full blur-3xl" style="
            top: <?= rand(-20, 120) ?>%;
            left: <?= rand(-20, 120) ?>%;
            animation: float-up <?= 20 + rand(0, 15) ?>s ease-in-out infinite;
            animation-delay: <?= $i * 0.5 ?>s;
        "></div>
            <?php endfor; ?>
        </div>

        <div class="relative z-10 container mx-auto px-6">
            <h2 class="text-6xl sm:text-7xl md:text-9xl font-black mb-10 text-white" data-aos="zoom-in"
                data-aos-duration="1000">
                Ready for Magic?
            </h2>
            <a href="products.php"
                class="btn btn-lg btn-ripple bg-white text-amber-700 hover:bg-yellow-100 text-3xl px-20 py-9 rounded-full shadow-2xl hover:shadow-3xl transform hover:scale-110 transition-all duration-500 inline-flex items-center gap-4 cta-pulse"
                data-aos="zoom-in" data-aos-delay="400">
                <span class="relative z-10">Order Your Dream Drink</span>
                <i class="fas fa-arrow-right text-2xl relative z-10"></i>
            </a>
        </div>
    </section>

    <?php require 'includes/footer.php'; ?>

    <script>
        // Initialize AOS with custom settings
        AOS.init({
            once: true,
            duration: 1200,
            easing: 'ease-out-cubic',
            offset: 100
        });

        // Scroll Reveal Observer
        const revealElements = document.querySelectorAll('.scroll-reveal');
        const revealObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('active');
                }
            });
        }, { threshold: 0.1 });

        revealElements.forEach(el => revealObserver.observe(el));

        // Parallax Effect on Hero
        document.addEventListener('mousemove', (e) => {
            const hero = document.querySelector('.parallax-section');
            if (!hero) return;

            const x = (e.clientX / window.innerWidth - 0.5) * 20;
            const y = (e.clientY / window.innerHeight - 0.5) * 20;

            hero.querySelector('.hero-gradient-text').style.transform = `translate(${x}px, ${y}px)`;
            hero.querySelector('.hero-subtitle').style.transform = `translate(${x * 0.5}px, ${y * 0.5}px)`;
        });

        // 3-Product Carousel with Enhanced Transitions
        const track = document.getElementById('carouselTrack');
        const dots = document.querySelectorAll('.dot');
        let currentIndex = 0;
        const totalRealSlides = <?= count($best_sellers) - 3 ?>;
        let autoPlay;

        function updateCarousel() {
            const offset = -currentIndex * (100 / 3);
            track.style.transform = `translateX(${offset}%)`;

            dots.forEach((dot, i) => {
                dot.classList.toggle('bg-amber-600', i === currentIndex);
                dot.classList.toggle('w-12', i === currentIndex);
                dot.classList.toggle('shadow-lg', i === currentIndex);
                dot.classList.toggle('bg-gray-300', i !== currentIndex);
                dot.classList.toggle('w-3', i !== currentIndex);
            });
        }

        function nextSlide() {
            currentIndex++;
            if (currentIndex >= totalRealSlides) {
                currentIndex = 0;
                track.style.transition = 'none';
                updateCarousel();
                void track.offsetWidth;
                track.style.transition = 'transform 1s cubic-bezier(0.23, 1, 0.32, 1)';
            }
            updateCarousel();
        }

        autoPlay = setInterval(nextSlide, 5000);

        track.parentElement.addEventListener('mouseenter', () => clearInterval(autoPlay));
        track.parentElement.addEventListener('mouseleave', () => autoPlay = setInterval(nextSlide, 5000));

        dots.forEach((dot, i) => dot.addEventListener('click', () => {
            currentIndex = i;
            updateCarousel();
            clearInterval(autoPlay);
            autoPlay = setInterval(nextSlide, 5000);
        }));

        // Enhanced Swiper Gallery
        const gallerySwiper = new Swiper('.gallery-swiper', {
            loop: true,
            grabCursor: true,
            centeredSlides: true,
            slidesPerView: 1.2,
            spaceBetween: 20,
            autoplay: {
                delay: 4000,
                disableOnInteraction: false
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev'
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
                dynamicBullets: true
            },
            breakpoints: {
                640: { slidesPerView: 2, spaceBetween: 30 },
                1024: { slidesPerView: 3, spaceBetween: 40 }
            },
            effect: 'coverflow',
            coverflowEffect: {
                rotate: 0,
                stretch: 0,
                depth: 200,
                modifier: 1.5,
                slideShadows: false
            },
            speed: 800
        });

        // Smooth Scroll with Offset
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Add loading animation
        window.addEventListener('load', () => {
            document.body.classList.add('loaded');
        });
    </script>

</body>

</html>