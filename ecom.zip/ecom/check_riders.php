<?php
require 'includes/db.php';

// Check all users
echo "<h2>All Users</h2>";
$stmt = $pdo->query("SELECT id, name, email, role FROM users ORDER BY id DESC");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($users as $user) {
    echo "ID: {$user['id']}, Name: {$user['name']}, Email: {$user['email']}, Role: {$user['role']}\n<br>";
}

echo "\n<h2>Riders Only (role = 'rider')</h2>";
$stmt = $pdo->query("SELECT id, name, email, role FROM users WHERE role = 'rider'");
$riders = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "Count: " . count($riders) . "<br>";
foreach ($riders as $rider) {
    echo "ID: {$rider['id']}, Name: {$rider['name']}, Email: {$rider['email']}, Role: {$rider['role']}\n<br>";
}

echo "\n<h2>Non-Admin, Non-Rider Users</h2>";
$stmt = $pdo->query("SELECT id, name, email, role FROM users WHERE role NOT IN ('admin', 'rider') AND role IS NOT NULL");
$available = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "Count: " . count($available) . "<br>";
foreach ($available as $user) {
    echo "ID: {$user['id']}, Name: {$user['name']}, Email: {$user['email']}, Role: {$user['role']}\n<br>";
}
