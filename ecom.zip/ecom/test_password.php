<?php
// Test password hashing
$hash = '$2y$10$W6N9j8i7k5v3x1Z9q0r5t.8e7v6c5x4z3a2s1d0f9g8h7j6k5l4m3n2o';

echo "Testing password hashes:\n";
echo "Hash in DB: " . $hash . "\n\n";

// Test various passwords
$test_passwords = ['admin', 'password', '123456', 'test'];

foreach ($test_passwords as $pwd) {
    $result = password_verify($pwd, $hash);
    echo "password_verify('$pwd', hash) = " . ($result ? 'TRUE' : 'FALSE') . "\n";
}

// Also test if we can create a hash for 'admin'
echo "\n\nCreating new hash for 'admin':\n";
$new_hash = password_hash('admin', PASSWORD_BCRYPT);
echo "New hash: " . $new_hash . "\n";
echo "Verify new hash with 'admin': " . (password_verify('admin', $new_hash) ? 'TRUE' : 'FALSE') . "\n";
?>
