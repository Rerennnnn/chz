<?php // includes/navbar.php ?>
<nav class="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-md shadow-lg z-50 transition-all duration-300" id="navbar">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center h-20">

            <!-- Logo -->
            <div class="flex-shrink-0 flex items-center gap-3">
                <img src="uploads/chztea.png" alt="CheezeTea Logo" class="h-12 w-12 md:h-14 md:w-14 object-contain">
                <a href="index.php" class="playfair text-3xl md:text-4xl font-bold text-yellow-dark">
                    Cheeze<span class="text-amber-600">Tea</span>
                </a>
            </div>

            <!-- Desktop Menu -->
            <div class="hidden md:flex items-center space-x-10">
                <a href="index.php" class="nav-link font-medium hover:text-yellow-dark transition">Home</a>
                <a href="products.php" class="nav-link font-medium hover:text-yellow-dark transition">Products</a>
                <a href="about.php" class="nav-link font-medium hover:text-yellow-dark transition">About</a>
                <a href="contact.php" class="nav-link font-medium hover:text-yellow-dark transition">Contact</a>

                <!-- CART -->
                <a href="cart.php" class="relative hover:text-yellow-dark transition">
                    <i class="fas fa-shopping-bag text-xl"></i>
                    <?php if(isset($_SESSION['cart']) && array_sum($_SESSION['cart'] ?? []) > 0): ?>
                        <span class="absolute -top-2 -right-3 bg-amber-500 text-gray-900 text-xs font-bold rounded-full h-6 w-6 flex items-center justify-center animate-pulse">
                            <?php echo array_sum($_SESSION['cart']); ?>
                        </span>
                    <?php endif; ?>
                </a>

                <!-- USER AUTH -->
                <?php if(isset($_SESSION['user_id'])): ?>
                    <div class="flex items-center gap-6">

                        <!-- SHOW RIDER PANEL IF ROLE IS RIDER OR ADMIN -->
                        <?php if(isset($_SESSION['role']) && in_array($_SESSION['role'], ['rider', 'admin'])): ?>
                            <a href="rider_panel.php" class="text-amber-600 hover:underline font-semibold text-sm">
                                <i class="fas fa-motorcycle mr-1"></i> Rider Panel
                            </a>
                        <?php endif; ?>

                        <!-- ADMIN PANEL -->
                        <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                            <a href="admin/dashboard.php" class="text-yellow-dark hover:underline text-sm font-medium">
                                Admin Panel
                            </a>
                        <?php endif; ?>

                        <!-- GREETING + LOGOUT -->
                        <span class="text-sm text-gray-600">Hi, <?php echo htmlspecialchars($_SESSION['name'] ?? 'User'); ?></span>
                        <a href="logout.php" class="text-red-600 hover:underline text-sm">Logout</a>
                    </div>

                <?php else: ?>
                    <a href="login.php" class="bg-yellow-dark text-gray-900 px-6 py-3 rounded-full font-medium hover:bg-yellow-warm transition shadow-md font-semibold">
                        Login
                    </a>
                <?php endif; ?>

            </div>

            <!-- Mobile Menu Button -->
            <div class="md:hidden">
                <button id="mobile-menu-btn" class="text-yellow-dark focus:outline-none">
                    <i class="fas fa-bars text-2xl"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Mobile Menu -->
    <div id="mobile-menu" class="hidden md:hidden bg-white shadow-lg">
        <div class="px-4 pt-4 pb-6 space-y-4">
            <a href="index.php" class="block nav-link-mobile">Home</a>
            <a href="products.php" class="block nav-link-mobile">Products</a>
            <a href="about.php" class="block nav-link-mobile">About</a>
            <a href="contact.php" class="block nav-link-mobile">Contact</a>

            <a href="cart.php" class="block nav-link-mobile flex items-center gap-2">
                <i class="fas fa-shopping-bag"></i> Cart 
                <?php if(isset($_SESSION['cart']) && array_sum($_SESSION['cart']) > 0): ?>
                    <span class="text-amber-600 font-bold">(<?php echo array_sum($_SESSION['cart']); ?>)</span>
                <?php endif; ?>
            </a>

            <!-- MOBILE RIDER PANEL -->
            <?php if(isset($_SESSION['role']) && in_array($_SESSION['role'], ['rider', 'admin'])): ?>
                <a href="rider_panel.php" class="block nav-link-mobile text-amber-600 font-semibold">
                    <i class="fas fa-motorcycle mr-1"></i> Rider Panel
                </a>
            <?php endif; ?>

            <!-- MOBILE ADMIN PANEL -->
            <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                <a href="admin/dashboard.php" class="block nav-link-mobile text-yellow-dark font-semibold">
                    Admin Panel
                </a>
            <?php endif; ?>

            <?php if(!isset($_SESSION['user_id'])): ?>
                <a href="login.php" class="block bg-yellow-dark text-gray-900 text-center py-3 rounded-full font-semibold">Login</a>
            <?php else: ?>
                <a href="logout.php" class="block text-red-600 text-center">Logout</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- Offset for fixed navbar -->
<div class="h-20"></div>

<script>
    document.getElementById('mobile-menu-btn').addEventListener('click', function() {
        document.getElementById('mobile-menu').classList.toggle('hidden');
    });

    document.querySelectorAll('.nav-link, .nav-link-mobile').forEach(link => {
        if (link.href === window.location.href) {
            link.classList.add('text-yellow-dark', 'font-bold');
        }
    });
</script>
