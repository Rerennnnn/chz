<?php
// includes/config.php
define('GOOGLE_CLIENT_ID', '990692747876-lnspvoi9p4bkbpmq6o5u3d14hfinra4m.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', 'http://localhost/ecom/oauth/google_callback.php');

// Facebook OAuth Configuration
define('FB_APP_ID', 'YOUR_FB_APP_ID_HERE');
define('FB_APP_SECRET', 'YOUR_FB_APP_SECRET_HERE');
define('FB_REDIRECT_URI', 'http://localhost/ecom/oauth/facebook_callback.php');

// PayMongo Configuration
define('PAYMONGO_SECRET_KEY', 'sk_test_dfZGRR1A9SPwLtHH8woPgKfJ');
define('PAYMONGO_PUBLIC_KEY', 'pk_test_TKayvH5kFVb6mM3DGw3YH2Vy');
define('PAYMONGO_API_URL', 'https://api.paymongo.com/v1');
?>