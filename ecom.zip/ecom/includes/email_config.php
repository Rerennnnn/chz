<?php
// Local email password helper for development. Remove or secure for production.
return 'kein njua uqrq fpib';
