<?php
// includes/header.php
require_once __DIR__ . '/auth.php'; // Session + login check

$page_title = $page_title ?? 'Cheeze Tea Alaminos';
$description = $description ?? 'Premium cheese foam milk tea made with love in Alaminos, Laguna. Creamy. Dreamy. Unforgettable.';
$og_image = $og_image ?? 'assets/images/og-preview.jpg'; // Create this 1200x630 image later
?>

<!DOCTYPE html>
<html lang="en" class="scroll-smooth">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="<?= htmlspecialchars($description) ?>" />
    <meta name="author" content="Cheeze Tea Alaminos" />
    <meta name="theme-color" content="#fbbf24" />

    <!-- Open Graph / Social Sharing -->
    <meta property="og:title" content="<?= htmlspecialchars($page_title) ?>" />
    <meta property="og:description" content="<?= htmlspecialchars($description) ?>" />
    <meta property="og:image" content="<?= htmlspecialchars($og_image) ?>" />
    <meta property="og:url" content="<?= "https://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}" ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="Cheeze Tea Alaminos" />

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="<?= htmlspecialchars($page_title) ?>" />
    <meta name="twitter:description" content="<?= htmlspecialchars($description) ?>" />
    <meta name="twitter:image" content="<?= htmlspecialchars($og_image) ?>" />

    <!-- Title & Favicon -->
    <title><?= htmlspecialchars($page_title) ?> • Cheeze Tea Alaminos</title>
    <link rel="icon" href="assets/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="assets/apple-touch-icon.png" />

    <!-- Google Fonts: Playfair Display (headings) + Poppins (body) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@300;400;500;600;700;900&display=swap"
        rel="stylesheet">

    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Tailwind CSS via CDN (fastest for dev) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        display: ['"Playfair Display"', 'serif'],
                        sans: ['Poppins', 'sans-serif'],
                    },
                    colors: {
                        cream: '#fffaf0',
                        'yellow-warm': '#fbbf24',
                        'yellow-dark': '#f59e0b',
                        'brown-cheese': '#92400e',
                    }
                }
            }
        }
    </script>

    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Global Styles (your main CSS) -->
    <link rel="stylesheet" href="assets/css/global.css?v=<?= time() ?>" />

    <!-- Page-Specific CSS (optional) -->
    <?php if (!empty($page_css)): ?>
        <link rel="stylesheet" href="<?= htmlspecialchars($page_css) ?>?v=<?= time() ?>" />
    <?php endif; ?>

    <!-- Inline Critical CSS (for instant render) -->
    <style>
        :root {
            --cream: #fffaf0;
            --yellow-warm: #fbbf24;
            --yellow-dark: #f59e0b;
            --brown-cheese: #92400e;
        }

        body {
            background: var(--cream);
            font-family: 'Poppins', sans-serif;
            color: #1f2937;
            min-height: 100dvh;
        }

        .playfair {
            font-family: 'Playfair Display', serif;
        }

        .bg-cheese {
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
        }

        .text-cheese {
            color: #92400e;
        }

        .btn-cheese {
            @apply bg-yellow-warm text-brown-cheese font-bold rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300;
        }
    </style>

    <!-- Preloader (Optional – looks super premium) -->
    <script>
        window.addEventListener('load', () => {
            document.body.classList.add('loaded');
        });
    </script>
</head>

<body class="bg-cream text-gray-800 relative">
    <!-- Preloader -->
    <div id="preloader"
        class="fixed inset-0 bg-cream flex items-center justify-center z-50 transition-opacity duration-700">
        <div class="text-center">
            <img src="assets/images/logo.png" alt="Cheeze Tea" class="w-32 h-32 mx-auto mb-4 animate-pulse"
                onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTI4IiBoZWlnaHQ9IjEyOCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSI2NCIgY3k9IjY0IiByPSI1MCIgc3Ryb2tlPSIjZmJiZjI0IiBzdHJva2Utd2lkdGg9IjE4IiBmaWxsPSJub25lIi8+PHBhdGggZD0iTTMyIDY0aDY0IiBzdHJva2U9IiNmNTllMGIiIHN0cm9rZS13aWR0aD0iMTQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjwvc3ZnPg=='">
            <p class="text-2xl font-bold text-yellow-warm playfair">Cheeze Tea</p>
        </div>
    </div>

    <!-- Smooth fade-out when loaded -->
    <style>
        #preloader {
            transition: opacity 0.8s ease;
        }

        body.loaded #preloader {
            opacity: 0;
            pointer-events: none;
        }
    </style>