<?php
require 'includes/db.php';

// Check rider_earnings table
$result = $pdo->query("SHOW COLUMNS FROM rider_earnings");
$columns = $result->fetchAll(PDO::FETCH_ASSOC);

echo "rider_earnings table columns:\n";
foreach ($columns as $col) {
    echo "- " . $col['Field'] . " (" . $col['Type'] . ")\n";
}
?>