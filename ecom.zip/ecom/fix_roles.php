<?php
require 'includes/auth.php';
require 'includes/db.php';

// Fix NULL roles
$pdo->exec("UPDATE users SET role = 'customer' WHERE role IS NULL");
echo "Fixed NULL roles to 'customer'";

// Verify
$stmt = $pdo->query("SELECT id, name, email, role FROM users");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "<pre>";
print_r($users);
echo "</pre>";
?>