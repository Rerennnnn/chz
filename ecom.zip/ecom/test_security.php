<?php
/**
 * Security Test Script - Verify CSRF, XSS, SQL Injection protections
 * 
 * Run this script to test security measures:
 * php test_security.php
 */

require 'includes/db.php';

echo "\n" . str_repeat("=", 70) . "\n";
echo "SECURITY HARDENING TEST SUITE\n";
echo str_repeat("=", 70) . "\n\n";

// Test 1: CSRF Token Generation
echo "[TEST 1] CSRF Token Generation\n";
$token = generateCsrfToken();
if ($token && strlen($token) === 64) {
    echo "✓ PASS - CSRF token generated (length: " . strlen($token) . ")\n";
} else {
    echo "✗ FAIL - CSRF token not properly generated\n";
}

// Test 2: Output Escaping
echo "\n[TEST 2] Output Escaping Functions\n";
$dangerous = '<script>alert("XSS")</script>';
$escaped = e($dangerous);
if (strpos($escaped, '<script>') === false && strpos($escaped, '&lt;') !== false) {
    echo "✓ PASS - HTML escaping works\n";
} else {
    echo "✗ FAIL - HTML escaping failed\n";
}

// Test 3: Email Validation
echo "\n[TEST 3] Email Validation\n";
$validEmail = 'user@example.com';
$invalidEmail = 'not-an-email';
if (validateEmail($validEmail) && !validateEmail($invalidEmail)) {
    echo "✓ PASS - Email validation works\n";
} else {
    echo "✗ FAIL - Email validation failed\n";
}

// Test 4: Text Sanitization
echo "\n[TEST 4] Text Sanitization\n";
$dirtyText = '<script>bad</script>Good Text<img src=x>';
$clean = sanitizeText($dirtyText);
if (strpos($clean, '<') === false && strpos($clean, '>') === false && strpos($clean, 'Good') !== false) {
    echo "✓ PASS - Text sanitization works\n";
} else {
    echo "✗ FAIL - Text sanitization failed\n";
}

// Test 5: Integer Validation
echo "\n[TEST 5] Integer Validation\n";
if (validateId(42) === 42 && validateId(0) === false && validateId(-1) === false) {
    echo "✓ PASS - ID validation works\n";
} else {
    echo "✗ FAIL - ID validation failed\n";
}

// Test 6: Phone Validation
echo "\n[TEST 6] Phone Validation\n";
$validPhone = '09123456789';
$invalidPhone = 'not-a-phone';
if (validatePhone($validPhone) && !validatePhone($invalidPhone)) {
    echo "✓ PASS - Phone validation works\n";
} else {
    echo "✗ FAIL - Phone validation failed\n";
}

// Test 7: SQL Injection Prevention
echo "\n[TEST 7] Prepared Statements (SQL Injection Prevention)\n";
try {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
    $stmt->execute(['test@example.com']);
    echo "✓ PASS - Prepared statements are enforced\n";
} catch (Exception $e) {
    echo "✗ FAIL - Prepared statement error: " . $e->getMessage() . "\n";
}

// Test 8: Rate Limiting
echo "\n[TEST 8] Rate Limiting\n";
$actionKey = 'test_action_' . time();
$allowed = 0;
for ($i = 0; $i < 6; $i++) {
    if (checkRateLimit($actionKey, 5, 300)) {
        $allowed++;
    }
}
if ($allowed === 5) {
    echo "✓ PASS - Rate limiting works (allowed 5 attempts, blocked 6th)\n";
} else {
    echo "✗ FAIL - Rate limiting failed (got $allowed attempts)\n";
}

// Reset the rate limit for clean state
resetRateLimit($actionKey);

echo "\n" . str_repeat("=", 70) . "\n";
echo "SECURITY TEST COMPLETE\n";
echo str_repeat("=", 70) . "\n\n";

// Additional Notes
echo "RECOMMENDATIONS:\n";
echo "1. Always use validateEmail(), sanitizeText(), etc. for user inputs\n";
echo "2. Use e() for HTML output, eattr() for HTML attributes\n";
echo "3. Add CSRF tokens to all POST/PUT/DELETE forms\n";
echo "4. Use verifyCsrfToken() to validate requests\n";
echo "5. Check the SECURITY_IMPROVEMENTS.md file for implementation details\n\n";
