<?php
require 'includes/db.php';

// Check riders
$stmt = $pdo->query("SELECT id, name, email, role FROM users WHERE role = 'rider'");
$riders = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "Riders in DB:\n";
echo json_encode($riders, JSON_PRETTY_PRINT);
echo "\n\n";

// Check all users
$stmt = $pdo->query("SELECT id, name, email, role FROM users LIMIT 20");
$all_users = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "All Users (first 20):\n";
echo json_encode($all_users, JSON_PRETTY_PRINT);
?>