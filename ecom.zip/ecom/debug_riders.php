<?php
// Quick test
require 'includes/db.php';

echo "<h1>Database Debug</h1>";

// Test 1: Check all users
echo "<h2>All Users in Database</h2>";
$stmt = $pdo->query("SELECT id, name, email, role FROM users LIMIT 20");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "<pre>";
print_r($users);
echo "</pre>";

// Test 2: Check riders specifically
echo "<h2>Users with role='rider'</h2>";
$stmt = $pdo->query("SELECT id, name, email, role FROM users WHERE role = 'rider'");
$riders = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "<p>Count: " . count($riders) . "</p>";
echo "<pre>";
print_r($riders);
echo "</pre>";

// Test 3: Check non-riders
echo "<h2>Users with role NOT IN ('admin', 'rider')</h2>";
$stmt = $pdo->query("SELECT id, name, email, role FROM users WHERE role NOT IN ('admin', 'rider')");
$non_riders = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "<p>Count: " . count($non_riders) . "</p>";
echo "<pre>";
print_r($non_riders);
echo "</pre>";
?>