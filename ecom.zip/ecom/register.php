<?php
// register.php - Registration page (restored to clean, working version)
$page_title = "Register - Cheeze Tea";
require 'includes/db.php';
require 'includes/header.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$error = '';
$success = '';

if (isRequestMethod('POST')) {
    // Basic validation and registration (simple and safe)
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($name === '') {
        $error = 'Please enter your full name.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        // Check existing email
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'Email already registered. Please login instead.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$name, $email, $hash, 'customer'])) {
                $success = 'Registration successful. You may now login.';
            } else {
                $error = 'Registration failed. Please try again later.';
            }
        }
    }
}
?>

<div class="min-h-screen flex items-center justify-center px-6 py-12">
    <div class="w-full max-w-md">

        <div class="text-center mb-8">
            <h1 class="playfair text-6xl font-bold text-yellow-600">Cheeze Tea</h1>
            <p class="text-lg text-gray-600 mt-2">Create your account</p>
        </div>

        <div class="bg-white rounded-xl shadow-lg p-8 border border-yellow-100">

            <?php if ($error): ?>
                <div
                    class="bg-red-100 border border-red-300 text-red-700 px-6 py-4 rounded-xl mb-6 text-center font-medium">
                    <i class="fas fa-exclamation-circle mr-2"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div
                    class="bg-green-100 border border-green-300 text-green-700 px-6 py-4 rounded-xl mb-6 text-center font-medium">
                    <i class="fas fa-check-circle mr-2"></i>
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <!-- Registration Form -->
            <form method="POST" class="space-y-4">
                <!-- Full Name -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Full Name</label>
                    <input type="text" name="name" required placeholder="Juan Dela Cruz"
                        value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>"
                        class="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-yellow-400 focus:outline-none text-base">
                </div>

                <!-- Email -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Email Address</label>
                    <input type="email" name="email" required placeholder="you@example.com"
                        value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                        class="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-yellow-400 focus:outline-none text-base">
                </div>

                <!-- Password -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Password</label>
                    <input type="password" name="password" required placeholder="At least 6 characters"
                        class="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-yellow-400 focus:outline-none text-base">
                </div>

                <!-- Confirm Password -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Confirm Password</label>
                    <input type="password" name="confirm_password" required placeholder="Repeat password"
                        class="w-full px-4 py-3 rounded-lg border border-gray-200 focus:border-yellow-400 focus:outline-none text-base">
                </div>

                <!-- Register Button -->
                <button type="submit"
                    class="w-full bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-3 rounded-lg">
                    Create Account
                </button>
            </form>

            <div class="text-center mt-6">
                <p class="text-gray-600">Already have an account? <a href="login.php"
                        class="text-yellow-600 font-semibold">Login</a></p>
            </div>

        </div>

        <p class="text-center mt-6 text-gray-500 text-sm">© 2025 Cheeze Tea Alaminos</p>

    </div>
</div>

<?php require 'includes/footer.php'; ?>