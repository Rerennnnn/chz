<?php
require 'includes/db.php';

// Test: Get all non-rider users
echo "<h2>Available Users (to assign as riders)</h2>";
$stmt = $pdo->query("SELECT id, name, email, role FROM users WHERE role NOT IN ('admin', 'rider') AND role IS NOT NULL ORDER BY name ASC");
$available = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "Count: " . count($available) . "<br><br>";

if (empty($available)) {
    echo "<strong style='color: red;'>No available users! Everyone is either admin or already rider.</strong><br>";
    echo "Let me check all users:<br>";
    $stmt = $pdo->query("SELECT id, name, email, role FROM users ORDER BY id DESC LIMIT 10");
    foreach ($stmt->fetchAll() as $u) {
        echo "ID: {$u['id']}, Name: {$u['name']}, Email: {$u['email']}, Role: {$u['role']}<br>";
    }
} else {
    foreach ($available as $user) {
        echo "ID: {$user['id']}, Name: {$user['name']}, Email: {$user['email']}, Role: {$user['role']}<br>";
    }

    echo "<br><h2>Testing Assignment</h2>";
    echo "If you want to test assignment, the first available user is ID {$available[0]['id']} - {$available[0]['name']}<br>";
}

echo "<br><h2>Current Riders</h2>";
$stmt = $pdo->query("SELECT id, name, email, role FROM users WHERE role = 'rider'");
$riders = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "Count: " . count($riders) . "<br>";
if (!empty($riders)) {
    foreach ($riders as $rider) {
        echo "ID: {$rider['id']}, Name: {$rider['name']}, Email: {$rider['email']}, Role: {$rider['role']}<br>";
    }
}
