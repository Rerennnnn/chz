<?php
session_start();
require '../includes/config.php';
require '../vendor/autoload.php';

use Facebook\Facebook;

$fb = new Facebook([
    'app_id' => FB_APP_ID,
    'app_secret' => FB_APP_SECRET,
    'default_graph_version' => 'v18.0',
]);

$helper = $fb->getRedirectLoginHelper();

// Permissions you need
$permissions = ['email', 'public_profile'];

// Generate login URL
$loginUrl = $helper->getLoginUrl(FB_REDIRECT_URI, $permissions);

// Redirect user to Facebook login
header('Location: ' . $loginUrl);
exit();
