<?php
require 'includes/email.php';

$to = 'cheezeeteaa@gmail.com';
$subject = 'Test Email from Cheeze Tea';
$body = '<p>This is a test email sent at ' . date('Y-m-d H:i:s') . ' to verify SMTP settings.</p>';

echo "Sending test email to $to...\n";
$ok = sendEmail($to, $subject, $body);
if ($ok) {
    echo "Email sent successfully.\n";
} else {
    echo "Email failed to send. Check paymongo/logs/email_errors.log and server logs.\n";
}
