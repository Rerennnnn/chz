<?php
require 'includes/db.php';

echo "<h1>User Management Diagnostic</h1>";

// Show all users
echo "<h2>All Users in Database:</h2>";
$stmt = $pdo->query("SELECT id, name, email, role, created_at FROM users ORDER BY id DESC");
$allUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($allUsers)) {
    echo "<p style='color:red;'><strong>No users found in database!</strong></p>";
} else {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Created</th></tr>";
    foreach ($allUsers as $user) {
        $roleColor = '';
        if ($user['role'] === 'admin')
            $roleColor = 'background-color: #ffcccc;';
        elseif ($user['role'] === 'rider')
            $roleColor = 'background-color: #ccffcc;';
        else
            $roleColor = 'background-color: #ccccff;';

        echo "<tr>";
        echo "<td>{$user['id']}</td>";
        echo "<td>{$user['name']}</td>";
        echo "<td>{$user['email']}</td>";
        echo "<td style='{$roleColor}'><strong>{$user['role']}</strong></td>";
        echo "<td>" . ($user['created_at'] ? date('M d, Y H:i', strtotime($user['created_at'])) : 'N/A') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

echo "<hr>";

// Count by role
echo "<h2>User Count by Role:</h2>";
$stmt = $pdo->query("SELECT role, COUNT(*) as count FROM users GROUP BY role");
$roleCounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($roleCounts as $rc) {
    echo "{$rc['role']}: {$rc['count']}<br>";
}

echo "<hr>";

// Show available users
echo "<h2>Available to Assign as Riders:</h2>";
$stmt = $pdo->query("SELECT id, name, email, role FROM users WHERE role NOT IN ('admin', 'rider') AND role IS NOT NULL ORDER BY name ASC");
$available = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "Count: " . count($available) . "<br>";

if (!empty($available)) {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Action</th></tr>";
    foreach ($available as $user) {
        echo "<tr>";
        echo "<td>{$user['id']}</td>";
        echo "<td>{$user['name']}</td>";
        echo "<td>{$user['email']}</td>";
        echo "<td style='background-color: #ccccff;'>{$user['role']}</td>";
        echo "<td>";
        echo "<form method='POST' style='display: inline;' onsubmit=\"return confirm('Assign {$user['name']} as rider?');\">";
        echo "<input type='hidden' name='assign_user_id' value='{$user['id']}'>";
        echo "<button type='submit'>Assign as Rider</button>";
        echo "</form>";
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: orange;'><strong>⚠️ No users available to assign!</strong></p>";
    echo "<p>This means all non-admin users are already riders.</p>";
}

// Handle assignment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_user_id'])) {
    $user_id = (int) $_POST['assign_user_id'];
    try {
        $stmt = $pdo->prepare("UPDATE users SET role = 'rider' WHERE id = ?");
        $stmt->execute([$user_id]);
        if ($stmt->rowCount() > 0) {
            echo "<h3 style='color: green;'>✓ User assigned as rider successfully!</h3>";
            echo "<meta http-equiv='refresh' content='2'>";
        } else {
            echo "<h3 style='color: red;'>✗ Failed to update user</h3>";
        }
    } catch (PDOException $e) {
        echo "<h3 style='color: red;'>✗ Database error: {$e->getMessage()}</h3>";
    }
}

// Show current riders
echo "<hr>";
echo "<h2>Current Riders:</h2>";
$stmt = $pdo->query("SELECT id, name, email FROM users WHERE role = 'rider' ORDER BY name ASC");
$riders = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "Count: " . count($riders) . "<br>";

if (!empty($riders)) {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>ID</th><th>Name</th><th>Email</th></tr>";
    foreach ($riders as $rider) {
        echo "<tr style='background-color: #ccffcc;'>";
        echo "<td>{$rider['id']}</td>";
        echo "<td>{$rider['name']}</td>";
        echo "<td>{$rider['email']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: orange;'><strong>⚠️ No riders yet</strong></p>";
}
?>