<?php
require 'includes/header.php';
require 'includes/navbar.php';
require 'includes/db.php';

if (!isset($_GET['id']))
    header('Location: products.php');
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$_GET['id']]);
$product = $stmt->fetch();

if (!$product)
    header('Location: products.php');
$page_title = $product['name'];

// Check if product is a drink (has size options)
$drink_categories = ['milktea', 'milkshake', 'fruittea', 'sparkling', 'coffee'];
$is_drink = in_array($product['category'], $drink_categories);

// Category styling
$category_styles = [
    'milktea' => ['gradient' => 'from-amber-500 to-orange-500', 'emoji' => '🧋', 'bg' => 'from-amber-50 to-orange-50'],
    'milkshake' => ['gradient' => 'from-pink-500 to-rose-500', 'emoji' => '🥤', 'bg' => 'from-pink-50 to-rose-50'],
    'fruittea' => ['gradient' => 'from-green-500 to-emerald-500', 'emoji' => '🍹', 'bg' => 'from-green-50 to-emerald-50'],
    'sparkling' => ['gradient' => 'from-blue-500 to-cyan-500', 'emoji' => '✨', 'bg' => 'from-blue-50 to-cyan-50'],
    'coffee' => ['gradient' => 'from-amber-600 to-yellow-700', 'emoji' => '☕', 'bg' => 'from-amber-50 to-yellow-50'],
    'food' => ['gradient' => 'from-purple-500 to-indigo-500', 'emoji' => '🍰', 'bg' => 'from-purple-50 to-indigo-50']
];

$style = $category_styles[$product['category']] ?? $category_styles['milktea'];
?>

<style>
    /* Animated Background */
    @keyframes float-slow {

        0%,
        100% {
            transform: translateY(0) translateX(0);
        }

        25% {
            transform: translateY(-20px) translateX(10px);
        }

        50% {
            transform: translateY(-40px) translateX(-10px);
        }

        75% {
            transform: translateY(-20px) translateX(5px);
        }
    }

    @keyframes gradient-shift {

        0%,
        100% {
            background-position: 0% 50%;
        }

        50% {
            background-position: 100% 50%;
        }
    }

    /* Image Hover Effect */
    .product-image-wrapper {
        position: relative;
        overflow: hidden;
        transition: transform 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
    }

    .product-image-wrapper:hover {
        transform: scale(1.05) rotate(2deg);
    }

    .product-image-wrapper img {
        transition: transform 0.8s ease;
    }

    .product-image-wrapper:hover img {
        transform: scale(1.15);
    }

    /* Badge Animations */
    @keyframes pulse-glow {

        0%,
        100% {
            box-shadow: 0 0 20px rgba(245, 158, 11, 0.5);
        }

        50% {
            box-shadow: 0 0 40px rgba(245, 158, 11, 0.8);
        }
    }

    .badge-glow {
        animation: pulse-glow 2s infinite;
    }

    /* Size Button Animation */
    .size-option {
        transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        position: relative;
        overflow: hidden;
    }

    .size-option::before {
        content: '';
        position: absolute;
        inset: 0;
        background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.3), transparent);
        transform: translateX(-100%);
        transition: transform 0.6s;
    }

    .size-option:hover::before {
        transform: translateX(100%);
    }

    .size-option:hover {
        transform: translateY(-3px) scale(1.05);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    }

    .size-option.active {
        transform: scale(1.1);
        box-shadow: 0 15px 40px rgba(245, 158, 11, 0.4);
    }

    /* Add to Cart Button */
    .btn-add-cart {
        position: relative;
        overflow: hidden;
        transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
    }

    .btn-add-cart::before {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 0;
        height: 0;
        background: rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        transform: translate(-50%, -50%);
        transition: width 0.6s, height 0.6s;
    }

    .btn-add-cart:hover::before {
        width: 500px;
        height: 500px;
    }

    .btn-add-cart:hover {
        transform: translateY(-3px) scale(1.02);
        box-shadow: 0 20px 50px rgba(245, 158, 11, 0.5);
    }

    .btn-add-cart:active {
        transform: translateY(0) scale(0.98);
    }

    /* Price Animation */
    @keyframes price-pop {
        0% {
            transform: scale(1);
        }

        50% {
            transform: scale(1.1);
        }

        100% {
            transform: scale(1);
        }
    }

    .price-change {
        animation: price-pop 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
    }

    /* Emoji Float */
    @keyframes emoji-float {

        0%,
        100% {
            transform: translateY(0) rotate(0deg);
        }

        50% {
            transform: translateY(-10px) rotate(5deg);
        }
    }

    .emoji-float {
        animation: emoji-float 3s ease-in-out infinite;
        display: inline-block;
    }

    /* Info Card Hover */
    .info-card {
        transition: all 0.3s ease;
    }

    .info-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
    }

    /* Breadcrumb Trail */
    .breadcrumb-link {
        transition: all 0.3s ease;
    }

    .breadcrumb-link:hover {
        transform: translateX(5px);
        color: #f59e0b;
    }

    /* Stock Badge Pulse */
    @keyframes stock-pulse {

        0%,
        100% {
            transform: scale(1);
        }

        50% {
            transform: scale(1.05);
        }
    }

    .stock-badge {
        animation: stock-pulse 2s infinite;
    }
</style>

<!-- Animated Background -->
<div class="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
    <div class="absolute inset-0 bg-gradient-to-br <?= $style['bg'] ?>"></div>

    <?php for ($i = 1; $i <= 20; $i++):
        $s = rand(40, 100);
        $d = 20 + rand(0, 15);
        $del = $i * 0.8;
        $l = rand(-5, 105);
        $t = rand(-5, 105);
        ?>
        <div style="position:absolute; left:<?= $l ?>%; top:<?= $t ?>%; animation-delay:<?= $del ?>s;">
            <div class="rounded-full bg-gradient-to-br from-amber-200/20 to-orange-200/20 backdrop-blur-sm"
                style="width:<?= $s ?>px; height:<?= $s ?>px; animation: float-slow <?= $d ?>s ease-in-out infinite;">
            </div>
        </div>
    <?php endfor; ?>
</div>

<!-- Breadcrumb Navigation -->
<div class="max-w-6xl mx-auto px-6 pt-8">
    <div class="flex items-center gap-3 text-sm font-semibold" data-aos="fade-down">
        <a href="index.php" class="breadcrumb-link text-gray-600 hover:text-amber-600 transition-all">
            🏠 Home
        </a>
        <span class="text-gray-400">→</span>
        <a href="products.php" class="breadcrumb-link text-gray-600 hover:text-amber-600 transition-all">
            🛍️ Products
        </a>
        <span class="text-gray-400">→</span>
        <span class="text-amber-700"><?= htmlspecialchars($product['name']) ?></span>
    </div>
</div>

<!-- Main Product Section -->
<div class="max-w-6xl mx-auto px-6 py-12">
    <div class="bg-white rounded-3xl shadow-2xl overflow-hidden" data-aos="fade-up">

        <div class="grid md:grid-cols-2 gap-0">

            <!-- Left: Product Image -->
            <div class="relative bg-gradient-to-br <?= $style['bg'] ?> p-12 flex items-center justify-center">

                <!-- Decorative Elements -->
                <div class="absolute top-10 left-10 text-8xl opacity-10 emoji-float">
                    <?= $style['emoji'] ?>
                </div>
                <div class="absolute bottom-10 right-10 text-8xl opacity-10 emoji-float" style="animation-delay: 1s;">
                    <?= $style['emoji'] ?>
                </div>

                <!-- Product Image -->
                <div class="product-image-wrapper relative z-10 rounded-3xl overflow-hidden shadow-2xl"
                    data-aos="zoom-in">
                    <img src="uploads/<?= htmlspecialchars($product['image']) ?>" class="w-full h-auto"
                        alt="<?= htmlspecialchars($product['name']) ?>">

                    <!-- Overlay Badge -->
                    <div class="absolute top-6 right-6">
                        <div class="bg-white px-4 py-2 rounded-full shadow-xl badge-glow">
                            <span class="text-2xl"><?= $style['emoji'] ?></span>
                        </div>
                    </div>
                </div>

                <!-- Category Badge -->
                <div
                    class="absolute bottom-6 left-6 bg-white px-6 py-3 rounded-full shadow-xl font-bold text-gray-800 capitalize">
                    <span class="mr-2"><?= $style['emoji'] ?></span>
                    <?= htmlspecialchars($product['category']) ?>
                </div>
            </div>

            <!-- Right: Product Details -->
            <div class="p-12 flex flex-col justify-center bg-gradient-to-br from-white to-amber-50/30">

                <!-- Product Title -->
                <div class="mb-6" data-aos="fade-left">
                    <h1 class="text-5xl md:text-6xl font-black text-gray-900 mb-4 leading-tight">
                        <?= htmlspecialchars($product['name']) ?>
                    </h1>

                    <!-- Rating & Stock -->
                    <div class="flex items-center gap-4 mb-4">
                        <div class="flex items-center gap-1">
                            <span class="text-2xl">⭐</span>
                            <span class="text-2xl">⭐</span>
                            <span class="text-2xl">⭐</span>
                            <span class="text-2xl">⭐</span>
                            <span class="text-2xl">⭐</span>
                            <span class="text-gray-600 ml-2 font-semibold">(4.9/5)</span>
                        </div>
                        <div
                            class="stock-badge inline-flex items-center gap-2 bg-green-100 text-green-700 px-4 py-2 rounded-full font-bold text-sm">
                            <span class="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                            In Stock
                        </div>
                    </div>
                </div>

                <!-- Description -->
                <div class="mb-8" data-aos="fade-left" data-aos-delay="100">
                    <p class="text-gray-700 text-lg leading-relaxed">
                        <?= nl2br(htmlspecialchars($product['description'] ?: 'Handcrafted with premium ingredients, made fresh daily. A delicious treat that will brighten your day!')) ?>
                    </p>
                </div>

                <!-- Price Display -->
                <div class="mb-8 relative" data-aos="fade-left" data-aos-delay="200">
                    <div class="inline-block relative">
                        <div
                            class="absolute inset-0 bg-gradient-to-r <?= $style['gradient'] ?> blur-xl opacity-30 rounded-3xl">
                        </div>
                        <div
                            class="relative bg-gradient-to-r <?= $style['gradient'] ?> text-white px-10 py-6 rounded-3xl shadow-2xl">
                            <div class="text-lg font-semibold mb-1">Price</div>
                            <div class="text-5xl font-black flex items-start">
                                <span class="text-3xl mr-1">₱</span>
                                <span id="price-display"><?= number_format($product['price'], 2) ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Order Form -->
                <form action="add_to_cart.php" method="POST" class="space-y-6" data-aos="fade-left"
                    data-aos-delay="300">
                    <input type="hidden" name="product_id" value="<?= htmlspecialchars($product['id']) ?>">

                    <?php if ($is_drink): ?>
                        <!-- Size Selection -->
                        <div>
                            <label class="block text-xl font-black text-gray-800 mb-4">
                                Choose Your Size:
                            </label>
                            <div class="grid grid-cols-3 gap-4">

                                <!-- Small -->
                                <label class="size-option cursor-pointer">
                                    <input type="radio" name="size" value="small" class="hidden size-radio" required>
                                    <div
                                        class="size-card bg-white border-3 border-gray-200 rounded-2xl p-6 text-center transition-all">
                                        <div class="text-4xl mb-2">🥤</div>
                                        <div class="font-black text-gray-800 text-lg mb-1">Small</div>
                                        <div class="text-sm text-gray-600 font-semibold">8oz</div>
                                        <div class="text-amber-600 font-bold text-lg mt-2">₱29</div>
                                    </div>
                                </label>

                                <!-- Medium -->
                                <label class="size-option cursor-pointer">
                                    <input type="radio" name="size" value="medium" class="hidden size-radio" checked
                                        required>
                                    <div
                                        class="size-card bg-white border-3 border-amber-400 rounded-2xl p-6 text-center transition-all active">
                                        <div class="text-4xl mb-2">🥤</div>
                                        <div class="font-black text-gray-800 text-lg mb-1">Medium</div>
                                        <div class="text-sm text-gray-600 font-semibold">16oz</div>
                                        <div class="text-amber-600 font-bold text-lg mt-2">₱39</div>
                                        <div
                                            class="absolute top-2 right-2 bg-amber-500 text-white text-xs px-2 py-1 rounded-full font-bold">
                                            Popular
                                        </div>
                                    </div>
                                </label>

                                <!-- Large -->
                                <label class="size-option cursor-pointer">
                                    <input type="radio" name="size" value="large" class="hidden size-radio" required>
                                    <div
                                        class="size-card bg-white border-3 border-gray-200 rounded-2xl p-6 text-center transition-all">
                                        <div class="text-4xl mb-2">🥤</div>
                                        <div class="font-black text-gray-800 text-lg mb-1">Large</div>
                                        <div class="text-sm text-gray-600 font-semibold">24oz</div>
                                        <div class="text-amber-600 font-bold text-lg mt-2">₱49</div>
                                    </div>
                                </label>

                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Quantity (Optional Enhancement) -->
                    <div>
                        <label class="block text-xl font-black text-gray-800 mb-4">
                            Quantity:
                        </label>
                        <div class="flex items-center gap-4">
                            <button type="button" onclick="changeQuantity(-1)"
                                class="w-12 h-12 rounded-full bg-gray-200 hover:bg-gray-300 transition-all font-bold text-xl flex items-center justify-center">
                                −
                            </button>
                            <input type="number" name="quantity" id="quantity" value="1" min="1" max="99"
                                class="w-20 text-center text-2xl font-bold border-2 border-gray-300 rounded-xl py-2">
                            <button type="button" onclick="changeQuantity(1)"
                                class="w-12 h-12 rounded-full bg-gray-200 hover:bg-gray-300 transition-all font-bold text-xl flex items-center justify-center">
                                +
                            </button>
                        </div>
                    </div>

                    <!-- Add to Cart Button -->
                    <button type="submit"
                        class="btn-add-cart w-full bg-gradient-to-r <?= $style['gradient'] ?> text-white py-6 rounded-2xl text-2xl font-black shadow-xl relative overflow-hidden">
                        <span class="relative z-10 flex items-center justify-center gap-3">
                            <i class="fa fa-shopping-cart"></i>
                            Add to Cart
                        </span>
                    </button>

                    <!-- Quick Actions removed: Wishlist & Share (not needed) -->
                </form>

                <!-- Back Link -->
                <a href="products.php"
                    class="mt-8 inline-flex items-center gap-2 text-amber-700 font-bold text-lg hover:text-amber-800 transition-all group"
                    data-aos="fade-left" data-aos-delay="400">
                    <span class="group-hover:-translate-x-2 transition-transform">←</span>
                    Back to Products
                </a>
            </div>
        </div>
    </div>

    <!-- Product Features -->
    <div class="grid md:grid-cols-4 gap-6 mt-12" data-aos="fade-up" data-aos-delay="500">
        <div class="info-card bg-white rounded-2xl p-6 shadow-lg text-center">
            <div class="text-5xl mb-3">✨</div>
            <h3 class="font-bold text-gray-800 mb-2">Fresh Daily</h3>
            <p class="text-sm text-gray-600">Made fresh every morning</p>
        </div>
        <div class="info-card bg-white rounded-2xl p-6 shadow-lg text-center">
            <div class="text-5xl mb-3">🌟</div>
            <h3 class="font-bold text-gray-800 mb-2">Premium Quality</h3>
            <p class="text-sm text-gray-600">Top-grade ingredients</p>
        </div>
        <div class="info-card bg-white rounded-2xl p-6 shadow-lg text-center">
            <div class="text-5xl mb-3">🚚</div>
            <h3 class="font-bold text-gray-800 mb-2">Fast Delivery</h3>
            <p class="text-sm text-gray-600">Quick & reliable service</p>
        </div>
        <div class="info-card bg-white rounded-2xl p-6 shadow-lg text-center">
            <div class="text-5xl mb-3">💯</div>
            <h3 class="font-bold text-gray-800 mb-2">100% Satisfaction</h3>
            <p class="text-sm text-gray-600">Money-back guarantee</p>
        </div>
    </div>
</div>

<script>
    // Initialize AOS
    if (typeof AOS !== 'undefined') {
        AOS.init({
            duration: 1000,
            once: true,
            offset: 100
        });
    }

    // Price update logic
    (function () {
        const category = <?= json_encode($product['category'] ?? '') ?>;
        const defaultSizePrices = { small: 29.00, medium: 39.00, large: 49.00 };
        const milkshakeSizePrices = { small: 69.00, medium: 79.00, large: 89.00 };
        const sizePrices = (category === 'milkshake') ? milkshakeSizePrices : defaultSizePrices;
        const basePrice = parseFloat(<?= json_encode((float) $product['price']) ?>);

        function priceForSize(size) {
            if (sizePrices.hasOwnProperty(size)) return sizePrices[size].toFixed(2);
            return basePrice.toFixed(2);
        }

        const priceEl = document.getElementById('price-display');

        // Size selection handling
        document.querySelectorAll('.size-radio').forEach(function (radio) {
            radio.addEventListener('change', function (e) {
                // Update price with animation
                if (priceEl) {
                    priceEl.classList.add('price-change');
                    setTimeout(() => {
                        priceEl.textContent = priceForSize(e.target.value);
                        priceEl.classList.remove('price-change');
                    }, 200);
                }

                // Update active state
                document.querySelectorAll('.size-option').forEach(opt => {
                    opt.classList.remove('active');
                    opt.querySelector('.size-card').classList.remove('border-amber-400', 'active');
                    opt.querySelector('.size-card').classList.add('border-gray-200');
                });

                const parent = e.target.closest('.size-option');
                parent.classList.add('active');
                parent.querySelector('.size-card').classList.add('border-amber-400', 'active');
                parent.querySelector('.size-card').classList.remove('border-gray-200');
            });
        });

        // Initialize with checked radio
        const checked = document.querySelector('.size-radio:checked');
        if (checked && priceEl) {
            priceEl.textContent = priceForSize(checked.value);
        }
    })();

    // Quantity controls
    function changeQuantity(delta) {
        const input = document.getElementById('quantity');
        const current = parseInt(input.value) || 1;
        const newValue = Math.max(1, Math.min(99, current + delta));
        input.value = newValue;
    }

    // Add to cart success animation
    document.querySelector('form').addEventListener('submit', function (e) {
        const btn = this.querySelector('.btn-add-cart');
        btn.innerHTML = '<span class="relative z-10 flex items-center justify-center gap-3"><i class="fa fa-check"></i> Added to Cart!</span>';
        btn.classList.add('bg-green-500');

        // Show floating notification
        const notification = document.createElement('div');
        notification.className = 'fixed top-24 right-6 bg-green-500 text-white px-8 py-4 rounded-2xl shadow-2xl font-bold z-50 flex items-center gap-3';
        notification.innerHTML = '<span class="text-2xl">✓</span> <span>Added to cart successfully!</span>';
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transform = 'translateY(-20px)';
            notification.style.transition = 'all 0.4s ease';
            setTimeout(() => notification.remove(), 400);
        }, 2500);
    });
</script>

<?php require 'includes/footer.php'; ?>