<?php
require 'includes/header.php';
require 'includes/navbar.php';
require 'includes/db.php';

if (!isset($_GET['id']))
    header('Location: products.php');
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$_GET['id']]);
$product = $stmt->fetch();

if (!$product)
    header('Location: products.php');
$page_title = $product['name'];
?>

<div class="max-w-4xl mx-auto px-4 py-16">
    <div class="grid md:grid-cols-2 gap-12 bg-white rounded-2xl shadow-xl p-8">
        <div>
            <img src="uploads/<?php echo $product['image']; ?>" class="w-full rounded-xl shadow-lg">
        </div>
        <div class="flex flex-col justify-center">
            <h1 class="playfair text-5xl font-bold mb-4"><?php echo htmlspecialchars($product['name']); ?></h1>
            <p class="text-gray-700 text-lg mb-6"><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
            <p class="text-4xl font-bold text-yellow-dark mb-8">₱<span
                    id="price-display"><?php echo number_format($product['price'], 2); ?></span></p>

            <form action="add_to_cart.php" method="POST">
                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">

                <?php
                // Check if product is a drink (has size options)
                $drink_categories = ['milktea', 'milkshake', 'fruittea', 'sparkling', 'coffee'];
                $is_drink = in_array($product['category'], $drink_categories);
                ?>

                <?php if ($is_drink): ?>
                    <div class="mb-6">
                        <label class="block text-lg font-semibold text-gray-700 mb-3">Select Size:</label>
                        <div class="flex gap-4">
                            <label class="flex items-center cursor-pointer">
                                <input type="radio" name="size" value="small"
                                    class="w-5 h-5 text-yellow-dark cursor-pointer" required>
                                <span class="ml-2 text-lg">Small (8oz)</span>
                            </label>
                            <label class="flex items-center cursor-pointer">
                                <input type="radio" name="size" value="medium"
                                    class="w-5 h-5 text-yellow-dark cursor-pointer" checked required>
                                <span class="ml-2 text-lg">Medium (16oz)</span>
                            </label>
                            <label class="flex items-center cursor-pointer">
                                <input type="radio" name="size" value="large"
                                    class="w-5 h-5 text-yellow-dark cursor-pointer" required>
                                <span class="ml-2 text-lg">Large (24oz)</span>
                            </label>
                        </div>
                    </div>
                <?php endif; ?>

                <button type="submit"
                    class="w-full bg-yellow-dark text-gray-900 py-4 rounded-lg text-xl hover:bg-yellow-warm transition font-semibold">
                    Add to Cart
                </button>
            </form>
            <script>
                (function(){
                    // Fixed price mapping for drink sizes (PHP pesos)
                    const sizePrices = { small: 29.00, medium: 39.00, large: 49.00 };
                    const basePrice = parseFloat(<?php echo json_encode((float)$product['price']); ?>);
                    function priceForSize(size){
                        // For drink categories, return fixed size price
                        if (sizePrices.hasOwnProperty(size)) return sizePrices[size].toFixed(2);
                        // Fallback: use base price
                        return basePrice.toFixed(2);
                    }

                    const priceEl = document.getElementById('price-display');
                    if(priceEl){
                        // initialize from checked radio (if any)
                        const checked = document.querySelector('input[name="size"]:checked');
                        if(checked){ priceEl.textContent = priceForSize(checked.value); }

                        document.querySelectorAll('input[name="size"]').forEach(function(r){
                            r.addEventListener('change', function(e){
                                priceEl.textContent = priceForSize(e.target.value);
                            });
                        });
                    }
                })();
            </script>
            <a href="products.php" class="mt-4 text-center text-yellow-dark underline">← Back to Products</a>
        </div>
    </div>
</div>

<?php require 'includes/footer.php'; ?>