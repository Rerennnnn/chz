<?php
// Test PHPMailer installation
require __DIR__ . '/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

try {
    $mail = new PHPMailer(true);
    echo "<h2 style='color: green;'>✓ PHPMailer is installed and working!</h2>";
    echo "<p>PHPMailer version: " . PHPMailer::VERSION . "</p>";
    echo "<p>All dependencies loaded successfully.</p>";
} catch (Exception $e) {
    echo "<h2 style='color: red;'>✗ PHPMailer Error: " . $e->getMessage() . "</h2>";
}
?>